                                    AQUALUNG- Underwater Quake Adventures!
                                            Version 1.01 28-APR-2000
                                Brought to You by logistix - ~the logistical one~
                                           logistix@planetquake.com
                                     http://www.planetquake.com/logistix

==========================
Installation Instructions:
==========================

-Make sure you've installed the most recent Q3A patch from id Software

-Download the Aqualung zip file and unzip it in your Quake 3 Directory. (Usually C:\Program Files\Quake III Arena\ )
 
-Run Q3A and choose the MODS option from the menu.

-Click on AQUALUNG- Underwater Quake Adventures! to load

-bind a key to +button5 to utilize the barrel roll ( I use mouse 2)

-Play and Enjoy! 

===========================
New CVARS
===========================

aq_tintWater 
[Default 1]
This was added anticipating problems with older videocards, although none have been reported yet.  Setting this to 0 will remove the blue tint effect from the display

aq_walkOnGround 
[Default 0]
This flag determines if you walk on the ground when you hit it or bounce off and keep swimming.  On more open levels(like Q3TOURNEY1 or Q3DM12), walking on the ground can make the game more challenging since walking slows you down, but on levels with low ceilings it's just annoying.  Setting to 1 allows you to walk on the ground.

aq_useTeamBubbles
[Default 1]
This flag gives anyone on the red team Red water bubbles.  Bubble trails from their guns are also red.

aq_useTeamShaders
[Default 1]
This replaces the gold enviro-suit with one that matches the team color.  Also uses standard skin instead of a team colored one.

aq_envirosuit
[Default 1]
Determines if the envirosuit effect is drawn.  This must be enabled for aq_useTeamShaders to work.
