                                                                      
                             edNinjaHedz
                            RELEASE NOTES
                             31-Jan-2000

GENERAL NOTES
=============

First off, I didn't design the sprites used in this release.  I wrote
an MD2 (Quake2 Model) converter and converted some add-ons from the
SuperMale collection.  This release should contain the SuperMale
Readme file.  If you want the actual MD2's they should be available at
http://www.fileplanet.com in the Quake2 section.  If anyone is inter-
ested in providing art e-mail me.

Everything else is COPYRIGHT JAN 2000 by Grant Olson.  This 
release is provided as/is, with no warranties.

You need an OpenGL ICD to get a decent framerate on the demo.  If you
haven't already, visit http://www.glsetup.com or your video-card manu-
facturer's homepage to get the latest drivers.  Also note that Voodoo1
and Voodoo2 based cards do not have an ICD even though a "full OpenGL
driver" is now available.  This means these cards won't get any 
hardware accelleration.  A seperate executeable will be provided in
the final release but it's not a priority now.  Sorry.

The framerate is not locked down in this release.  That means if your
system is slower than mine the animations will move slower and if yours
is faster the animations will move faster.  There set up to look 'right'
at about 50-60 fps.  I'd appreciate it if you could email me your system
configuration (processor type, processor speed, videocard) and framerate
so I can try to set a baseline system.

You can try and get a faster framerate by setting the CLIPPING option on
the video menu to NEAR.  You can also switch on SKIPFRAME mode which draws
every other frame.

My homepage: http://members.bellatlantic.net/~olsongt
My e-mail: logstx@bellatlantic.net

STARTING THE GAME
=================

Double click on the LaunchGame file.  It will present several options.
Choose the one that you think will run best on your system.

PLAYING THE GAME
================

When you run the program, it'll initally start up in game mode.  This
is a third person shooter, so you'll see your character on the screen
(currently daredevil).  Following are the control keys:

UP ARROW    - move forward
DOWN ARROW  - spin around 180 degrees
RIGHT ARROW - turn Right
LEFT ARROW  - turn left

CONTROL     - fire weapon

(if you're using the numeric keypad the following keys also work)

7 / HOME    - move forward while turning to the left
9 / PgUp    - move forward while turning to the right
   5        - fire weapon

That's about all there is to it.  There's only one sample level and
there arn't any 'win conditions' so even if you kill everyone you
can keep exploring.

CUSTOM SETTINGS
===============

If you want to set custom settings, the easiest way is to make a 
shortcut to the edNinjaHedz file, and set various command line 
options [GIVE MORE DETAILS, LIST OPTIONS ON THE GAME]

COMMAND LINE SETTINGS
=====================

Switches are added to the command line in the form of +switch to 
turn an option on and -switch to turn it off.  For example +fullscreen
will put the game in fullscreen mode and -fullscreen will run it
in windowed mode.

Following is a list of switches and descriptions.  The sign in 
parenthesis shows the default value.



