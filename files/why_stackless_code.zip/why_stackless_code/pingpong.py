def ping():
    print "PING"
    pong()

def pong():
    print "PONG"
    ping()


ping()
