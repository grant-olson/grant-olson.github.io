#ifndef MATRIX2D_FILE_SEEN
#define MATRIX2D_FILE_SEEN

#include "gfxTypes.h"
#include "vector.h"

//////////////////////////////////////////////////////////////////////
//
// This implements a basic 2D matrix so we can transform points into
// real space for collision detection.  It provides the routines to
// translate and rotate the matrix and multiply by matrix and vector.
// It also does some goofy stuff to address the fact that 0 degrees
// points down the negative Y axis, so it's not really general purpose
//
//////////////////////////////////////////////////////////////////////

class matrix2D
{
protected:

	// the actual matrix.  Protected so the user
	// doesn't have to figure out if it's row or column major
	GFX_FLOAT matrix[3][3];

public:
	matrix2D();

	void loadIdentity(void);

	void translate(GFX_FLOAT X, GFX_FLOAT Y);
	void rotate(double radians);

	matrix2D operator*(const matrix2D& otherMatrix);
	vector operator*(vector originalVector);
};

#endif