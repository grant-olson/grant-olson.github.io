#include "file_io.h"

// STRING CONSTANTS
#define CARRIAGE_RETURN 13
#define LINEFEED 10

//////////////////////////////////////////////////////////////////////
// WRITE THE LEVEL FILE
//////////////////////////////////////////////////////////////////////
bool
createFile(TCHAR* filename)
{
	HANDLE	saveFile;
	fileInfo fileHeader;
	DWORD		numWritten;
	int			i;

	GFX_TextureInfo*	tmpTexture;	// to save textures
	light*				tmpLight;	// to save lights

	fileHeader.worldSize		= World->Quadtree->Corner.x2 - World->Quadtree->Corner.x1;
	fileHeader.worldResolution	= World->Quadtree->resolution;
	fileHeader.backgroundColor	= World->bgcolor;
	fileHeader.fadeOn			= World->fadeOn;
	fileHeader.fadeThreshold	= World->fadeThreshold;
	fileHeader.floorColor		= World->Quadtree->floorColor;
	fileHeader.floorOn			= World->Quadtree->floor;
	fileHeader.ceilingOn		= World->Quadtree->ceiling;
	
	fileHeader.PlayerPos		= playerPos;

	fileHeader.textureCount		= World->textureCount;
	fileHeader.lightCount		= World->lightCount;
	fileHeader.leafCount		= World->Quadtree->leafCount();

	fileHeader.enemyCount		= enemyCount;
	fileHeader.objectCount		= 0;
	fileHeader.eventCount		= 0;


	saveFile = CreateFile(filename, GENERIC_WRITE,
				FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if(saveFile == INVALID_HANDLE_VALUE)
	{
		//couldn't create
		MessageBox(NULL, TEXT("Unable to save file."), szAppName, NULL);
		return FALSE;
	}

	WriteFile(saveFile, &fileHeader, sizeof(fileHeader),  &numWritten, NULL);

	WriteFile(saveFile, &playerPos, sizeof(playerPos),  &numWritten, NULL);

	for(i = 0; i < fileHeader.textureCount; i++)
	{
		tmpTexture = World->getPtrToTexture(i);
		WriteFile(saveFile, tmpTexture, sizeof(GFX_TextureInfo), &numWritten, NULL);
		WriteFile(saveFile, tmpTexture->texelData, sizeof(GLubyte) * tmpTexture->height * tmpTexture->width * 4,
					&numWritten, NULL);
	}

	for(i = 0; i < fileHeader.lightCount; i++)
	{
		tmpLight = World->getPtrToLight(i);

		WriteFile(saveFile, tmpLight, sizeof(light), &numWritten, NULL);
	}

	World->Quadtree->writeLeaf(saveFile);

	for(i = 0; i < fileHeader.enemyCount; i++)
	{
		WriteFile(saveFile, editEnemies[i], sizeof(enemyInfo), &numWritten, NULL);
	}
	//write Objects;
	//write events;

	CloseHandle(saveFile);

	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// READ THE LEVEL FILE
//////////////////////////////////////////////////////////////////////
bool
loadFile(TCHAR* filename)
{
	bool tmpReturn = TRUE;

	// info to create file
	HANDLE		loadFile;
	fileInfo	fileHeader;
	DWORD		numWritten;

	// loop counter
	int			i;

	// temporary info to load in and send out
	GFX_TextureInfo	tmpTexture;
	leaf		tmpLeaf;
	light		tmpLight;
	enemyInfo	tmpEnemy;

	loadFile =  CreateFile(filename, GENERIC_READ,
				FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(loadFile == INVALID_HANDLE_VALUE)
	{
		//couldn't create ABORT
		GFX_ErrorMessage("Unable to create file.","loadFile:.lvl");
		return FALSE;
	}

	//Read File Header
	if(!ReadFile(loadFile, &fileHeader, sizeof(fileInfo), &numWritten, NULL) ||
		!numWritten)
	{
		GFX_ErrorMessage("Unable to read file header.","fileLoad-lvl");
		tmpReturn = FALSE;

		goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
	}
	
	//init WORLD global
	World = new world(fileHeader.worldSize, fileHeader.worldResolution);

	World->setBgcolor(fileHeader.backgroundColor);
	World->fadeOn = fileHeader.fadeOn;
	World->fadeThreshold = fileHeader.fadeThreshold;
	World->Quadtree->setFloorColor(fileHeader.floorColor);
	World->Quadtree->floor = fileHeader.floorOn;
	World->Quadtree->ceiling = fileHeader.ceilingOn;
	World->Quadtree->floorTexture = World->textureID;

	//TEMP TEXTURE EXPERIMENT
	World->loadBackgroundImage("bg.bmp");

	//read player position
	if(!ReadFile(loadFile, &playerPos, sizeof(playerPos), &numWritten, NULL) ||
		!numWritten)
	{
		GFX_ErrorMessage("Unable to read player Info.","fileLoad-lvl");
		tmpReturn = FALSE;

		goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
	}

	//read textures
	for(i = 0; i < fileHeader.textureCount; i++)
	{
		if(!ReadFile(loadFile, &tmpTexture, sizeof(GFX_TextureInfo), &numWritten, NULL) ||
			!numWritten)
		{
			GFX_ErrorMessage( "Unable to read texture header.", "fileLoad-lvl");
			tmpReturn = FALSE;

			goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
		}

		int tmpSize = (int)(tmpTexture.height * tmpTexture.width * 4);
		tmpTexture.texelData = new GLubyte[tmpSize];

		if(!ReadFile(loadFile, tmpTexture.texelData, sizeof(GLubyte) * tmpSize, &numWritten, NULL) ||
			!numWritten)
		{
			GFX_ErrorMessage( "Unable to read texture data.","fileLoad-lvl");
			tmpReturn = FALSE;

			goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
		}

		World->addNewTexture(tmpTexture);
	}

	// read light info
	for(i = 0; i < fileHeader.lightCount; i++)
	{
		if(!ReadFile(loadFile, &tmpLight, sizeof(light), &numWritten, NULL) ||
			!numWritten)
		{
			GFX_ErrorMessage("Unable to read light info.","fileLoad-lvl");
			tmpReturn = FALSE;

			goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
		}
		World->addNewLight(tmpLight);
	}

	// read leaf info
	for(i = 0; i < fileHeader.leafCount; i++)
	{
		if(!ReadFile(loadFile, &tmpLeaf, sizeof(leaf), &numWritten, NULL) ||
			!numWritten)
		{
			GFX_ErrorMessage("Unable to read leaf info.","fileLoad-lvl");
			tmpReturn = FALSE;

			goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
		}

		tmpLeaf.texturePointer = World->textureID;
		World->addLeaf(&tmpLeaf);
	}

	// read enemy info
	for(i = 0; i < fileHeader.enemyCount; i++)
	{
		if (!ReadFile(loadFile, &tmpEnemy, sizeof(enemyInfo), &numWritten, NULL) ||
			!numWritten)
		{
			GFX_ErrorMessage("Unable to read enemy Info.","fileLoad-lvl");
			tmpReturn = FALSE;

			goto CLOSE_FILE_HANDLE;	// ABORT- HANDLE GRACEFULLY
		}
		newEnemy(tmpEnemy);
	}

	//READ OBJECTS;
	//READ EVENTS;


CLOSE_FILE_HANDLE:	// SO WE CAN HANDLE ERRORS GRACEFULLY

	if(!CloseHandle(loadFile))
	{
		GFX_ErrorMessage("Unable to close handle","loadFile-lvl");
		tmpReturn = FALSE;
	}

	return tmpReturn;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This writes info to a log file
//
// [PARAMETERS]
//   logInfo- Pointer to the NULL Terminated string
//
//////////////////////////////////////////////////////////////////////
void WriteToLogFile(LPSTR logInfo)
{

#ifdef PREFS_ON  // ONLY LOG IF PREFS SAY TO
	if(!Prefs.log){return;}
#endif

	HANDLE	hFile;
	DWORD	dwNumWritten;

	CHAR	EndOfLine[3] = {CARRIAGE_RETURN, LINEFEED, '\0'};
	//OPEN FILE
	hFile = CreateFile(TEXT("log.txt"), GENERIC_WRITE,
				FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	// MOVE TO END
	SetFilePointer(hFile, 0, 0, FILE_END);

	// GO UNTIL WE HIT END OF STRING, WRITING ONE CHAR AT A TIME
	while(*logInfo != '\0')
	{
		WriteFile(hFile, logInfo, sizeof(CHAR), &dwNumWritten, NULL);
		logInfo++;
	}

	// ADD LINEFEED
	WriteFile(hFile, EndOfLine, sizeof(CHAR) * 3, &dwNumWritten, NULL);

	// EXIT
	CloseHandle(hFile);
}