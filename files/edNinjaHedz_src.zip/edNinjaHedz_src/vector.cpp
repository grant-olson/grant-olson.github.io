#include "vector.h"

/*********************************************************************
* VECTOR:
* THIS CLASS PROVIDES A VECTOR LOCATION.  ALSO INCLUDED IS A RADIUS 
* FOR BOUND CHECKING. (IS THERE?)
*********************************************************************/
////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This locks the angle between 0 and 360
//
// [PARAMETERS]
//    GFX_FLOAT tmpDegrees- angle to clamp
//
// [RETURN TYPE]
//    the Clampped angle
//
/////////////////////////////////////////////////////////////////////
GFX_FLOAT
vector::clampDegrees(GFX_FLOAT tmpDegrees)
{
	while(tmpDegrees < 0.0 || tmpDegrees >=360.0)
	{
		if(tmpDegrees <  0.0){tmpDegrees += 360.0;}
		if(tmpDegrees >= 360.0){tmpDegrees -= 360.0;}
	}
	return tmpDegrees;
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This loads in an angle in degrees, makes sure it's between 0-360
//   degrees and loads in the proper radians amount. This function 
//   should be used if you don't want to explicitly do this.
//
// [PARAMETERS]
//   GFX_FLOAT tmpDegrees- angle in degrees
//
/////////////////////////////////////////////////////////////////////
void 
vector::setAngle(GFX_FLOAT tmpDegrees)
{
	degrees = clampDegrees(tmpDegrees);
	degreesToRadians();
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This loads radians with the proper value after setting degrees.
//   Open GL works with degrees. The C math library works with radians.
//
// [NOTES]
//   This needs to be done if you don't use setAngle()
//
/////////////////////////////////////////////////////////////////////
void
vector::degreesToRadians(void)
{
	radians = ((double)degrees) * PI / 180;
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This converts radians to degrees
//
/////////////////////////////////////////////////////////////////////
void
vector::radiansToDegrees(void)
{
	degrees = (GFX_FLOAT)(radians * 180 / PI);
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This moves the vector according to it's velocity and angle
//
/////////////////////////////////////////////////////////////////////
void
vector::move(void)
{ 
	X += (GFX_FLOAT)sin(radians) * velocity;
	Y -= (GFX_FLOAT)cos(radians) * velocity;
}

////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This calculates the angle of another VECTOR relative to the 
//   current VECTOR in DEGREES
//
// [PARAMETERS]
//   vector otherVector
//
// [RETURN TYPE]
//   GFX_FLOAT angle in Degrees
//
// [NOTES]
//   Assumes 0 degrees is down the Z-axis.  This function doesn't 
//   take into account the direction of the VECTOR
//
/////////////////////////////////////////////////////////////////////
GFX_FLOAT
vector::getOtherAngle(vector otherVector)
{
	GFX_FLOAT tmpX, tmpY, tmpAngle;

	tmpX = otherVector.X - X;
	tmpY = Y - otherVector.Y;
	tmpAngle = (GFX_FLOAT)atan2((double)tmpX, (double)tmpY);
	tmpAngle = tmpAngle * 180.0 / PI;   // convert to degrees

	return clampDegrees(tmpAngle);
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This calculates the DISTANCE of another VECTOR
//
// [PARAMETERS]
//    vector otherVector
//
// [RETURN TYPE]
//    GFX_FLOAT- the Distance
//
/////////////////////////////////////////////////////////////////////
GFX_FLOAT
vector::getOtherDistance(vector otherVector)
{
	GFX_FLOAT tmpX, tmpY, tmpDistance;

	tmpX = X - otherVector.X;
	tmpY = Y - otherVector.Y;
	tmpDistance = sqrt((tmpX * tmpX) + (tmpY * tmpY));

	return tmpDistance;
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This figures out if a given VECTOR is in a given FIELD OF VIEW
//    This means that the other VECTOR is within a given DISTANCE
//    of the current vector and within a given ANGLE RANGE of the 
//    direction the VECTOR is facing
//
// [PARAMETERS]
//    vector otherVector- the other Vector
//    GFX_FLOAT range- the ANGLE RANGE
//    GFX_FLOAT dist-  the distance in units
//
// [RETURN TYPE]
//    TRUE- the other Vector is in the field of view
//    FALSE- it's not
//
/////////////////////////////////////////////////////////////////////
bool
vector::getOtherFOV(vector otherVector, GFX_FLOAT range, GFX_FLOAT dist)
{
	GFX_FLOAT tmpAngle, boundLeft, boundRight;

	if( getOtherDistance(otherVector) <= dist)
	{
		tmpAngle = getOtherAngle(otherVector);
		boundLeft = clampDegrees( degrees - (range / 2) ); 
		boundRight = clampDegrees( degrees + (range / 2) );

		if(boundLeft <= boundRight)              //Normal angle calculationss
		{
			if( (tmpAngle >= boundLeft) && (tmpAngle <= boundRight) )
			{
					return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
		else                                   // the bounds cross the 0 deg. mark
		{
			if( (tmpAngle >= boundLeft) || (tmpAngle <= boundRight) )
			{
				return TRUE;
			}
			else
			{
				return FALSE;
			}
		}
	}
	else
	{
		return FALSE;
	}  //failed distance test
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This checks to see if bounding circles of this and another VECTOR
//   collide.  A very basic intersection test
//
// [PARAMETERS]
//   vector otherVector- the other Vector
//
// [RETURN TYPE]
//    TRUE- they collide
//    FALSE- they don't
//
/////////////////////////////////////////////////////////////////////
bool
vector::getOtherCollide(vector otherVector)
{
	GFX_FLOAT xDistance, yDistance;  //Distance between positions
	GFX_FLOAT distLengthSquared;
	GFX_FLOAT radiusLengthSquared;  //Distance of radii added

	radiusLengthSquared = (radius + otherVector.radius) *
                        (radius + otherVector.radius) ;

	xDistance = X - otherVector.X;
	yDistance = Y - otherVector.Y;
	distLengthSquared = (xDistance * xDistance) + (yDistance * yDistance);

	if(distLengthSquared <= radiusLengthSquared)
	{
		return TRUE;      // overlap
	}
	else
	{
		return FALSE;     // don't overlap
	}
}

