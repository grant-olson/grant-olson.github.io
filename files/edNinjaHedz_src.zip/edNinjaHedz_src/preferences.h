#ifndef	PREFS_FILE_SEEN
#define PREFS_FILE_SEEN

#include "gfxTypes.h"

extern void WriteToLogFile(LPSTR logInfo);   // from FILE_IO.CP

enum clipPlane{CLIP_NEAR, CLIP_MEDIUM, CLIP_FAR};
enum textures{NEAREST, LINEAR};
//
// This just holds user preferences on various settings
//
class preferences
{
public:

	bool		fullscreen;
	bool		log;		// Write to Log File?

	bool		lowRes;		// Low Resolution
	bool		thirtyTwoBit;	// Thirty two bit color
	bool		alpha;		// alpha channel
	bool		lightmap;
	bool		flush;		// Periodically FLUSH GL for videocard

	clipPlane	clip;		// clipping size
	textures	textureMode;	//TEXTURE MODE
	GFX_FLOAT	gamma;		// gamma setting, between 0.0 - 2.0
	bool		fog;		// use fogging for distance attenuation
	bool		realFloor;	// Use a Real Floor / Ceiling instead of background image mockup
	bool		skipframe;	// automatically skip every other frame without testing speed

	preferences();

};

/////////////////////////////////////////////////////////////////////
//
// Not part of the preferences struct but this is some stuff so that
// we can use command line switches to override default prefs
//
/////////////////////////////////////////////////////////////////////

extern preferences Prefs;

#define	CMD_PARAMETERS	18	// LINES IN cmdLineInstruction
#define CONVERT_TO_LOWERCASE(a)	(a += 32)

// ENUMERATED OPTIONS
enum	cmdLineCommands{CMD_FULLSCREEN, CMD_LOWRES, CMD_32BIT, CMD_ALPHA, CMD_FOG,
						CMD_FLOOR, CMD_SKIPFRAME,
						CMD_GAMMA_LOW, CMD_GAMMA_MEDIUM, CMD_GAMMA_HIGH,
						CMD_CLIP_NEAR, CMD_CLIP_MEDIUM, CMD_CLIP_FAR,
						CMD_TEXTURE_NEAREST, CMD_TEXTURE_LINEAR,
						CMD_LIGHTMAP, CMD_FLUSH,
						CMD_LOG,
						CMD_NOMATCH};

// TABLE TO CONVERT STRING TO ENUMERATED OPTION
struct cmdLineTable
{

	CHAR*	name;
	cmdLineCommands	command;

};


// FUNCTIONS
void	parseWinCmdLine(LPSTR szCmdLine);
void	parseCmdInstruction(LPSTR szInstruction);
void	processCmdInstruction(CHAR type, cmdLineCommands instruction);
//
void	writePrefsToLogFile(void);
#endif