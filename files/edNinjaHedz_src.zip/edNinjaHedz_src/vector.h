#ifndef GFX_VECTOR_SEEN
#define GFX_VECTOR_SEEN

#include "gfxTypes.h"

//////////////////////////////////////////////////////////////////////
//
// This provides a basic vector class to hold the position,
//  orientation and speed of objects:
//
// public member variables:
//
//     X, Y     - X and Y coordinates, assuming an overhead orthographic
//                 view.  In 3D the Y-axis is translated to the Z axis.
//     degrees,
//     radians  - holds the degree and radian values for the current 
//                vector.  It is reccommended that the setAngle()
//                function is used so that bounds checking and
//                conversion is performed.  The MATH library requires 
//                radians for trig operations so this must be correct 
//                to move the vector.  OpenGL uses degrees so that must 
//                be correct to render.  In general, using degrees is 
//                preferred because radians can drift after time.
//
//     velocity - rate of movement.
//     radius   - A vector doesn't really have a radius, but the object 
//                it's attached to does. Provides a quick way for
//                collision detection.
//
//
// public member variables:
//   
//   setAngle(GFX_FLOAT tmpAngle)
//      Takes input in degrees and performs bounds checking and conversion
//      to radians.  If you don't use this function you MUST explicitly 
//      provide radians or the data will be garbage.
//      you can also use following functions to correct.
//
//   degreesToRadians(void)
//      loads the radians var with proper value based on valid info for degrees
//   radiansToDegrees(void)
//      loads the degrees var with proper value based on valid info for radians.
//
//   move(void)
//      moves the vector based on direction and velocity.
//
// THESE FUNCTIONS COMPARE THIS VECTORS POSITION TO ANOTHER
//
//   getOtherAngle(vector otherVector);  //returns degrees
//      returns the angle of other vector relative to this one in degrees
//
//   getOtherDistance(vector otherVector);
//      returns the distance between the two vectors
//
// getOtherFOV(vector otherVector, GFX_FLOAT range, GFX_FLOAT dist);
//      this returns TRUE/ FALSE depending on weather the other vector
//      falls within a theoretical 'Field of View'.
//      Basically if it falls within a certain distance and angle range
//      
//   getOtherCollide(vector otherVector);
//      returns TRUE-FALSE if vector bounding spheres collide.
//
//
// private functions:
//
//  clampDegrees(GFX_FLOAT tmpDegrees);
//     limits the angle to between 0 -360 degrees
//
//////////////////////////////////////////////////////////////////////
struct vector
{

private:
  GFX_FLOAT clampDegrees(GFX_FLOAT tmpDegrees);

public:

  GFX_FLOAT X, Y;
  GFX_FLOAT degrees;
  double radians;
  GFX_FLOAT velocity;
  GFX_FLOAT radius;      //not really part of the vector, bounding sphere

  void setAngle(GFX_FLOAT tmpAngle);
  void degreesToRadians(void);
  void radiansToDegrees(void);

  void move(void);

  GFX_FLOAT getOtherAngle(vector otherVector);  //returns degrees
  GFX_FLOAT getOtherDistance(vector otherVector);
  bool    getOtherFOV(vector otherVector, GFX_FLOAT range, GFX_FLOAT dist);
  bool    getOtherCollide(vector otherVector);
};



#endif /* FILE_VECTOR_SEEN */