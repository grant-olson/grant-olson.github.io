#include "editor.h"

//////////////////////////////////////////////////////////////////////////////////////////
// This does the basic OpenGL initialization
//////////////////////////////////////////////////////////////////////////////////////////
void initGL(){

	glMatrixMode(GL_PROJECTION);
	glEnable(GL_DEPTH_TEST);

	glShadeModel(GL_FLAT);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHTING);
	glDisable(GL_COLOR_MATERIAL);

	glDisable(GL_DITHER);    // Don't dither, we're never below 16 bit

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);      
	glPolygonMode(GL_FRONT, GL_FILL);


	if(Prefs.lightmap)
	{
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	else
	{
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	}

	if(Prefs.alpha)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}
}

void setupFog(void)
{
	GFX_FLOAT fogColor[4] = {0.0, 0.0, 0.0, 1.0};

	fogColor[0] = World->bgcolor.red;
	fogColor[1] = World->bgcolor.green;
	fogColor[2] = World->bgcolor.blue;

	GFX_FLOAT fogBegin, fogEnd;

	fogBegin = 0.0;

	switch(Prefs.clip)
	{
	case CLIP_NEAR:
		fogEnd = 25.0;
		break;

	case CLIP_MEDIUM:
		fogEnd = 50.0;
		break;

	case CLIP_FAR:
		fogEnd = 75.0;
		break;

	default:
		fogEnd = 50.0;
		break;
	}

	glFogi(GL_FOG_MODE, GL_LINEAR);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 1.0);
	glHint(GL_FOG_HINT, GL_DONT_CARE);
	glFogf(GL_FOG_START, fogBegin);
	glFogf(GL_FOG_END, fogEnd);
}


////////////////////////////////////////////////////////////////////////////////
// displayGL.
// draws the current Frame and swaps buffers
////////////////////////////////////////////////////////////////////////////////
void
displayGL(void)
{
	if(drawOrNot){World->addLightsIndirect();}

	if(EditOn)
	{
		displayEditorGL();
	}
	else
	{
		displayGameGL();
	}
}

//////////////////////////////////////////////////////////////////////
void displayGameGL(void)
{

	World->Camera.chase(Player->Position.current);

	glEnable(GL_TEXTURE_2D);
	World->render(drawOrNot);

	movePlayer();

	Player->cyclePosition();
	Player->bound(World);
	Player->cycleState();
	Player->cycleAnim();

	if(Prefs.fog)
	{
		glEnable(GL_FOG);
	}

	color tmpColor;

	tmpColor = World->getLightColor(Player->Position.current);

	Player->draw(drawOrNot, tmpColor);
	if(Prefs.flush){glFlush();glFinish();}	// FLUSH IF NECESSARY

	Projectiles->draw(drawOrNot);
	if(Prefs.flush){glFlush();glFinish();}	// FLUSH IF NECESSARY

	Enemies->draw(drawOrNot);
	if(Prefs.flush){glFlush();glFinish();}	// FLUSH IF NECESSARY

	if(Prefs.fog)
	{
		glDisable(GL_FOG);
	}

	if(Prefs.skipframe && drawOrNot)
	{
		drawOrNot = FALSE;
	}
	else
	{
		drawOrNot = TRUE;
	}
}

//////////////////////////////////////////////////////////////////////
void displayEditorGL(void)
{
	light* tmpLight;

	World->Camera.place(editPos);

#if 1
	glDisable(GL_FOG);
#endif

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	gluPerspective( 80.0, 1.33, 1.0, editZoomDistance * 1.1);

	World->Camera.visionRange = editZoomDistance * 1.4;

	gluLookAt(editPos.X,    editZoomDistance,    editPos.Y,
			editPos.X,    0,    editPos.Y,
			0,    0,   -1);


	glEnable(GL_TEXTURE_2D);
	World->draw();
	glDisable(GL_TEXTURE_2D);	
		
	// Draw icon
	glBegin(GL_QUADS);

	glColor3f(1.0, 1.0, 1.0);
	glVertex3f(editPos.X, 3.25, editPos.Y);
	glVertex3f(editPos.X, 3.25, editPos.Y + 1);
	glVertex3f(editPos.X + 1, 3.25, editPos.Y + 1);
	glVertex3f(editPos.X + 1, 3.25, editPos.Y);

	glEnd();

	//draw Positioned Lights
	glBegin(GL_QUADS);
	glColor3f(1.0, 1.0, 0.0);

	for(int i = 0; i < World->lightCount; i++)
	{
		tmpLight = World->getPtrToLight(i);

		glVertex3f(tmpLight->Position.X, 3.25, tmpLight->Position.Y);
		glVertex3f(tmpLight->Position.X , 3.25, tmpLight->Position.Y + 1);
		glVertex3f(tmpLight->Position.X + 1, 3.25, tmpLight->Position.Y + 1);
		glVertex3f(tmpLight->Position.X + 1, 3.25, tmpLight->Position.Y);
			
	}
	glEnd();

	if(World->lightCount != 0)
	{
		tmpLight = World->getPtrToLight(currentLight);
			
		glBegin(GL_LINE_STRIP);
		glColor3f(1.0, 1.0, 1.0);

		glVertex3f(tmpLight->Position.X - 0.2, 3.25, tmpLight->Position.Y - 0.2);
		glVertex3f(tmpLight->Position.X  - 0.2 , 3.25, tmpLight->Position.Y + 1.2);
		glVertex3f(tmpLight->Position.X + 1.2 , 3.25, tmpLight->Position.Y + 1.2);
		glVertex3f(tmpLight->Position.X + 1.2 , 3.25, tmpLight->Position.Y -0.2);
		glVertex3f(tmpLight->Position.X - 0.2, 3.25, tmpLight->Position.Y - 0.2);

		glEnd();
	}

	//draw Enemies
	glBegin(GL_QUADS);
	glColor3f(1.0, 0.0, 0.0);

	for(i = 0; i < enemyCount; i++)
	{
		glVertex3f(editEnemies[i]->Position.X, 3.25, editEnemies[i]->Position.Y);
		glVertex3f(editEnemies[i]->Position.X , 3.25, editEnemies[i]->Position.Y + 1);
		glVertex3f(editEnemies[i]->Position.X + 1, 3.25, editEnemies[i]->Position.Y + 1);
		glVertex3f(editEnemies[i]->Position.X + 1, 3.25, editEnemies[i]->Position.Y);
	}

	glEnd();
		
	if(enemyCount != 0)
	{
		glBegin(GL_LINE_STRIP);
		glColor3f(1.0, 1.0, 1.0);

		glVertex3f(editEnemies[currentEnemy]->Position.X - 0.2, 3.25, editEnemies[currentEnemy]->Position.Y - 0.2);
		glVertex3f(editEnemies[currentEnemy]->Position.X  - 0.2 , 3.25, editEnemies[currentEnemy]->Position.Y + 1.2);
		glVertex3f(editEnemies[currentEnemy]->Position.X + 1.2 , 3.25, editEnemies[currentEnemy]->Position.Y + 1.2);
		glVertex3f(editEnemies[currentEnemy]->Position.X + 1.2 , 3.25, editEnemies[currentEnemy]->Position.Y -0.2);
		glVertex3f(editEnemies[currentEnemy]->Position.X - 0.2, 3.25, editEnemies[currentEnemy]->Position.Y - 0.2);

		glEnd();
	}

	//draw PLAYER
	glBegin(GL_QUADS);
	glColor3f(0.0, 1.0, 0.0);

	glVertex3f(playerPos.X, 3.25, playerPos.Y);
	glVertex3f(playerPos.X, 3.25, playerPos.Y + 1);
	glVertex3f(playerPos.X + 1, 3.25, playerPos.Y + 1);
	glVertex3f(playerPos.X + 1, 3.25, playerPos.Y);

	glEnd();

	//draw Primitive rectangle
	if(PrimitiveOn)
	{
	glBegin(GL_LINES);

	if(addRect)
	{glColor3f(1.0, 1.0, 1.0);}
	else
	{glColor3f(1.0, 0.0, 0.0);}

	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y1);
	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y1);

	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y2);
	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y2);

	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y1);
	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y2);

	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y1);
	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y2);

	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y1);
	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y1);

	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y2);
	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y2);

	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y1);
	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y2);

	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y1);
	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y2);

	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y1);
	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y1);

	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y1);
	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y1);

	glVertex3f(editPrimitive.x1, 0.0, editPrimitive.y2);
	glVertex3f(editPrimitive.x1, 3.25, editPrimitive.y2);

	glVertex3f(editPrimitive.x2, 0.0, editPrimitive.y2);
	glVertex3f(editPrimitive.x2, 3.25, editPrimitive.y2);

	glEnd();
	}
}

void newEnemy(enemyInfo tmpEnemy)
{
	if(enemyCount < MAX_ENEMIES)
	{
		editEnemies[enemyCount] = new enemyInfo;
		(*editEnemies[enemyCount]) = tmpEnemy;

		enemyCount++;
	}
	else
	{
		MessageBeep(0);
	}
}


void initLevel(void)
{
	Player = new player;

	Player->Position.setXY(playerPos.X, playerPos.Y);
	Player->SoundEngine = SoundEngine;
	Player->Position.setAngle(playerPos.degrees);
	Player->Position.velocity = playerPos.velocity;
	Player->Position.move();

	World->Camera.place(Player->Position.current);

	Enemies = new enemies;
	Projectiles = new projectiles;

	Enemies->World = World;
	Enemies->SoundEngine = SoundEngine;

	Enemies->voidPointer1 = Player;
	Enemies->voidPointer2 = Projectiles;
	Enemies->initPointers();

	for(int i = 0; i < enemyCount; i++)
	{
		Enemies->addNew(editEnemies[i]->Type);
		Enemies->current->Position.setXY(editEnemies[i]->Position.X, editEnemies[i]->Position.Y);
		Enemies->current->Position.setAngle(editEnemies[i]->Position.degrees);
		Enemies->current->Position.move();
	}

	Projectiles->voidPointer1 = Enemies;
	Projectiles->voidPointer2 = Player;
	Projectiles->initPointers();
	Projectiles->World = World;
	Projectiles->SoundEngine = SoundEngine;
}

void cleanUpLevel(void)
{
	if(Projectiles != NULL)
	{
		delete Projectiles;
		Projectiles = NULL;
	}

	if(Enemies != NULL)
	{
		delete Enemies;
		Enemies = NULL;
	}

	if(Player != NULL)
	{
		delete Player;
		Player = NULL;
	}
}



void editTitleText(HWND hwnd)
{
	TCHAR	szTitleString[80], szTempString[40];

	if(addRect || deleteRect)
	{
		wsprintf(szTempString, 
				addRect ? TEXT("ADD (%1i, %1i --> %1i, %1i)") :
						  TEXT("DELETE (%1i, %1i --> %1i, %1i)") ,
				(int)editPrimitive.x1, (int)editPrimitive.y1,
				(int)editPrimitive.x2, (int)editPrimitive.y2);
	}
	else
	{
		wsprintf(szTempString, TEXT("(%1i, %1i)"), (int)editPos.X, (int)editPos.Y);
	}

	wsprintf(szTitleString, TEXT("%s - [%s] - %s"), szAppName,
		szTitleName[0] == TEXT('\0') ? NO_FILE_LOADED : szTitleName, szTempString);

	SetWindowText(hwnd, szTitleString);
}

void
deleteAllEnemies(void)
{
	for(int i = 0; i < enemyCount; i++)
	{
		delete editEnemies[i];
	}

	enemyCount = 0;
}

void
deleteEnemy(int index)
{
	if(index >= 0 && index < enemyCount)
	{
		delete editEnemies[index];

		for(int i = index; i < enemyCount; i++)
		{
			editEnemies[i] = editEnemies[i + 1];
		}

		editEnemies[enemyCount] = NULL;
		enemyCount--;
	}
}

void cleanUpEditor(void)
{
	deleteAllEnemies();
	editLeaf.textureIndex = 0;
}
/////////////////////////////////////////////////////////////////////
// Gets key states and moves player.  Should incorporate DX in the 
// game version
/////////////////////////////////////////////////////////////////////
void movePlayer(void)
{
	static int flipWait = 0;
	static int throwWait = 0;

	int iState;

	iState = GetAsyncKeyState(VK_ESCAPE);

	if(iState < 0){PostQuitMessage(0);}

	if(Player->State.dead){return;}

	iState = GetAsyncKeyState(VK_UP);

	if(iState < 0)
	{
		if(!Player->State.hit)
		{
			Player->Position.velocity = 0.6;
		}
		else
		{
			Player->Position.velocity = 0.1;
		}
	}

	iState = GetAsyncKeyState(VK_DOWN);

	if(iState < 0)
	{
		flipWait++;
		
		if(flipWait > 15)
		{
			Player->Position.setAngle(Player->Position.degrees + 180.0);
			flipWait = 0;
		}
	}

	iState = GetAsyncKeyState(VK_RIGHT);

	if(iState < 0)
	{
		Player->Position.setAngle(Player->Position.degrees + 4.0);
	}

	iState = GetAsyncKeyState(VK_LEFT);

	if(iState < 0)
	{
		Player->Position.setAngle(Player->Position.degrees - 4.0);
	}

	iState = GetAsyncKeyState(VK_HOME);

	if(iState < 0)
	{
		Player->Position.velocity = 0.6;
		Player->Position.setAngle(Player->Position.degrees - 4.0);
	}

/*	iState = GetAsyncKeyState(VK_HOME);

	if(iState < 0)
	{
		Player->Position.velocity = 0.6;
		Player->Position.setAngle(Player->Position.degrees - 4.0);
	}
	*/

	iState = GetAsyncKeyState(VK_CONTROL);

	if (iState < 0)
	{
		if(throwWait++ == 0)
		{
			Projectiles->addNew(STAR);
			Projectiles->current->Position.setXY(Player->Position.current.X,
				Player->Position.current.Y);
			Projectiles->current->Position.setAngle(Player->Position.current.degrees);
			Projectiles->current->Position.velocity = 0.7;
			Projectiles->current->Position.move();
			Projectiles->current->Position.move();
			SoundEngine->playSound(STAR_THROW);
		}
		else
		{
			if(throwWait > 6){throwWait = 0;}
		}
	}


}

