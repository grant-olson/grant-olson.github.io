#include "NinjaHedEntities.h"

/*******************************************************************************
* head:
* THIS IS A DUMMY CLASS BASED ON sprite FOR DEVELOPMENT PURPOSES WHILE I SIFT
* OUT WHAT FUNCTIONS ETC I NEED AND IMPLEMENTATION OF THE STATE MACHINE.
*******************************************************************************/
mesh* head::HEAD_MESH = NULL;

head::head()
{
	previous = NULL;
	next = NULL;

	if(HEAD_MESH == NULL)
	{
		HEAD_MESH = new mesh(TEXT("msh//head.msh"));
	}

	Color.setColor(0.7, 0.7, 0.7);
	Mesh = HEAD_MESH;

	frame = Q_RUN_START;
	animCounter = 0;
	State.hit = 0;

	Position.setXY( 0.0,0.0);
//	Position.setBoundBox(-0.16666666, 0.16666666, -0.16666666, 0.16666666);
//	Position.current.radius = 0.666;


	Position.current.radius = 3.5;
	Position.setBoundBox(-0.66666666, 0.33333333, -2.2222222, 0.1666666);  // For full person
	Position.setAngle(0.0);
	Position.velocity = 0;
	Position.move();


	hitPoints = 3;
}

//////////////////////////////////////////////////////////////////////
// Sets up pointers to elements we need
//////////////////////////////////////////////////////////////////////
void
head::initPointers(void)
{
	Projs  = (spriteCollection*) voidPointer1;
	Player = (sprite*) voidPointer2;
}

//////////////////////////////////////////////////////////////////////
// Just needed to unPURE the virtual function it's based on.
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// All this does now is move the head.  Will change.
//////////////////////////////////////////////////////////////////////
void
head::cyclePosition(void)
{
	GFX_FLOAT tmpAngle;

	if(State.hit || State.dead)  //Hit or dead, doesn't move
		{return;}   

	if(!State.sight && 
	Position.current.getOtherFOV(Player->Position.current, 60.0, 12.0))   //Checks to see if you're in sight
	{
		SoundEngine->playSound(NINJA_YELL);
		tmpAngle = Position.current.getOtherAngle(Player->Position.current);
		Position.velocity = 0.2;
		Position.setAngle(tmpAngle);
		State.sight = 20;
	}
    
	if(!State.hit && State.sight)   //Isn't Hit, Just saw you
	{
		Position.velocity = 0.2;
	}

	if(!State.hit && State.saw)
	{
		if(Position.current.getOtherFOV(Player->Position.current, 60.0, 8.0))
		{
			State.saw = 0;
			Position.velocity = 0.2;
			State.sight = 20;
		}
		else
		{
			Position.velocity -= 0.03;
			Position.setAngle(Position.degrees + 44.0);
		}
	}
    
    if(!State.hit && !State.sight && !State.saw)  // Isn't Hit, doesn't see you
    {
		Position.velocity = 0.2;
    }

	Position.move();
	Position.velocity = 0.0;
}

void
head::cycleAnim(void)
{
	animCounter++;
	if(animCounter >= 5)
	{
		animCounter = 0;
		frame++;

		if(State.dead)    // DEAD
		{
			if(frame > Q_DEATH1_END)
			{
				frame = Q_DEATH1_END;
			}

			return;
		}

		if(State.sight)   // SEES YOU
		{
			if(frame > Q_ATTACK_END || frame < Q_ATTACK_START)
			{
				frame = Q_ATTACK_START;
			}

			return;
		}

		if(Position.current.X != Position.last.X ||			// IS MOVING
			Position.current.Y != Position.last.Y)
		{
			if(frame > Q_RUN_END || frame < Q_RUN_START)
			{
				frame = Q_RUN_START;
			}

			return;
		}

		if(frame > Q_STAND_END)
		{
			frame = Q_STAND_START;
		}
	}

}
//////////////////////////////////////////////////////////////////////
void
head::ActionCollide(sprite* otherSprite)
{
	if(!State.dead)
	{
		otherSprite->State.damage = 1;
		State.sight=1;
	}
}
//////////////////////////////////////////////////////////////////////
void
head::ActionBound(void)
{
	Position.current = Position.last;
	Position.setAngle(Position.degrees + 128.0);
	SoundEngine->playSound(NINJA_HURT);
}

//////////////////////////////////////////////////////////////////////
void
head::ActionDamage(void)
{
	hitPoints -= State.damage;
	State.damage = 0;

	if(hitPoints > 0)   // STILL ALIVE
	{
		State.hit = 25;
		SoundEngine->playSound(NINJA_HURT);
	}
}

void
head::ActionNoHP(void)
{
	State.dead = 1000;
	frame = Q_DEATH1_START;
	SoundEngine->playSound(NINJA_DEAD);
}
//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens when see time runs out
//////////////////////////////////////////////////////////////////////
void
head::ActionSight(void)
{
	State.saw = 10;
	Position.velocity = 0.6;
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
mesh* headII::HEADII_MESH = NULL;

headII::headII()
{
	previous = NULL;
	next = NULL;

	if(HEADII_MESH == NULL)
	{
		HEADII_MESH = new mesh(TEXT("msh//headII.msh"));
	}

	Color.setColor(0.7, 0.7, 0.7);
	Mesh = HEADII_MESH;

	frame = Q_RUN_START;
	animCounter = 0;
	State.hit = 0;

	Position.setXY( 0.0,0.0);
//	Position.setBoundBox(-0.16666666, 0.16666666, -0.16666666, 0.16666666);
//	Position.current.radius = 0.666;


	Position.current.radius = 3.5;
	Position.setBoundBox(-0.66666666, 0.33333333, -2.2222222, 0.1666666);  // For full person
	Position.setAngle(0.0);
	Position.velocity = 0;
	Position.move();


	hitPoints = 3;
}

//////////////////////////////////////////////////////////////////////
// All this does now is move the headii.  Will change.
//////////////////////////////////////////////////////////////////////
void
headII::cyclePosition(void)
{
	GFX_FLOAT tmpAngle;

	if(State.hit || State.dead)  //Hit or dead, doesn't move
		{return;}   

	if(!State.sight && 
	Position.current.getOtherFOV(Player->Position.current, 60.0, 16.0))   //Checks to see if you're in sight
	{
		SoundEngine->playSound(NINJA_YELL);
		tmpAngle = Position.current.getOtherAngle(Player->Position.current);
		Position.velocity = 0.2;
		Position.setAngle(tmpAngle);
		State.sight = 30;
	}
    
	if(!State.hit && State.sight)   //Isn't Hit, Just saw you
	{
		Position.velocity = 0.4;
	}

	if(!State.hit && State.saw)
	{
		if(Position.current.getOtherFOV(Player->Position.current, 60.0, 8.0))
		{
			State.saw = 0;
			Position.velocity = 0.2;
			State.sight = 30;
		}
		else
		{
			if(State.sight % 3)
			{
				Position.setAngle(Position.current.degrees + 18.0);
			}
			else
			{
				Position.setAngle(Position.current.degrees = 33.0);
			}
		}
	}
    
    if(!State.hit && !State.sight && !State.saw)  // Isn't Hit, doesn't see you
    {
		Position.velocity = 0.0;
		Position.setAngle(Position.current.degrees + 2.0);
    }

	Position.move();
	Position.velocity = 0.0;
}

//////////////////////////////////////////////////////////////////////
void
headII::ActionBound(void)
{
	Position.velocity = -0.4;
}
/*******************************************************************************
* PLAYER:
* THIS CLASS IMPLEMENTS THE PLAYER INFO
*******************************************************************************/

mesh* player::PLAYER_MESH = NULL;

player::player()
{
	previous = NULL;      // Doesn't belong to a collection
	next = NULL;

	if(PLAYER_MESH == NULL)
	{
		PLAYER_MESH = new mesh(TEXT("msh//player.msh"));
	}

	Mesh = PLAYER_MESH;

	Color.setColor(0.7, 0.7, 0.7);
	frame = Q_STAND_START;

	Position.setXY(0.0, 0.0);
	//Position.setBoundBox(-0.33333333, 0.33333333, -0.1666666, 0.1666666);
	//Position.current.radius = 1.0;

	Position.current.radius = 3.5;
	Position.setBoundBox(-0.66666666, 0.33333333, -2.2222222, 0.1666666);  // For full person

	Position.setAngle(0.0);
	Position.velocity = 0.3;
	Position.move();


	hitPoints = 30;
}

//////////////////////////////////////////////////////////////////////
void
player::cycleAnim(void)
{
	animCounter++;
	if(animCounter >= 5)
	{
		animCounter = 0;
		frame++;

		if(State.dead)
		{
			if(frame > Q_DEATH1_END)
			{
				frame = Q_DEATH1_END;
			}

			return;
		}

		if(Position.current.X != Position.last.X ||			// IS MOVING
			Position.current.Y != Position.last.Y)
		{
			if(frame > Q_RUN_END || frame < Q_RUN_START)
			{
				frame = Q_RUN_START;
			}

			return;
		}

		if(frame > Q_STAND_END)
		{
			frame = Q_STAND_START;
		}
	}

}

void
player::cyclePosition(void)
{
	Position.move();
	Position.velocity = 0.0;
}

//////////////////////////////////////////////////////////////////////
void
player::ActionDamage(void)
{
	hitPoints -= State.damage;
	State.damage = 0;
	State.hit = 12;
	animCounter = 0;
	frame = Q_PAIN1_START;
	SoundEngine->playSound(PLAYER_HURT);
}

//////////////////////////////////////////////////////////////////////
void
player::ActionNoHP(void)
{
	State.dead=32000;

	animCounter = 0;
	frame = Q_DEATH1_START;

	SoundEngine->playSound(PLAYER_DEAD);
}



/*******************************************************************************
* STAR
* A SPRITE THAT ACTS AS A PROJECTILE( ITS A THROWING STAR) THROWN AT ENEMIES.
*******************************************************************************/

mesh* star::STAR_MESH = NULL;

star::star()
{
	previous = NULL;
	next = NULL;

	if(STAR_MESH == NULL)
	{
		STAR_MESH = new mesh(TEXT("msh//star.msh"));
	}

	Mesh = STAR_MESH;

	Color.setColor(0.6, 0.6, 0.6);

	frame = 1;
	hitPoints = 1;

	Position.setXY(0.0,0.0);
	Position.setAngle(0.0);
	Position.velocity = 0.4;
	Position.move();
	Position.current.radius = 0.5;
	Position.setBoundBox(-0.2, 0.2, -0.2, 0.2);
}

//////////////////////////////////////////////////////////////////////
void
star::cycleAnim(void)
{
	if(!State.dead)
	{
		frame++;
		if(frame > 4)
			{frame = 1;}
	}
}

//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
void
star::ActionCollide(sprite* otherSprite)
{
    otherSprite->State.damage = 1;
    State.dead = 1;
}

//////////////////////////////////////////////////////////////////////
void
star::ActionBound(void)
{
	Position.velocity = 0 - Position.velocity;
	Position.move();
	Position.velocity = 0.0;
	State.dead = 250;
}

void
star::ActionOutOfRange(void)
{
	State.dead = 1;
}

void
star::cyclePosition(void)
{
	Position.move();
}


/*******************************************************************************
* PROJECTILES:
* SUPERCLASS OF SPRITE COLLECTION.  THIS IS A GROUP OF PROJECTILES THAT PLAYER
* THROWS AT THE ENEMIES.
*******************************************************************************/
sprite*
projectiles::createNew(sprite_type tmpSprite)
{
	sprite* tmpPointer = NULL;

	switch(tmpSprite)
	{
	case STAR:
		tmpPointer = new star;
		break;

	default:
		GFX_ErrorMessage("Invalid Type. Not a projectile.", "projectiles::createNew()");
		break;
	}

	return tmpPointer;
}

//////////////////////////////////////////////////////////////////////

void
projectiles::collisionRoutine(void)
{
	current->collideCollection(enemySprites);
	//current->collideSprite(playerSprite);
}

void
projectiles::initPointers(void)
{
	enemySprites = (spriteCollection*) voidPointer1;
	playerSprite = (sprite*) voidPointer2;
}
/*******************************************************************************
* ENEMIES:
* SUPERCLASS OF SPRITE COLLECTION.  THIS IS JUST A GROUP OF ENEMIES.
*******************************************************************************/

//////////////////////////////////////////////////////////////////////
// PRIVATE FUNCTION:
// This just NEWs a subclass of the appropriate type per ENUM 
// enemy_type. That way it doesn't have to be hardcoded into 
// routines using this class. 
//////////////////////////////////////////////////////////////////////
sprite*
enemies::createNew(sprite_type tmpSprite)
{
	sprite* tmpPointer = NULL;

	switch(tmpSprite)
	{
	case HEAD:
		tmpPointer = new head;
		tmpPointer->voidPointer1 = projectileSprites;
		tmpPointer->voidPointer2 = playerSprite;
		tmpPointer->initPointers();
		break;

    case HEADII:
		tmpPointer = new headII;
		tmpPointer->voidPointer1 = projectileSprites;
		tmpPointer->voidPointer2 = playerSprite;
		tmpPointer->initPointers();
		break;

	default:
		GFX_ErrorMessage("Invalid Enemy Type", "enemies::createNew()");
		break;
	}

	return tmpPointer;
}

//////////////////////////////////////////////////////////////////////
void
enemies::collisionRoutine(void)
{
	current->collideSprite(playerSprite);
}

//////////////////////////////////////////////////////////////////////
void
enemies::initPointers(void)
{
	playerSprite = (sprite*) voidPointer1;
	projectileSprites = (spriteCollection*) voidPointer2;
}

