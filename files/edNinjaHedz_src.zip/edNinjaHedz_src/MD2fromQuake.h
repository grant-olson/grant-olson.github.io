//
// These are just constants of animation frmaes for MD2's designed for Quake
//

#define	Q_STAND_START	1
#define Q_STAND_END		40

#define Q_RUN_START		41
#define	Q_RUN_END		46

#define Q_ATTACK_START	47
#define Q_ATTACK_END	54

#define	Q_PAIN1_START	55
#define Q_PAIN1_END		58

#define Q_PAIN2_START	59
#define Q_PAIN2_END		62

#define Q_PAIN3_START	63
#define Q_PAIN3_END		66

#define	Q_JUMP_START	67
#define Q_JUMP_END		72

#define Q_FLIPOFF_START	73
#define	Q_FLIPOFF_END		84

#define Q_SALUTE_START	85
#define Q_SALUTE_END	95

#define Q_TAUNT_START	96
#define	Q_TAUNT_END		112

#define Q_WAVE_START	113
#define Q_WAVE_END		123

#define Q_POINT_START	124
#define Q_POINT_END		135

#define	Q_CROUCH_START	136
#define Q_CROUCH_END	154

#define Q_CROUCH_WALK_START	155
#define Q_CROUCH_WALK_END	160

#define Q_CROUCH_ATTACK_START	161
#define Q_CROUCH_ATTACK_END		169

#define Q_CROUCH_PAIN_START	170
#define	Q_CROUCH_PAIN_END	173

#define	Q_CROUCH_DEAD_START	174
#define Q_CROUCH_DEAD_END	178

#define Q_DEATH1_START	179
#define	Q_DEATH1_END		184

#define	Q_DEATH2_START	185
#define Q_DEATH2_END	190

#define Q_DEATH3_START	191
#define Q_DEATH3_END	198
