#include "md2converter.h"

/*********************************************************************
*
* MD2 Converter
* 
* This is just a total hack job so that I can import MD2's into my
* file format.  I had to do some goofy stuff with global constants
* (i'm not sure why) to get it to work
*
* I was having some trouble with Milkshape's MD2 export so I tried
* some other tweaks but it didn't work. (Other Quake viewers couldn't look
* at the exported MD2 files, either)
*
*********************************************************************/


TCHAR	szAppName[] = TEXT("MD2Convert");


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					PSTR szCmdLine, int iCmdShow)
{
	TCHAR		szFileName[MAX_PATH]	= TEXT("\0");
	TCHAR		szTitleName[MAX_PATH]	= TEXT("\0");

	OPENFILENAME ofn;

// FILE COMMON DIALOG INITIALIZATION BASICS
	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= NULL;
	ofn.hInstance			= NULL;
	ofn.lpstrCustomFilter	= NULL;
	ofn.nMaxCustFilter		= 0;
	ofn.nFilterIndex		= 0;
	ofn.lpstrFile			= NULL;
	ofn.nMaxFile			= MAX_PATH;
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= MAX_PATH;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= NULL;
	ofn.Flags				= 0;
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
	ofn.lCustData			= 0L;
	ofn.lpfnHook			= NULL;
	ofn.lpTemplateName		= NULL;


	//MD2 FILE INFO
	//
	MD2header		MD2_HEADER;
	MD2triangle*	MD2_TRIANGLES;
	MD2frame*		MD2_FRAMES;
	MD2texture*		MD2_TEXELS;
	MD2vertex*		MD2_POINTS;
	
	//FILE I/O INFO
	//
	HANDLE	MD2file;
	DWORD	numRead;

	ofn.lpstrFile		= szFileName;
	ofn.lpstrFileTitle	= szTitleName;
	ofn.Flags			= OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
	//file info for lvl files
	ofn.lpstrFilter			= TEXT("Quake 2 Model File\0*.md2\0");
	ofn.lpstrDefExt	= TEXT("md2");

	if(!GetOpenFileName(&ofn))
	{
		return 0;
	}

	//OPEN MD2 FILE
	//
	MD2file = CreateFile(szFileName, GENERIC_READ,
				FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(MD2file == INVALID_HANDLE_VALUE)
	{
		//couldn't create
		GFX_ErrorMessage("unable to load file.", szAppName);
		return FALSE;
	}

	// READ THE FILE HEADER, VERIFY IT'S MD2
	//
	if(!ReadFile(MD2file, &MD2_HEADER, sizeof(MD2header), &numRead, NULL))
	{MessageBox(NULL, TEXT("Unable to Read File Header."), szAppName, NULL);}

	if(MD2_HEADER.ident != IDALIASHEADER)
	{
		GFX_ErrorMessage("Not an MD2 file", szAppName);
		return 0;
	}

	// READ INFO FOR THE TEXTURES
	//
	SetFilePointer(MD2file, MD2_HEADER.ofs_st, NULL, FILE_BEGIN);

	MD2_TEXELS = new MD2texture[MD2_HEADER.num_st];

	if(!ReadFile(MD2file, MD2_TEXELS, sizeof(MD2texture) * MD2_HEADER.num_st , &numRead, NULL))
	{
		GFX_ErrorMessage( "Couldn't Read Texture Info", szAppName);
	}

	// CHREATE OUR MESH DATA
	//
	mesh* tmpMesh;

	tmpMesh = new mesh;

	tmpMesh->frames = MD2_HEADER.num_frames;

	tmpMesh->triangleCount = MD2_HEADER.num_tris;
	tmpMesh->triangleData = new triangleInfo[tmpMesh->triangleCount];

	tmpMesh->texPointCount = MD2_HEADER.num_st;
	tmpMesh->texPointData = new texPointInfo[tmpMesh->texPointCount];

	tmpMesh->pointCount = MD2_HEADER.num_xyz;
	tmpMesh->pointData = new pointInfo[tmpMesh->pointCount * tmpMesh->frames];

	tmpMesh->textureInfo = new GFX_TextureInfo;

	szFileName[0] = '\0';
	szTitleName[0] = '\0';
	ofn.Flags			= OFN_HIDEREADONLY | OFN_FILEMUSTEXIST;
	//file info for lvl files
	ofn.lpstrFilter			= TEXT("Windows Bitmap file\0*.bmp\0");
	ofn.lpstrDefExt	= TEXT("bmp");

	if(GetOpenFileName(&ofn))
	{
		tmpMesh->textureInfo->loadBMP(szFileName);
	}

	// READ TRIANGLE INFORMATION- THIS DOESN'T CHANGE POINTS DO
	// THIS IS A REFERENCE TO WHAT POINTS TO USE
	//
	SetFilePointer(MD2file, MD2_HEADER.ofs_tris, NULL, FILE_BEGIN);

	MD2_TRIANGLES = new MD2triangle[MD2_HEADER.num_tris];

	if(!ReadFile(MD2file, MD2_TRIANGLES, sizeof(MD2triangle) * MD2_HEADER.num_tris, &numRead, NULL))
	{
		GFX_ErrorMessage("Couldn't read triData", szAppName);
	}

	//Triangle Info
	//
	for(int i = 0; i < tmpMesh->triangleCount; i++)
	{
		tmpMesh->triangleData[i].one = MD2_TRIANGLES[i].index_xyz[0];
		tmpMesh->triangleData[i].two = MD2_TRIANGLES[i].index_xyz[2];   // opposite culling order
		tmpMesh->triangleData[i].three = MD2_TRIANGLES[i].index_xyz[1];

		tmpMesh->triangleData[i].texOne = MD2_TRIANGLES[i].index_st[0];
		tmpMesh->triangleData[i].texTwo = MD2_TRIANGLES[i].index_st[2]; // opposite culling order
		tmpMesh->triangleData[i].texThree = MD2_TRIANGLES[i].index_st[1];
	}

	// SET UP FRAME INFO
	//
	MD2_FRAMES = new MD2frame[MD2_HEADER.num_frames];
	MD2_POINTS = new MD2vertex[MD2_HEADER.num_xyz];

	SetFilePointer(MD2file, MD2_HEADER.ofs_frames, NULL, FILE_BEGIN);

	int tmpIndex;

	for(int frames = 0; frames < MD2_HEADER.num_frames; frames++)
	{
		// READ INFO FOR THE  FRAME HEADER
		//
		if(!ReadFile(MD2file, (&MD2_FRAMES[frames]), sizeof(MD2frame) - sizeof(MD2vertex) , &numRead, NULL))
		{
			GFX_ErrorMessage("Couldn't Read Frame Header", szAppName);
		}

		// READ IN POINT INFORMATION.  THIS IS WHERE THE POINTS LIE FOR GIVEN FRAME
		//
		if(!ReadFile(MD2file, MD2_POINTS, sizeof(MD2vertex) * MD2_HEADER.num_xyz, &numRead, NULL))
		{
			GFX_ErrorMessage("Couldn't Read Frame Point Info", szAppName);
		}

		// TRANSLATE THE POINTS TO THEIR FLOATING POINT EQUIVILENT


		for(int i = 0; i < MD2_HEADER.num_xyz; i++)
		{
			tmpIndex = (tmpMesh->pointCount * frames) + i;

#ifndef	MD2
			// MILKSHAPE MD2 ATTEMPT
			tmpMesh->pointData[tmpIndex].x =MD2_FRAMES[frames].scale[0] * (float) MD2_POINTS[i].v[0] * MD2_FRAMES[frames].translate[0];
			tmpMesh->pointData[tmpIndex].z =MD2_FRAMES[frames].scale[1] * (float) MD2_POINTS[i].v[1] * MD2_FRAMES[frames].translate[1];
			tmpMesh->pointData[tmpIndex].y = MD2_FRAMES[frames].scale[2] * (float) MD2_POINTS[i].v[2] * MD2_FRAMES[frames].translate[2];
			tmpMesh->pointData[tmpIndex].w = 1.0;
#else
			// REAL MD2
			tmpMesh->pointData[tmpIndex].z = MD2_FRAMES[frames].scale[0] * (float) MD2_POINTS[i].v[0] * MD2_FRAMES[frames].translate[0];
			tmpMesh->pointData[tmpIndex].x = MD2_FRAMES[frames].scale[1] * (float) MD2_POINTS[i].v[1] * MD2_FRAMES[frames].translate[1];
			tmpMesh->pointData[tmpIndex].y =-( MD2_FRAMES[frames].scale[2] * (float) MD2_POINTS[i].v[2] * MD2_FRAMES[frames].translate[2]);
			tmpMesh->pointData[tmpIndex].w = 1.0;
#endif
			tmpMesh->pointData[tmpIndex].x *= MY_X_SCALE;
			tmpMesh->pointData[tmpIndex].x += MY_X_TRANS;

			tmpMesh->pointData[tmpIndex].y *= MY_Y_SCALE;
			tmpMesh->pointData[tmpIndex].y += MY_Y_TRANS;

			tmpMesh->pointData[tmpIndex].z *= MY_Z_SCALE;
			tmpMesh->pointData[tmpIndex].z += MY_Z_TRANS;
		}

	}

	// THAT'S ALL WE NEED NOW, CLOSE THE MD2 FILE
	CloseHandle(MD2file);

	
	// should load the texture into the mesh
	//
	for(i = 0; i < tmpMesh->texPointCount; i++)
	{
		//Convert to GL range 0.0-1.0 from absolute pixel value

		tmpMesh->texPointData[i].s	= (float) MD2_TEXELS[i].s / (float) MD2_HEADER.skinwidth;
		tmpMesh->texPointData[i].t	= (float) MD2_TEXELS[i].t / (float) MD2_HEADER.skinheight;

		tmpMesh->texPointData[i].s	= (float) MD2_TEXELS[i].s / (float) MD2_HEADER.skinwidth;
		tmpMesh->texPointData[i].t	= (float) MD2_TEXELS[i].t / (float) MD2_HEADER.skinheight;

		tmpMesh->texPointData[i].s	= (float) MD2_TEXELS[i].s / (float) MD2_HEADER.skinwidth;
		tmpMesh->texPointData[i].t	= (float) MD2_TEXELS[i].t / (float) MD2_HEADER.skinheight;
	}

	szFileName[0] = '\0';
	szTitleName[0] = '\0';
	ofn.Flags			= OFN_HIDEREADONLY;
	//file info for lvl files
	ofn.lpstrFilter			= TEXT("Ninja Hed Mesh File(*.msh)\0*.msh\0");
	ofn.lpstrDefExt	= TEXT("msh");

	GetSaveFileName(&ofn);

	// SAVES THE FILE
	tmpMesh->saveFile(szFileName);

	GFX_ErrorMessage("Conversion Complete.", szAppName);
	return 0;
}