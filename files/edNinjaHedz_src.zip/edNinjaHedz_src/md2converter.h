#ifndef	MD2CONV_FILE_SEEN
#define	MD2CONV_FILE_SEEN

#include <windows.h>
#include "gfxTypes.h"
#include "mesh.h"
#include "md2info.h"

// for other format conversions
#define MD2

#ifdef MD2

// TRANSLATES FOR SCALE
#define	MY_X_SCALE	0.004
#define	MY_X_TRANS	0.5
#define MY_Y_SCALE	0.002
#define MY_Y_TRANS	0.0
#define MY_Z_SCALE	0.005
#define MY_Z_TRANS	0.25

#else   // TRIAL MD2 FROM MILKSHAPE

#define	MY_X_SCALE	0.004
#define	MY_X_TRANS	0.0
#define MY_Y_SCALE	0.002
#define MY_Y_TRANS	0.225
#define MY_Z_SCALE	0.005
#define MY_Z_TRANS	0.0

#endif
// TRANSLATES FOR MS3 FORMAT

#endif

