//
//  The Win32 native version of the test level
//

#include "editor.h"
#include "file_io.h"
#include "windowsx.h"

// CRACKED WINDOWS MESSAGES.
void Cls_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);		//WM_COMMAND
void Cls_OnKey(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags);	//WM_KEYDOWN



// MAIN ENGINE POINTERS- STANDARD GLOBALS
world*				World		= NULL;			// physical world struct
sprite*				Player		= NULL;			// PLAYER info
spriteCollection*	Enemies		= NULL;		// ENEMY stack
spriteCollection*	Projectiles	= NULL;	// PROJECTILE stack
soundEngine*		SoundEngine	= NULL;		// Sound Engine
preferences			Prefs;

// ENGINE GLOBALS
bool	drawOrNot	= TRUE;		// really draw or cycle without drawing?

// EDITOR GLOBAL INFO
bool	EditOn		= FALSE;			// EDIT MODE on
bool	PrimitiveOn	= FALSE;			// PRIMITIVE is BEING DRAWN
bool	addRect		= FALSE;			// PRIMITIVE is ADDITIVE
bool	deleteRect	= FALSE;			// PRIMITIVE is SUBTRACTIVE

int		frameCount	= 0;				// counts FRAMES PER SECOND
int		secondCount = 0;				// counts Seconds for FULLSCREEN MODE

vector	playerPos;						// holds the position PLAYER starts level at
vector	editPos;						// holds edit cursor
leaf	editLeaf;						// holds current leaf definition

corners editPrimitive;					// holds Primitive area before it's created
GLfloat editZoomDistance = 24.0;		// holds the size of the edit screen

// ENEMY ARRAY
enemyInfo*	editEnemies[MAX_ENEMIES];
int			enemyCount = 0;

// CURRENT INFO
int	currentLight = 0;
int currentEnemy = 0;

//WINDOWS GLOBALS
OPENFILENAME ofn;						// for common dialog FILES
HINSTANCE	hInstance;					
HWND		hDlgCurrentTexture = NULL;	// Modeless Dialog in edit mode

// WINDOWS STRINGS
TCHAR		szAppName[]				= TEXT("EDninjaHed");
TCHAR		szFileName[MAX_PATH]	= TEXT("\0");
TCHAR		szTitleName[MAX_PATH]	= TEXT("\0");
TCHAR		szTextureFile[MAX_PATH]	= TEXT("\0");

int	music[5] = {7, 4, 0, 0, 0};

HGLRC	getGLcontext(HDC hdc);
void	setMenuPrefs(HWND hwnd);
void	makeFullscreen(int Width, int Height, int BitDepth);


// WINDOW SIZE
int		cxWindow = 0;
int		cyWindow = 0;

////////////////////////////////////////////////////////////////////////////////
// WinMain
// Initializes the Editor Version of the level
////////////////////////////////////////////////////////////////////////////////
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					PSTR szCmdLine, int iCmdShow)
{
	// MAIN WINDOW VARS
	HWND			hwnd;
	MSG				msg;
	WNDCLASS		wndclass;

	// DEVICE CONTEXT VARS
	HDC				hdc;
	HGLRC			hrc;		//OpenGL Context

	HWND			hDlgStatus = NULL;
	hDlgStatus = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_STATUS), NULL, NULL);

	SetDlgItemText(hDlgStatus, IDC_STATUS, "Loading Preferences...");

	// LOAD DEFAULT SETTINGS

	// PROCESS COMMAND LINE
	parseWinCmdLine(szCmdLine);

	WriteToLogFile( "Starting edNinjaHedz...");
	WriteToLogFile( ".");

	writePrefsToLogFile();

	SetDlgItemText(hDlgStatus, IDC_STATUS, "Initializing Window...");

	// set window width
	if(Prefs.lowRes){cxWindow /= 2;}

	// set window height
	if(!Prefs.lowRes)
	{
		cyWindow = GL_WINDOW_HEIGHT;
		cxWindow  = GL_WINDOW_WIDTH;
	}
	else
	{
		cyWindow = 240;
		cxWindow = 320;
	}

	// IF ITS WINDOWED, WE NEED TO ACCOUNT FOR THAT IN WINDOW SIZE
	if(!Prefs.fullscreen)		
	{
		cxWindow += GetSystemMetrics(SM_CXBORDER) * 2;

		cyWindow += GetSystemMetrics(SM_CYMENU);
		cyWindow += GetSystemMetrics(SM_CYCAPTION);
		cyWindow += GetSystemMetrics(SM_CYBORDER) * 2;
	}

	// WNDCLASS INTITIALIZATION
	wndclass.style			= CS_HREDRAW | CS_VREDRAW ;
	wndclass.lpfnWndProc	= WndProc;
	wndclass.cbClsExtra		= 0;
	wndclass.cbWndExtra		= 0;
	wndclass.hInstance		= hInstance;
	wndclass.hIcon			= LoadIcon (NULL, szAppName);
	wndclass.hCursor		= LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground	= (HBRUSH) GetStockObject (BLACK_BRUSH);
	wndclass.lpszMenuName	= szAppName;
	wndclass.lpszClassName	= szAppName;


	if(Prefs.fullscreen)	// NO MENU ON FULL SCREEN
	{
		wndclass.lpszMenuName	= NULL;
	}

	SetDlgItemText(hDlgStatus, IDC_STATUS, "Creating Window...");

	//REGISTER THE CLASS
	if (!RegisterClass(&wndclass))
	{
		MessageBox (NULL, TEXT("Couldn't Register wndclass!!!"), szAppName, MB_ICONERROR);
		return 0;
	}

	// CREATE THE WINDOW

	hwnd = CreateWindow (szAppName, TEXT("NinjaHedKillaz test level!"),
				Prefs.fullscreen ? WS_POPUP : (WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX) ,
				0, 0,
				cxWindow, cyWindow,
				NULL, NULL, hInstance, NULL);

	// FILE COMMON DIALOG INITIALIZATION BASICS,
	// JUST SO WE CAN GET IT OUT OF THE WAY
	// (needed hwnd- thats why it's here)
	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= hwnd;
	ofn.hInstance			= NULL;
	ofn.lpstrCustomFilter	= NULL;
	ofn.nMaxCustFilter		= 0;
	ofn.nFilterIndex		= 0;
	ofn.lpstrFile			= NULL;
	ofn.nMaxFile			= MAX_PATH;
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= MAX_PATH;
	ofn.lpstrInitialDir		= NULL;
	ofn.lpstrTitle			= NULL;
	ofn.Flags				= 0;
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
	ofn.lCustData			= 0L;
	ofn.lpfnHook			= NULL;
	ofn.lpTemplateName		= NULL;

	// MAKE FULLSCREEN IF NECESSARY
	if(Prefs.fullscreen)
	{
		SetDlgItemText(hDlgStatus, IDC_STATUS, "Making Fullscreen...");

		makeFullscreen(cxWindow, cyWindow, Prefs.thirtyTwoBit ? 32 : 16);

		SetDlgItemText(hDlgStatus, IDC_TITLE, "Loading...");
	}

	//INIT GL CONTEXT
	SetDlgItemText(hDlgStatus, IDC_STATUS, "Initializing OpenGL Settings...");

	hdc = GetDC(hwnd);
	hrc = getGLcontext(hdc);

	if(!hrc)
	{
		MessageBox(NULL, TEXT("Couldn't find create an OpenGL Context. \n Initialization Failed"), 
				szAppName, MB_ICONERROR);
		goto EXIT_UNDO_GL;
	}

	// MAKE IT CURRENT, INITIALIZE
	wglMakeCurrent(hdc, hrc);

	if( !strcmp("GDI Generic", (char *) glGetString(GL_RENDERER) ) )
	{
		MessageBox(NULL, TEXT("Warning! \n\n No 3-D Hardware Detected. \n Software Rendering is not Recommended."), 
				szAppName, MB_ICONERROR);
	}

	// LOG GL INFO
	WriteToLogFile( (char *) glGetString(GL_VENDOR) );
	WriteToLogFile( (char *) glGetString(GL_RENDERER) );
	WriteToLogFile( (char *) glGetString(GL_VERSION) );
	// I'm not using extentions, no point in logging.
	//WriteToLogFile( (char *) glGetString(GL_EXTENSIONS) );
	WriteToLogFile( ".");
	
	initGL();

	SetDlgItemText(hDlgStatus, IDC_STATUS, "Initializing Editor Settings...");

	//INTITIALIZE EDITOR INFO
	editPos.X = 0.0;
	editPos.Y = 0.0;

	editPrimitive.x1 = editPos.X;
	editPrimitive.x2 = editPos.X + 1.0;
	editPrimitive.y1 = editPos.Y;
	editPrimitive.y2 = editPos.Y + 1.0;

	editLeaf.Color.setColor(0.2, 0.2, 0.2);
	editLeaf.height = 3.0;
	editLeaf.textureIndex = 2;
	editLeaf.flags = LF_NORTH_WALL | LF_SOUTH_WALL | LF_EAST_WALL |
		LF_WEST_WALL | LF_TOP_WALL;

	//INITIALIZE THE SOUND ENGINE
	SoundEngine = new soundEngine;
	SoundEngine->initSoundEngine(hwnd);
	SoundEngine->setCDplaylist(music);
	SoundEngine->playNextCDtrack();

	SetDlgItemText(hDlgStatus, IDC_STATUS, "Loading Level...");

	// LOAD DEFAULT LEVEL
	if(!loadFile(TEXT("default.lvl")) )
	{
		//couldn't load default level
		MessageBox(NULL, TEXT("Unable to load default level.  You must create New Level."),
				szAppName, MB_OK);
		
		//Try to create a new level
		if(!DialogBox (hInstance, MAKEINTRESOURCE(IDD_NEW_FILE), hwnd, dlgNewFileProc))
		{
			goto EXIT_UNDO_GL;
		}
	}

	initLevel();

	World->setClipPlane(Prefs.clip);
	setupFog();

	DestroyWindow(hDlgStatus);

	// STANDARD WINDOWS JUNK, SHOW WINDOW, MESSAGE LOOP
	ShowWindow(hwnd, iCmdShow);
	UpdateWindow(hwnd);

	while(TRUE)  // endless loop until we get a WM_QUIT message
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if (hDlgCurrentTexture == NULL || !IsDialogMessage(hDlgCurrentTexture, &msg))
			{
				if (msg.message == WM_QUIT){break;}
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
		else
		{
			// draw the junk if windows doesn't need to do anything
			displayGL();
			frameCount++;

			// IF THIS WORKS I'LL MOVE IT TO THE displayGL() routine
			if(!Prefs.skipframe || drawOrNot || EditOn)
			{
				SwapBuffers(hdc);
			}

			// LOG ERRORS IF THEY EXIST AND LOGGING IS ON
			if(Prefs.log)
			{
				GLenum	GLerrorCode;
				GLerrorCode = glGetError();

				if(GLerrorCode != GL_NO_ERROR)
				{
					do  // WHILE ERRORS STILL EXIST
					{
						WriteToLogFile( (char*) gluErrorString(GLerrorCode) );
						GLerrorCode = glGetError();
					}
					while(GLerrorCode != GL_NO_ERROR);
				}
			}
		}
	}

	//CLEAN EVERYTHING UP
EXIT_UNDO_LEVEL:
	delete World;
	delete Enemies;
	delete Player;
	delete Projectiles;

EXIT_UNDO_GL:
	wglMakeCurrent(NULL, NULL);
	ReleaseDC(hwnd, hdc);
	wglDeleteContext(hrc);

	delete SoundEngine;



EXIT_UNDO_VIDEO:

	if(Prefs.fullscreen)
	{
		ChangeDisplaySettings(NULL, 0);
	}

	DestroyWindow(hwnd);

	return msg.wParam;
}

////////////////////////////////////////////////////////////
//
// Main Window Procedure Loop
//
////////////////////////////////////////////////////////////

LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	
	static TCHAR		szTitleText[40]= TEXT("Blah blah blah");
	static int			currentTrack = 7;

	switch(message)
	{
	case WM_CREATE:
		hInstance = ((LPCREATESTRUCT) lParam)->hInstance;
		setMenuPrefs(hwnd);
		SetTimer(hwnd, 1, 1000, NULL);   //Once Every Second, Framerate counter
		return 0;

	HANDLE_MSG(hwnd, WM_COMMAND, Cls_OnCommand);
	HANDLE_MSG(hwnd, WM_KEYDOWN, Cls_OnKey);

#if 0
	case WM_ACTIVATEAPP:
		// ALLOW US TO SWITCH APPS
		if(Prefs.fullscreen)
		{
			if(wParam)
			{
				makeFullscreen(cxWindow, cyWindow, Prefs.thirtyTwoBit ? 32 : 16);
			}
			else
			{
				ChangeDisplaySettings(NULL, 0);
			}
		}
		return 0;

#endif

	case WM_TIMER:
		secondCount++;

		if(!EditOn && !Prefs.fullscreen)
		{
			wsprintf(szTitleText, TEXT("%s - [%s] - %03d fps"),  szAppName,
				szTitleName[0] == TEXT('\0') ? NO_FILE_LOADED : szTitleName , frameCount);
			SetWindowText(hwnd, szTitleText);
			frameCount = 0;
		}
		return 0;

	case MM_MCINOTIFY:
		// CD PLAYER
		MessageBox(hwnd, TEXT("Notify Message Sent"), szAppName, NULL);
		SoundEngine->playNextCDtrack();
		break;

	case WM_DESTROY:
		wsprintf(szTitleText, "PROGRAM DONE AFTER %05d SECONDS- AVERAGE FPS %04d",
			secondCount, Prefs.fullscreen ? frameCount / secondCount : frameCount);
		WriteToLogFile(szTitleText);
		WriteToLogFile(".");
		WriteToLogFile(".");
		KillTimer (hwnd, 1);
		PostQuitMessage(0);
		return 0;

	default:
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

//////////////////////////////////////////////////////////////////////
//
// Message Cracked function for WM_COMMAND message from WinProc
//
//////////////////////////////////////////////////////////////////////
void Cls_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	// for dialogs
	light		tempEditLight;
	enemyInfo	tempEditEnemy;
	vector		tempPlayerPos;
	GFX_TextureInfo loadTexture;

	TCHAR	dummyText[256];  // for various messageboxes

	HMENU	hMenu = GetMenu(hwnd);

	switch (id)
	{
	case IDM_FILE_NEW:

		if(!EditOn){SendMessage(hwnd, WM_COMMAND, IDM_EDIT_EDITMODE, 0);}
		DialogBox (hInstance, MAKEINTRESOURCE(IDD_NEW_FILE), hwnd, dlgNewFileProc);
		//fix menu if necessary
		CheckMenuItem(hMenu, IDM_VIDEO_CEILING, World->Quadtree->ceiling ? MF_CHECKED : MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_FLOOR, World->Quadtree->floor ? MF_CHECKED : MF_UNCHECKED);
			
		// Make sure it's untitled so we don't overwrite file
		szFileName[0]  = '\0';
		szTitleName[0] = '\0';
		break;

	case IDM_FILE_SAVE :
		if(szFileName[0])    // file exists
		{
			createFile(szFileName);
			return;
		}
		//else filename doesn't exist-  use SAVE AS

	case IDM_FILE_SAVE_AS :
		ofn.hwndOwner		= hwnd;
		ofn.lpstrFile		= szFileName;
		ofn.lpstrFileTitle	= szTitleName;
		ofn.Flags			= OFN_HIDEREADONLY | OFN_CREATEPROMPT;
		//file info for lvl files
		ofn.lpstrFilter			= TEXT("NinjaHedEditor Files (*.lvl)\0*.lvl\0");
		ofn.lpstrDefExt			= TEXT("lvl");
			
		if(GetSaveFileName(&ofn))
		{
			createFile(szFileName);
		}
		return;

	case IDM_FILE_LOAD:
		ofn.hwndOwner		= hwnd;
		ofn.lpstrFile		= szFileName;
		ofn.lpstrFileTitle	= szTitleName;
		ofn.Flags			= OFN_HIDEREADONLY;
		// file info for lvl files
		ofn.lpstrFilter			= TEXT("NinjaHedEditor Files (*.lvl)\0*.lvl\0");
		ofn.lpstrDefExt			= TEXT("lvl");

		if(GetOpenFileName(&ofn))
		{
			if(!EditOn)    // put in edit mode
				{SendMessage(hwnd, WM_COMMAND, IDM_EDIT_EDITMODE, 0);}

			cleanUpLevel();	//erase old junk
			cleanUpEditor();

			if(World != NULL)
			{
				delete World;
				World = NULL;
			}

			if(!loadFile(szFileName))
			{
				MessageBox(NULL, TEXT("Error loading this file!"), szAppName, MB_OK);
				SendMessage(hwnd, WM_COMMAND, IDM_FILE_LOAD, 0);
			}
		}
		return;

	case IDM_FILE_EXIT :
		SendMessage(hwnd, WM_CLOSE, 0, 0);
		return;

	case IDM_EDIT_EDITMODE:
		if(EditOn)
		{
			CheckMenuItem(hMenu, IDM_EDIT_EDITMODE, MF_UNCHECKED);
			EditOn = FALSE;

			EnableMenuItem(hMenu, IDM_EDIT_ADD_PRIMITIVE, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_WORLD, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_CLEAR_AREA, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_ZOOM_IN, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_ZOOM_OUT, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_LIGHT, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_ENEMY, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_PLAYER, MF_GRAYED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_TEXTURE, MF_GRAYED);

			if(hDlgCurrentTexture != NULL)
			{SendMessage(hDlgCurrentTexture, WM_CLOSE, 0, 0);}

			initLevel();
			SoundEngine->continueCDplayer();

			SendMessage(hwnd, WM_COMMAND, IDM_VIDEO_CLIP_MEDIUM, 0);
		}
		else
		{
			CheckMenuItem(hMenu, IDM_EDIT_EDITMODE, MF_CHECKED);
			EditOn = TRUE;
			editTitleText(hwnd);  // change title

			EnableMenuItem(hMenu, IDM_EDIT_ADD_PRIMITIVE, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_WORLD, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_CLEAR_AREA, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_ZOOM_IN, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_ZOOM_OUT, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_LIGHT, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_ENEMY, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_PLAYER, MF_ENABLED);
			EnableMenuItem(hMenu, IDM_EDIT_ADD_TEXTURE, MF_ENABLED);

			SoundEngine->pauseCDplayer();

			// add texture box
			if(hDlgCurrentTexture == NULL)
			{
				hDlgCurrentTexture = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_CURRENT_TEXTURE),
									hwnd, dlgCurrentTextureProc);
			}

			World->Camera.place(editPos);
			cleanUpLevel();
		}
		return;
			
	case IDM_EDIT_ZOOM_IN:
		editZoomDistance /= 2;
		return;

	case IDM_EDIT_ZOOM_OUT:
		editZoomDistance *= 2;
		return;
			
	case IDM_EDIT_ADD_PRIMITIVE:
		DialogBox (hInstance, MAKEINTRESOURCE(IDD_ADD_PRIMITIVE), hwnd, dlgAddPrimitiveProc);
		break;

	case IDM_EDIT_CLEAR_AREA:
		DialogBox (hInstance, MAKEINTRESOURCE(IDD_CLEAR_AREA), hwnd, dlgClearAreaProc);
		break;

	case IDM_EDIT_WORLD:
		DialogBox (hInstance, MAKEINTRESOURCE(IDD_EDIT_WORLD), hwnd, dlgEditWorldProc);
		CheckMenuItem(hMenu, IDM_VIDEO_CEILING, World->Quadtree->ceiling ? MF_CHECKED : MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_FLOOR, World->Quadtree->floor ? MF_CHECKED : MF_UNCHECKED);
		break;

	case IDM_EDIT_ADD_LIGHT:
		if(EditOn)
		{
			tempEditLight.Position.X = editPos.X;
			tempEditLight.Position.Y = editPos.Y;

			if(DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_ADD_LIGHT), hwnd,
							dlgAddLightProc, (LPARAM) &tempEditLight) ) // returns non-0 OK
			{
				World->addNewLight(tempEditLight);
			}
		}
		break;

	case IDM_EDIT_ADD_ENEMY:
		if(EditOn)
		{
			tempEditEnemy.Position.X = editPos.X;
			tempEditEnemy.Position.Y = editPos.Y;

			if(DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_ADD_ENEMY), hwnd,
								dlgAddEnemyProc, (LPARAM) &tempEditEnemy) ) // returns non-0 OK
			{
				newEnemy(tempEditEnemy);
			}
		}
		break;

	case IDM_EDIT_PLAYER:
		tempPlayerPos.X = editPos.X;
		tempPlayerPos.Y = editPos.Y;

		if(DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_SET_PLAYER), hwnd,
			dlgSetPlayerProc, (LPARAM) &tempPlayerPos) ) // returns non-0 OK
		{
			playerPos.X = tempPlayerPos.X;
			playerPos.Y = tempPlayerPos.Y;
			playerPos.setAngle(tempPlayerPos.degrees);
		}
		break;

	case IDM_EDIT_ADD_TEXTURE:
		ofn.hwndOwner		= hwnd;
		ofn.lpstrFile		= szTextureFile;
		ofn.lpstrFileTitle	= NULL;
		ofn.Flags			= OFN_HIDEREADONLY;
		//file info for bmp files
		ofn.lpstrFilter			= TEXT("Windows Bitmap Files (*.bmp)\0*.bmp\0");
		ofn.lpstrDefExt			= TEXT("bmp");

		GetOpenFileName(&ofn);
			
		if(szTextureFile[0] != '\0')
		{
			loadTexture.loadBMP(szTextureFile);
			World->addNewTexture(loadTexture);
		}
		break;
	
	case IDM_VIDEO_CLIP_NEAR:
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_NEAR, MF_CHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_MEDIUM, MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_FAR, MF_UNCHECKED);

		World->setClipPlane(CLIP_NEAR);
		setupFog();
		return;

	case IDM_VIDEO_CLIP_MEDIUM:
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_NEAR, MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_MEDIUM, MF_CHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_FAR, MF_UNCHECKED);

		World->setClipPlane(CLIP_MEDIUM);
		setupFog();
		return;

	case IDM_VIDEO_CLIP_FAR:
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_NEAR, MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_MEDIUM, MF_UNCHECKED);
		CheckMenuItem(hMenu, IDM_VIDEO_CLIP_FAR, MF_CHECKED);

		World->setClipPlane(CLIP_FAR);
		setupFog();
		return;

	case IDM_VIDEO_RES:
		if(Prefs.lowRes)
		{
			CheckMenuItem(hMenu, IDM_VIDEO_RES, MF_UNCHECKED);
			Prefs.lowRes = FALSE;
		}
		else
		{
			CheckMenuItem(hMenu, IDM_VIDEO_RES, MF_CHECKED);
			Prefs.lowRes = TRUE;
		}
		return;

	case IDM_VIDEO_32BIT:
		if(Prefs.thirtyTwoBit)
		{
			CheckMenuItem(hMenu, IDM_VIDEO_32BIT, MF_UNCHECKED);
			Prefs.thirtyTwoBit = FALSE;
		}
		else
		{
			CheckMenuItem(hMenu, IDM_VIDEO_32BIT, MF_CHECKED);
			Prefs.thirtyTwoBit = TRUE;
		}
		return;

	case IDM_VIDEO_FLOOR :
		if(Prefs.realFloor)
		{
			CheckMenuItem(hMenu, IDM_VIDEO_FLOOR, MF_UNCHECKED);
			Prefs.realFloor = FALSE;
		}
		else
		{
			CheckMenuItem(hMenu, IDM_VIDEO_FLOOR, MF_CHECKED);
			Prefs.realFloor = TRUE;
		}
		return;

	case IDM_VIDEO_FOG:
		if(Prefs.fog)
		{
			CheckMenuItem(hMenu, IDM_VIDEO_FOG, MF_UNCHECKED);
			Prefs.fog = FALSE;
		}
		else
		{
			CheckMenuItem(hMenu, IDM_VIDEO_FOG, MF_CHECKED);
			Prefs.fog = TRUE;
		}
		return;

	case IDM_VIDEO_SKIPFRAME:
		if(Prefs.skipframe)
		{
			CheckMenuItem(hMenu, IDM_VIDEO_SKIPFRAME, MF_UNCHECKED);
			Prefs.skipframe = FALSE;
			drawOrNot = TRUE;
		}
		else
		{
			CheckMenuItem(hMenu, IDM_VIDEO_SKIPFRAME, MF_CHECKED);
			Prefs.skipframe = TRUE;
		}
		return;

	case IDM_HELP_ABOUT:
		wsprintf(dummyText, 
			TEXT("NINJA HED LEVEL EDITOR\n\n Build %s - %s               \n\n Copyright Logistical Games \n\n http://members.bellatlantic.net/~olsongt\n mailto:logstx@bellatlantic.net\n"),
						__DATE__, __TIME__);
		MessageBeep(MB_OK);
		MessageBox(hwnd, dummyText, szAppName, MB_ICONINFORMATION);
		return;
	}

	return;
}

//////////////////////////////////////////////////////////////////////
//
// Message Cracked function for WM_KEYDOWN message from WInProc
//
//////////////////////////////////////////////////////////////////////
void Cls_OnKey(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags)
{
	int		iState; // for keystrokes

	if(!EditOn)
	{return;}

	switch(vk)
	{
	case VK_F1:				//Raytrace- debug mode
		glDisable(GL_CULL_FACE);            
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		break;

	case VK_F2:				//Normal Mode
		glEnable(GL_DEPTH_TEST);
		glShadeModel(GL_FLAT);
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHTING);
		glDisable(GL_COLOR_MATERIAL);
		glEnable(GL_CULL_FACE);
		glCullFace(GL_BACK);      
		glPolygonMode(GL_FRONT, GL_FILL);			
		break;

	case VK_F5:
		//add light
		iState = GetKeyState (VK_TAB);

		if(iState < 0)    //INCREMENT CURRENT LIGHT
		{
			currentLight++;
			if(currentLight >= World->lightCount){currentLight = 0;}

			break;
		}

		iState = GetKeyState(VK_SHIFT);

		if(iState < 0)	//EDIT CURRENT
		{
			light tmpLight, *tmpPointer;

			tmpPointer = World->getPtrToLight(currentLight);
			tmpLight = *tmpPointer;

			if(DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_ADD_LIGHT), hwnd,
						dlgAddLightProc, (LPARAM) &tmpLight) ) // returns non-0 OK
			{
				*tmpPointer = tmpLight;
			}
				
			break;
		}

		iState = GetKeyState(VK_CONTROL);

		if(iState < 0)    // DELETE CURRENT
		{
			World->deleteLight(currentLight);
			if(currentLight >= World->lightCount  && World->lightCount != 0)
				{currentLight = World->lightCount - 1;}
			break;
		}
		

		SendMessage(hwnd, WM_COMMAND, IDM_EDIT_ADD_LIGHT, 0);

		break;

	case VK_F6:
		
		iState = GetKeyState (VK_TAB);

		if(iState < 0)	//INCREMENT ENEMY COUNTER
		{
			currentEnemy++;
			if(currentEnemy >= enemyCount){currentEnemy = 0;}

			break;
		}
				
		iState = GetKeyState(VK_SHIFT);

		if(iState < 0) // EDIT CURRENT ENEMY
		{
			enemyInfo tmpEnemy, *tmpPointer;

			tmpPointer = editEnemies[currentEnemy];
			tmpEnemy = *tmpPointer;

			if(DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_ADD_ENEMY), hwnd,
				dlgAddEnemyProc, (LPARAM) &tmpEnemy) ) // returns non-0 OK
			{
				*tmpPointer = tmpEnemy;
			}

			break;
		}

		iState = GetKeyState(VK_CONTROL);

		if(iState < 0)
		{
			deleteEnemy(currentEnemy);

			break;
		}

		// ADD NEW ENEMY

		SendMessage(hwnd, WM_COMMAND, IDM_EDIT_ADD_ENEMY, 0);

		break;

	case VK_F7:
			//reposition player
		SendMessage(hwnd, WM_COMMAND, IDM_EDIT_PLAYER, 0);
		break;

	case VK_LEFT:
		editPos.X -= 1.0;

		if(PrimitiveOn)
		{
			if(editPos.X < editPrimitive.x1)
			{editPrimitive.x1 -= 1.0;}
			else
			{editPrimitive.x2 -= 1.0;}
		}
		editTitleText(hwnd);
			
		break;

	case VK_RIGHT:

		editPos.X += 1.0;

		if(PrimitiveOn)
		{
			if((editPos.X + 1) > editPrimitive.x2)
			{editPrimitive.x2 += 1.0;}
			else
			{editPrimitive.x1 += 1.0;}
		}
		editTitleText(hwnd);

		break;

	case VK_UP:
		editPos.Y -= 1.0;

		if(PrimitiveOn)
		{
			if(editPos.Y < editPrimitive.y1)
			{editPrimitive.y1 -= 1.0;}
			else
			{editPrimitive.y2 -= 1.0;}
		}
		editTitleText(hwnd);

		break;

	case VK_DOWN:
		editPos.Y += 1.0;

		if(PrimitiveOn)
		{
			if((editPos.Y + 1) > editPrimitive.y2)
			{editPrimitive.y2 += 1.0;}
			else
			{editPrimitive.y1 += 1.0;}
		}
		editTitleText(hwnd);

		break;

	case VK_RETURN:
		if(PrimitiveOn)
		{
			PrimitiveOn = FALSE;

			if(addRect)
			{
				World->addPrimitive(editPrimitive, editLeaf);
				addRect = FALSE;
			}

			if(deleteRect)
			{
				World->deleteArea(editPrimitive);
				deleteRect = FALSE;
			}
			editTitleText(hwnd);  // change title
		}
		else
		{
			PrimitiveOn = TRUE;
			addRect = TRUE;

			editPrimitive.x1 = editPos.X;
			editPrimitive.x2 = editPos.X + 1.0;
			editPrimitive.y1 = editPos.Y;
			editPrimitive.y2 = editPos.Y + 1.0;
			editTitleText(hwnd);  // change title
		}
		return;

	case VK_INSERT:
		if(!PrimitiveOn)
		{
			PrimitiveOn = TRUE;
			addRect = TRUE;

			editPrimitive.x1 = editPos.X;
			editPrimitive.x2 = editPos.X + 1.0;
			editPrimitive.y1 = editPos.Y;
			editPrimitive.y2 = editPos.Y + 1.0;

			editTitleText(hwnd);  // change title
		}
		return;

	case VK_DELETE:
		if(!PrimitiveOn)
		{
			PrimitiveOn = TRUE;
			deleteRect = TRUE;

			editPrimitive.x1 = editPos.X;
			editPrimitive.x2 = editPos.X + 1.0;
			editPrimitive.y1 = editPos.Y;
			editPrimitive.y2 = editPos.Y + 1.0;

			editTitleText(hwnd);  // change title
		}
		return;

	case VK_ESCAPE:
		if(PrimitiveOn)
		{
			PrimitiveOn = FALSE;
			addRect		= FALSE;
			deleteRect	= FALSE;
			editTitleText(hwnd);
		}
		break;
	}

	return;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Sets up an open GL context
// [PARAMETERS]
//   hdc- the Device Context to set GL context to
// [RETURNS]
//   HGLRC- the GL context
// [NOTES]
//   The returned GL context must be destroyed before the program terminates
//////////////////////////////////////////////////////////////////////
HGLRC
getGLcontext(HDC hdc)
{
// OPEN GL CONTEXT INTIALIZATION
	int				pf;        // Enumerated PixelFormat.

	static PIXELFORMATDESCRIPTOR
		pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),		// Size Of This Pixel Format Descriptor
		1,						// Version Number (?)
		PFD_DRAW_TO_WINDOW |	// Format Must Support Window
		PFD_SUPPORT_OPENGL |	// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,		// Must Support Double Buffering
		PFD_TYPE_RGBA,			// Request An RGBA Format
		32,						// Select Color Depth
		0, 0, 0, 0, 0, 0,		// Color Bits Ignored (?)
		8,						// 8 bit Alpha Buffer
		0,						// Shift Bit Ignored (?)
		0,						// No Accumulation Buffer
		0, 0, 0, 0,				// Accumulation Bits Ignored (?)
		24,						// 24 Bit Z-Buffer (Depth Buffer)  
		0,						// No Stencil Buffer
		0,						// No Auxiliary Buffer (?)
		PFD_MAIN_PLANE,			// Main Drawing Layer
		0,						// Reserved (?)
		0, 0, 0					// Layer Masks Ignored (?)
	};

	// SET TO 16 BIT IF NECESSARY
	if( !Prefs.thirtyTwoBit )
	{
		pfd.cColorBits = 16;
		pfd.cDepthBits = 16;
	}

	// GET RID OF ALPHA
	if(!Prefs.alpha)
	{
		pfd.cAlphaBits	= 0;
	}

	// get Pixel Closest Format Descriptor to Optimum one defined
	pf = ChoosePixelFormat(hdc, &pfd);

	if(pf == 0)
	{
		MessageBox(NULL, TEXT("Couldn't find  a close enough PFD. \n Initialization Failed.")
					, szAppName, MB_ICONERROR);
		return 0;
	}
	
	SetPixelFormat(hdc, pf, &pfd);

	// get the OpenGL Rendering Context
	return wglCreateContext(hdc);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This syncs the PREFERENCES MENU settings with the user preferences
//   defined in PREFS
//////////////////////////////////////////////////////////////////////
void
setMenuPrefs(HWND hwnd)
{
	HMENU hmenu = GetMenu(hwnd);

	CheckMenuItem(hmenu, IDM_VIDEO_FLOOR, 
					Prefs.realFloor ? MF_CHECKED : MF_UNCHECKED);

	CheckMenuItem(hmenu, IDM_VIDEO_RES, 
					Prefs.lowRes ? MF_CHECKED : MF_UNCHECKED);

	CheckMenuItem(hmenu, IDM_VIDEO_32BIT,
					Prefs.thirtyTwoBit ? MF_CHECKED : MF_UNCHECKED);

	CheckMenuItem(hmenu, IDM_VIDEO_SKIPFRAME, 
					Prefs.skipframe ? MF_CHECKED : MF_UNCHECKED);

	CheckMenuItem(hmenu, IDM_VIDEO_FOG, 
					Prefs.fog ? MF_CHECKED : MF_UNCHECKED);

	switch(Prefs.clip)
	{
	case CLIP_NEAR:
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_NEAR, MF_CHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_MEDIUM, MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_FAR, MF_UNCHECKED);
		break;

	case CLIP_MEDIUM:
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_NEAR, MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_MEDIUM, MF_CHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_FAR, MF_UNCHECKED);
		break;

	case CLIP_FAR:
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_NEAR, MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_MEDIUM, MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_FAR, MF_CHECKED);
		break;

	default:
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_NEAR, MF_UNCHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_MEDIUM, MF_CHECKED);
		CheckMenuItem(hmenu, IDM_VIDEO_CLIP_FAR, MF_UNCHECKED);
		break;
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This makes the window fullscreen
//////////////////////////////////////////////////////////////////////
void
makeFullscreen(int Width, int Height, int BitDepth)
{
	//MAKE FULLSCREEN BEFORE WE GET PFD
	DEVMODE dmScreenSettings;				
	memset(&dmScreenSettings,0,sizeof(dmScreenSettings));
	
	dmScreenSettings.dmSize			= sizeof(dmScreenSettings);
	dmScreenSettings.dmPelsWidth	= Width;
	dmScreenSettings.dmPelsHeight	= Height;
	dmScreenSettings.dmBitsPerPel	= BitDepth;

	// CHANGE BPP FIRST
	dmScreenSettings.dmFields = DM_BITSPERPEL;

	if(ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
	{
		MessageBox(NULL, TEXT("Couldn't change color depth! You must change settings manually"),
				TEXT("setup"), NULL);
	}

	// CHANGE SCREENSIZE NEXT
		dmScreenSettings.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;

	if(ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
	{
		MessageBox(NULL, TEXT("Couldn't grab video mode! Running in windowed mode."), 
				TEXT("setup"), NULL);
	}
}

