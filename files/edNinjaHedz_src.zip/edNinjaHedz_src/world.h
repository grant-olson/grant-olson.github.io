#ifndef GFX_WORLD_SEEN
#define GFX_WORLD_SEEN

#include "gfxTypes.h"
#include "textureInfo.h"
#include "quadtree.h"
#include "camera.h"

#ifdef PREFS_ON

#include "preferences.h"

#endif

/////////////////////////////////////////////////////////////////////////////////////////
// World
/////////////////////////////////////////////////////////////////////////////////////////

class world
{
private:
	void loadBgcolor(void);

	// BACKGROUND IMAGE
	GFX_TextureInfo*	backgroundTexInfo;
	GFX_TEXTURE_ID		backgroundTexID;

	void drawBackgroundImage(void);

	void addRectangle(corners tmpCorner, leaf* tmpLeaf);
	void addLine(GFX_FLOAT tmpX1, GFX_FLOAT tmpX2, GFX_FLOAT tmpY1,
               GFX_FLOAT tmpY2, leaf* tmpLeaf);

	void initQuadtree(GFX_FLOAT size, GFX_FLOAT resolution);

	light*	lightInfo[MAX_LIGHTS];

	GFX_TextureInfo*	textureInfo[MAX_TEXTURES];

protected:


public:

	// Texture Junk
	GFX_TEXTURE_ID		textureID[MAX_TEXTURES];		// GL texture reference
	int					textureCount;

	void loadBackgroundImage(TCHAR* filename);

	// LIGHT VARS

	int		lightCount;

	quadtree* Quadtree;
	camera Camera;
	corners edges;  // World's edges

	color bgcolor;    //background color
	bool fadeOn;
	GFX_FLOAT fadeThreshold;

//CONSTRUCTION / DESTRUCTION
	world(void);
	world(GFX_FLOAT size);
	world(GFX_FLOAT size, GFX_FLOAT resolution);
	~world(void);

	void setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha);
	void setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue);
	void setBgcolor(color tmpColor);

// PHYSICAL JUNK
	void addLeaf(leaf* tmpLeaf);
	void addPrimitive(corners tmpCorner, leaf tmpLeaf);
	void deleteArea(corners tmpCorner);

//LIGHT JUNK
	light* addNewLight(light tmpLight);	// adds light to light array
	void addLightsIndirect(void);		// temporarity adds lights from the array to the quadtree
	light* getPtrToLight(int index);
	void deleteLight(int index);

	color	getLightColor(const vector& position);

	void addLight(light tmpLight);		// premanantly mixes in an individual light to quadtree
	void addTempLight(light tmpLight);  // temporarily adds one light to the quadtree

// TEXTURE JUNK
	GFX_TextureInfo* addNewTexture(GFX_TextureInfo& tmpTexture);
	void generateTextures(void);
	GFX_TextureInfo* getPtrToTexture(int index);
	void deleteTexture(int index);

//RENDERING JUNK
	void draw(void);
	void drawAll(void);
	void render(bool drawOrNot);

	void setClipPlane(clipPlane ClipPlane);

//COLLISION JUNK
	bool bound(GFX_FLOAT posX, GFX_FLOAT posY);
};


#endif /* FILE_WORLD_SEEN */