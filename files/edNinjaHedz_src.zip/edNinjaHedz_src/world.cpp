#include "world.h"


/*********************************************************************
*
* WORLD CLASS
* This wraps all of the physical properties of the environment into 
* one class.
*
*********************************************************************/
//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   DEFAULT CONSTRUCTOR
//
// [NOTES]
//   Will default the worldsize to 256 units
//
//////////////////////////////////////////////////////////////////////
world::world(void)
{
	backgroundTexInfo = NULL;
	backgroundTexID = 0;

	textureCount = 0;
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		textureID[i] = 0;
		textureInfo[i] = NULL;
	}
	generateTextures();

	lightCount = 0;

	for(i = 0; i < MAX_LIGHTS; i++)
	{
		lightInfo[i] = NULL;
	}

	initQuadtree(256.0, 256.0);
	Quadtree->floorTexture = textureID;

	fadeOn = TRUE;
	fadeThreshold = 0.15;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   PARAMETERIZED CONSTRUCTOR
//
// [PARAMETERS]
//   GFX_FLOAT size- the size of the world to initalized
//
//////////////////////////////////////////////////////////////////////
world::world(GFX_FLOAT size)
{
	backgroundTexInfo = NULL;
	backgroundTexID = 0;

	textureCount = 0;
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		textureID[i] = 0;
		textureInfo[i] = NULL;
	}
	generateTextures();

	
	lightCount = 0;

	for(i = 0; i < MAX_LIGHTS; i++)
	{
		lightInfo[i] = NULL;
	}

	initQuadtree(size, size);
	Quadtree->floorTexture = textureID;

	fadeOn = TRUE;
	fadeThreshold = 0.15;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   PARAMETERIZED CONSTRUCTOR
//
// [PARAMETERS]
//   GFX_FLOAT size- the size of the world to initialize
//   GFX_FLOAT resolution- the maximum size of the smallest quadtree
//             NODE can be.  Helps with lighting functions.
//
//////////////////////////////////////////////////////////////////////
world::world(GFX_FLOAT size, GFX_FLOAT resolution)
{
	backgroundTexInfo = NULL;
	backgroundTexID = 0;

	textureCount = 0;
	for(int i = 0; i < MAX_TEXTURES; i++)
	{
		textureID[i] = 0;
		textureInfo[i] = NULL;
	}
	generateTextures();

		lightCount = 0;

	for(i = 0; i < MAX_LIGHTS; i++)
	{
		lightInfo[i] = NULL;
	}


	Quadtree->floorTexture = textureID;

	initQuadtree(size, resolution);
	fadeOn = TRUE;
	fadeThreshold = 0.15;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    DESTRUCTOR
//
//////////////////////////////////////////////////////////////////////
world::~world(void)
{
	delete backgroundTexInfo;

	// CLEAR GL TEXTURES
	glDeleteTextures(MAX_TEXTURES, textureID);
	glDeleteTextures(1, &backgroundTexID);
	
	for(int i = 0; i < textureCount; i++)
	{
		delete textureInfo[i];
		textureInfo[i] = NULL;
	}
	// release GL textureIDs


	for(i = 0; i < lightCount; i++)
	{
		delete lightInfo[i];
		lightInfo[i] = NULL;
	}

	delete Quadtree;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    draws everything contained in the quadtree without discresion.
//    It's very slow but can be useful for debugging.
//
//////////////////////////////////////////////////////////////////////
void
world::drawAll(void)
{
	Quadtree->drawAll();
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    Draws the quadtree up to a set distance, so we can throw out 
//    stuff that's too far away.
//
// [NOTES]
//    If fadeOn == TRUE it will incorporate lightmap functions
//
//////////////////////////////////////////////////////////////////////
void
world::draw(void)
{
	if(fadeOn)
	{
		if(Prefs.fog)
		{
			glEnable(GL_FOG);
			Quadtree->draw(Camera.eye, Camera.visionRange);
		}
		else
		{
			glDisable(GL_FOG);
			Quadtree->drawWithFade(Camera.eye, Camera.visionRange, fadeThreshold);
		}

	}
	else
	{
		Quadtree->draw(Camera.eye, Camera.visionRange);
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This is used by WORLD CONSTRUCTORS to initaize an appropriate
//   quadtree.
//
// [PARAMETERS]
//   GFX_FLOAT size- size of the quadtree
//   GFX_FLOAT resolution- maximum size of smallest quadtree NODE
//
//////////////////////////////////////////////////////////////////////
void
world::initQuadtree(GFX_FLOAT size, GFX_FLOAT resolution)
{
	size = size /2;

	edges.x1 = 0 - size;
	edges.x2 = size;
	edges.y1 = 0 - size;
	edges.y2 = size;

	Quadtree = new quadtree(edges.x1, edges.x2, edges.y1, edges.y2);
	Quadtree->minQuadResolution(resolution);
	Quadtree->resolution = resolution;

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a leaf to the quadtree
//
// [PARAMETERS]
//   leaf* tmpLeaf- properties of the leaf to add
//
// [NOTES]
//   Maybe leaf* should be a leaf reference.
//
//////////////////////////////////////////////////////////////////////
void
world::addLeaf(leaf* tmpLeaf)
{
	Quadtree->insertLeaf(tmpLeaf);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This checks to see if a point is inside the world and then if
//    it intersects with any physical objects in the world
//    (leafs on the quadtree)
//
// [PARAMETERS]
//    GFX_FLOAT posX, posY- point to check
//
// [RETURN TYPE]
//    TRUE- the coordinate is invalid, either outside of world range
//          or it intersects with a leaf
//    FALSE- this point is open
//
//////////////////////////////////////////////////////////////////////
bool
world::bound(GFX_FLOAT posX, GFX_FLOAT posY)
{
	if( (posX < edges.x1) || (posX > edges.x2)
		|| (posY < edges.y1) || (posY > edges.y2) )		//World limits
	{
		return TRUE;									// outside of world
	}
	else
	{
		return Quadtree->boundCheck(posX, posY);		//intersecting w/ leaf
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a rectangle with an open interior to the world
//
// [PARAMETERS]
//   corners tmpCorner- the corners of the rectangle to add
//   leaf* tmpLeaf- the physical properties of the leaf to add
//
//////////////////////////////////////////////////////////////////////
void
world::addRectangle(corners tmpCorner, leaf* tmpLeaf)
{
	tmpLeaf->texturePointer = textureID;

	GFX_FLOAT i;

	tmpLeaf->flags = LF_NORTH_WALL | LF_WEST_WALL | LF_TOP_WALL;
	tmpLeaf->Corner.x1 = tmpCorner.x1;
    tmpLeaf->Corner.x2 = tmpCorner.x1 + 1;
    tmpLeaf->Corner.y1 = tmpCorner.y1;
    tmpLeaf->Corner.y2 = tmpCorner.y1 + 1;
    Quadtree->insertLeaf(tmpLeaf);

    for(i=tmpCorner.x1 + 1; i < tmpCorner.x2 - 1; i++)
    {
		tmpLeaf->flags = LF_SOUTH_WALL | LF_NORTH_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = i;
		tmpLeaf->Corner.x2 = i + 1;
		tmpLeaf->Corner.y1 = tmpCorner.y1;
		tmpLeaf->Corner.y2 = tmpCorner.y1 + 1;
		Quadtree->insertLeaf(tmpLeaf);
    }

    tmpLeaf->flags = LF_NORTH_WALL | LF_EAST_WALL | LF_TOP_WALL;
    tmpLeaf->Corner.x1 = tmpCorner.x2 - 1;
    tmpLeaf->Corner.x2 = tmpCorner.x2;
    tmpLeaf->Corner.y1 = tmpCorner.y1;
    tmpLeaf->Corner.y2 = tmpCorner.y1 + 1;
    Quadtree->insertLeaf(tmpLeaf);

    for(i=tmpCorner.x1 + 1; i < tmpCorner.x2 - 1; i++)
    {
		tmpLeaf->flags = LF_NORTH_WALL | LF_SOUTH_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = i;
		tmpLeaf->Corner.x2 = i + 1;
		tmpLeaf->Corner.y1 = tmpCorner.y2 - 1;
		tmpLeaf->Corner.y2 = tmpCorner.y2;
		Quadtree->insertLeaf(tmpLeaf);
    }

    tmpLeaf->flags = LF_SOUTH_WALL | LF_WEST_WALL | LF_TOP_WALL;
    tmpLeaf->Corner.x1 = tmpCorner.x1;
    tmpLeaf->Corner.x2 = tmpCorner.x1 + 1;
    tmpLeaf->Corner.y1 = tmpCorner.y2 - 1;
    tmpLeaf->Corner.y2 = tmpCorner.y2;
    Quadtree->insertLeaf(tmpLeaf);

    for(i=tmpCorner.y1 + 1; i < tmpCorner.y2 - 1; i++)
    {
		tmpLeaf->flags = LF_EAST_WALL | LF_WEST_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.y1 = i;
		tmpLeaf->Corner.y2 = i + 1;
		tmpLeaf->Corner.x1 = tmpCorner.x1;
		tmpLeaf->Corner.x2 = tmpCorner.x1 + 1;
		Quadtree->insertLeaf(tmpLeaf);
    }


    tmpLeaf->flags = LF_SOUTH_WALL | LF_EAST_WALL | LF_TOP_WALL;
    tmpLeaf->Corner.x1 = tmpCorner.x2 - 1;
    tmpLeaf->Corner.x2 = tmpCorner.x2;
    tmpLeaf->Corner.y1 = tmpCorner.y2 - 1;
    tmpLeaf->Corner.y2 = tmpCorner.y2;
    Quadtree->insertLeaf(tmpLeaf);

    for(i=tmpCorner.y1 + 1; i < tmpCorner.y2 - 1; i++)
    {
		tmpLeaf->flags = LF_WEST_WALL | LF_EAST_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = tmpCorner.x2 - 1;
		tmpLeaf->Corner.x2 = tmpCorner.x2;
		tmpLeaf->Corner.y1 = i;
		tmpLeaf->Corner.y2 = i + 1;
		Quadtree->insertLeaf(tmpLeaf);
    }

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a line to the world
//
// [PARAMETERS]
//   GFX_FLOAT tmpX1, tmpX2, tmpY1, tmpY2- coordinate of the line.
//             if tmpX1 == tmpX2 the line is along the Y axis, if not
//             its along the X axis
//
//////////////////////////////////////////////////////////////////////
void
world::addLine(GFX_FLOAT tmpX1,GFX_FLOAT tmpX2,GFX_FLOAT tmpY1,
               GFX_FLOAT tmpY2, leaf* tmpLeaf)
{
	tmpLeaf->texturePointer = textureID;

	GFX_FLOAT i;

	if(tmpX1 == tmpX2)      // along Y axis
	{
		tmpLeaf->flags = LF_NORTH_WALL | LF_EAST_WALL | LF_WEST_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = tmpX1;
		tmpLeaf->Corner.x2 = tmpX1 + 1;
		tmpLeaf->Corner.y1 = tmpY1;
		tmpLeaf->Corner.y2 = tmpY1 + 1;
		Quadtree->insertLeaf(tmpLeaf);

		tmpLeaf->flags = LF_WEST_WALL | LF_SOUTH_WALL | LF_EAST_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.y1 = tmpY2 - 1;
		tmpLeaf->Corner.y2 = tmpY2;
		Quadtree->insertLeaf(tmpLeaf);

		tmpLeaf->flags = LF_WEST_WALL | LF_EAST_WALL | LF_TOP_WALL;

		for(i = tmpY1 + 1; i < (tmpY2 - 1); i++)
		{
			tmpLeaf->Corner.y1 = i;
			tmpLeaf->Corner.y2 = i + 1;
			Quadtree->insertLeaf(tmpLeaf);
		}
	}
	else                   // along X axis
	{
		tmpLeaf->flags = LF_NORTH_WALL | LF_SOUTH_WALL | LF_WEST_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = tmpX1;
		tmpLeaf->Corner.x2 = tmpX1 + 1;
		tmpLeaf->Corner.y1 = tmpY1;
		tmpLeaf->Corner.y2 = tmpY1 + 1;
		Quadtree->insertLeaf(tmpLeaf);

		tmpLeaf->flags = LF_EAST_WALL | LF_SOUTH_WALL | LF_NORTH_WALL | LF_TOP_WALL;
		tmpLeaf->Corner.x1 = tmpX2 - 1;
		tmpLeaf->Corner.x2 = tmpX2;
		Quadtree->insertLeaf(tmpLeaf);

		tmpLeaf->flags = LF_NORTH_WALL | LF_SOUTH_WALL | LF_TOP_WALL;

		for(i = tmpX1 + 1; i < (tmpX2 - 1); i++)
		{
			tmpLeaf->Corner.x1 = i;
			tmpLeaf->Corner.x2 = i + 1;
			Quadtree->insertLeaf(tmpLeaf);
		}
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//  This basically does all the drawing.
//  It sets up the camera and draws the landscape if the argument 
//  drawOrNot is TRUE.  This is done so we can controll skipframe mode
//  outside of WORLD's contex, since sprites, the player, and score
//  info is drawn seperately
//
// [PARAMETERS]
//  drawOrNot- FALSE, we don't draw it, but still move the camera, ect
//
//////////////////////////////////////////////////////////////////////
void
world::render(bool drawOrNot)
{
	if(drawOrNot)
	{
		if(backgroundTexInfo == NULL)
		{
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		}
		else
		{
			glClear(GL_DEPTH_BUFFER_BIT);  // DONT NEED TO CLEAR SCREEN, JUST DEPTH BUFFER
			drawBackgroundImage();
		}

#ifdef PREFS_ON
		if(Prefs.flush){glFlush();glFinish();}
#endif

		glMatrixMode(GL_MODELVIEW);
		
		Camera.setUp();

		draw();

#ifdef PREFS_ON
		if(Prefs.flush){glFlush();glFinish();}
#endif
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   sets the background/ sky color for the engine
//
// [PARAMETERS]
//   OVERLOADED- different ways of stating the color to use
//
//////////////////////////////////////////////////////////////////////

// RGBA
void
world::setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha)
{
  bgcolor.red = tmpRed;
  bgcolor.green = tmpGreen;
  bgcolor.blue = tmpBlue;
  bgcolor.alpha = tmpAlpha;

  loadBgcolor();
}

// RGB
void
world::setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue)
{
  setBgcolor(tmpRed, tmpGreen, tmpBlue, 1.0);
}

// color type
void
world::setBgcolor(color tmpColor)
{
  bgcolor.red = tmpColor.red;
  bgcolor.green = tmpColor.green;
  bgcolor.blue = tmpColor.blue;
  bgcolor.alpha = tmpColor.alpha;

  loadBgcolor();
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This loads the current background color into the quadtree
//
//////////////////////////////////////////////////////////////////////
void
world::loadBgcolor(void)
{
  glClearColor(bgcolor.red, bgcolor.green,
               bgcolor.blue, bgcolor.alpha);
  Quadtree->setBgcolor(bgcolor);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This mixes a light into the Quadtree's lightmap.
//
// [PARAMETERS]
//   light tmpLight- the light to add
//
// [NOTES]
//   ONCE DONE THIS CAN'T BE UNDONE.
//   Use addTempLight() to mix in a light for one frame only.
//
//////////////////////////////////////////////////////////////////////
void
world::addLight(light tmpLight)
{
  Quadtree->mixColor(tmpLight);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a temporary light to the quadtree's lightmap.
//
// [PARAMETERS]
//   light tmpLight- the light to add.
//
// [NOTES]
//   This light is mixed in and then deleted the next time the world 
//   is drawn.  Used for dynamic lighting.  Use addLight() to add
//   a permanant light.
//
//////////////////////////////////////////////////////////////////////
void
world::addTempLight(light tmpLight)
{
  Quadtree->mixTempColor(tmpLight);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This adds either a line, rectangle or one square to the world
//    depending on the size/shape of the info received.
//
// [PARAMETERS]
//    corners tmpCorner- the primitive to add
//    leaf tmpLeaf- the physical properties of the primitive
//
//
//////////////////////////////////////////////////////////////////////
void
world::addPrimitive(corners tmpCorner, leaf tmpLeaf)
{
	tmpLeaf.texturePointer = textureID;

	if( ( (tmpCorner.x1 + 1.0) == tmpCorner.x2) &&
		( (tmpCorner.y1 + 1.0) == tmpCorner.y2) )
	{
		//add leaf;
		tmpLeaf.flags = LF_NORTH_WALL | LF_SOUTH_WALL | LF_EAST_WALL |
			LF_WEST_WALL | LF_TOP_WALL;
		tmpLeaf.Corner = tmpCorner;
		addLeaf(&tmpLeaf);
	}
	else
	{
		if( ( (tmpCorner.x1 + 1.0) == tmpCorner.x2) ) 
		{	//line along x axis
		addLine(tmpCorner.x1, tmpCorner.x2 - 1.0, 
			tmpCorner.y1, tmpCorner.y2 , &tmpLeaf);
		}
		else
		{  //line alnot y axis
			if( ( (tmpCorner.y1 + 1.0) == tmpCorner.y2) )
			{
			addLine(tmpCorner.x1, tmpCorner.x2, 
			tmpCorner.y1, tmpCorner.y2 - 1.0 , &tmpLeaf);
			}
			else
			{  //add Rectangle
				addRectangle(tmpCorner, &tmpLeaf);
			}
		}	
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This deletes the given area.
//
// [PARAMETERS]
//   corners tmpCorner- area to clear
//
//////////////////////////////////////////////////////////////////////
void
world::deleteArea(corners tmpCorner)
{
	Quadtree->clearArea(tmpCorner);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a texture to the texture list
//
// [PARAMETERS]
//   tmpTexture - the Texture to Add
//
// [RETURN]
//   A POINTER to the new texture or NULL
//
// [NOTES]
//   The return pointer should only be considered temporarily valid
//   over the local scope
//
//////////////////////////////////////////////////////////////////////
GFX_TextureInfo* 
world::addNewTexture(GFX_TextureInfo& tmpTexture)
{
	if(textureCount < MAX_TEXTURES )
	{
		textureInfo[textureCount] = 
			new GFX_TextureInfo(tmpTexture);
		
		textureInfo[textureCount]->bindTexture(textureID[textureCount]);

		textureCount++;

		return textureInfo[textureCount - 1];
	}
	else
	{
		GFX_ErrorMessage("Can't Add Any More Textures.", "world::addTexture");

		return NULL;
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   The returns a pointer to the Texture occupying a given index
//
// [PARAMETERS]
//   int Index- the index of the texture to check
//
// [RETURN]
//   A POINTER to the texture or NULL if it's invalid
//
// [NOTES]
//   MAX_TEXTURES tells you how many textures are permissable
//
//   The return pointer should only be considered temporarily valid
//   over the local scope
//
//////////////////////////////////////////////////////////////////////
GFX_TextureInfo*
world::getPtrToTexture(int index)
{
	if(index >= 0 && index < textureCount)
	{
		return textureInfo[index];
	}
	else
	{
		return NULL;
	}
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//  This deletes a texture at a given index
//
// [PARAMETERS]
//  int index- the index of the texture to delete
//
/////////////////////////////////////////////////////////////////////
void
world::deleteTexture(int index)
{
	if(index >= 0 && index < textureCount)
	{
		delete textureInfo[index];

		for(int i = index; i < textureCount; i++)
		{
			textureInfo[i] = textureInfo[i + 1];
		}

		textureInfo[textureCount] = NULL;
		textureCount--;
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This generates the OpenGL texture Info to bind the textures
//
//
//////////////////////////////////////////////////////////////////////
void 
world::generateTextures(void)
{
	glGenTextures(MAX_TEXTURES, textureID);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds a new light to the light array
//
// [PARAMETERS]
//    light tmpLight - light to add
//
// [RETURN]
//   A POINTER to the new texture or NULL
//
// [NOTES]
//   The return pointer should only be considered temporarily valid
//   over the local scope
//
//////////////////////////////////////////////////////////////////////
light*
world::addNewLight(light tmpLight)
{
	if(lightCount < MAX_LIGHTS)
	{
		lightInfo[lightCount] = new light;
		(*lightInfo[lightCount]) = tmpLight;

		lightCount++;
		
		return lightInfo[lightCount - 1];
	}
	else
	{
		GFX_ErrorMessage("Couldn't add light.  MAX_LIGHTS exceeded.", 
			"world::addNewLight()");

		return NULL;
	}

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This adds the lights from the light array to the temporary light
//   for the quadtree instead of permanantly adding it.
//
// [NOTES]
//   Once you permanantly add lights, they cannot be removed or edited
//   This is provided for level Editors
//
//////////////////////////////////////////////////////////////////////
void
world::addLightsIndirect(void)
{
	for(int i = 0; i < lightCount; i++)
	{
		addTempLight(*lightInfo[i]);
	}

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   The returns a pointer to the Texture occupying a given index
//
// [PARAMETERS]
//   int Index- the index of the texture to check
//
// [RETURN]
//   A POINTER to the texture or NULL if it's invalid
//
// [NOTES]
//   MAX_TEXTURES tells you how many textures are permissable
//
//   The return pointer should only be considered temporarily valid
//   over the local scope
//
//////////////////////////////////////////////////////////////////////
light*
world::getPtrToLight(int index)
{
	if(index >= 0 && index < lightCount)
	{
		return lightInfo[index];
	}
	else
	{
		return NULL;
	}
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//  This deletes a light at a given index
//
// [PARAMETERS]
//  int index- the index of the light to delete
//
/////////////////////////////////////////////////////////////////////
void
world::deleteLight(int index)
{
	if(index >= 0 && index < lightCount)
	{
		delete lightInfo[index];

		for(int i = index; i < lightCount; i++)
		{
			lightInfo[i] = lightInfo[i + 1];
		}

		lightInfo[lightCount] = NULL;
		lightCount--;
	}
}

/////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//  This calculates the light to add to a given point
//
// [PARAMETERS]
//  vector position- point to add
//
// [RETURN]
//  the color to mix
//
/////////////////////////////////////////////////////////////////////
color
world::getLightColor(const vector& position)
{
	color	returnColor, tmpColor;
	GFX_FLOAT	distance, range;

	returnColor.setColor(0.0, 0.0, 0.0);

	for(int i = 0; i < lightCount; i++)
	{
		distance = lightInfo[i]->Position.getOtherDistance(position);

		if(distance < lightInfo[i]->distance)
		{
			if(lightInfo[i]->Position.getOtherFOV(position, lightInfo[i]->angle, lightInfo[i]->distance))
			{
				range = lightInfo[i]->distance;
				tmpColor = lightInfo[i]->Color;
				tmpColor *=  distance / range;
				returnColor += tmpColor;
			}
		}
	}

	return returnColor;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This loads a bitmap into the background image
//
// [INPUT]
//   The filename of the image to load
//
//////////////////////////////////////////////////////////////////////
void
world::loadBackgroundImage(TCHAR* filename)
{
	backgroundTexInfo = new GFX_TextureInfo;

	backgroundTexInfo->loadBMP(filename);

	glGenTextures(1, &backgroundTexID);
	backgroundTexInfo->bindTexture(backgroundTexID);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This draws the background image on the screen
//
//////////////////////////////////////////////////////////////////////
void
world::drawBackgroundImage(void)
{
	int tmpX;
	GFX_FLOAT tmpXstart, tmpXend;

	if(backgroundTexInfo != NULL)
	{

		// figure out offset for image
		tmpX = (int)Camera.eye.degrees;
		tmpX = tmpX % 90;

		tmpXstart = (GFX_FLOAT)tmpX / 90.0;
		tmpXend = tmpXstart + (4.0 / 3.0);

		
		// SETUP
		glDisable(GL_DEPTH_TEST);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

		//DRAW BACKGROUND
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glBindTexture(GL_TEXTURE_2D, backgroundTexID);

		glBegin(GL_QUADS);

		glTexCoord2f(tmpXstart, 0.0);
		glVertex2f(-1.0,  1.0);

		glTexCoord2f(tmpXstart, 1.0);
		glVertex2f(-1.0, -1.0);
		
		glTexCoord2f(tmpXend, 1.0);
		glVertex2f(1.0, -1.0);

			
		glTexCoord2f(tmpXend, 0.0);
		glVertex2f(1.0,  1.0);

		glEnd();


#ifdef PREFS_ON

		if(Prefs.lightmap)
		{
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		else
		{
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		}

#else

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

#endif //PREFS_ON

		// UNDO SETUP
		glEnable(GL_DEPTH_TEST);
	}
}

void
world::setClipPlane(clipPlane ClipPlane)
{
	Prefs.clip = ClipPlane;

	switch(Prefs.clip)
	{
	case CLIP_NEAR:
		Camera.visionRange = 25.0;
		break;

	case CLIP_MEDIUM:
		Camera.visionRange = 50.0;
		break;

	case CLIP_FAR:
		Camera.visionRange = 75.0;		
		break;

	default:
		Camera.visionRange = 50.0;
		break;
	}
}