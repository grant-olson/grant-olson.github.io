#include "sprites.h"

/*******************************************************************************
* SPRITE COLLECTION:
* THIS IS A VIRTUAL CLASS THAT TAKES CARE OF THE LINKED LIST BASICS FOR A COLLECTION
* OF SPRITES.  I WILL OVERRIDE WITH SPECIFICS, SUCH AS A COLLECTION OF ENEMIES
* AND A COLLECTION OF PROJECTILES.
*
* I BASICALLY PLAN TO GROUP BY THINGS THAT CAN'T RUN INTO EACH OTHER.  I.E.
* I DON'T CARE IF TWO ENEMIES OVERLAP, BUT IF ONE HITS THE PLAYERS OR A PROJECTILE
* DAMAGE MUST BE FIGURED OUT.
* 
* NOTE THAT YOU NEED TO CREATE A PRIVATE CREATE_NEW FUNCTION FOR EACH SUPERCLASS
* TO CHECK AGAINST THE ENUM TYPE WHEN ADD_NEW IS CALLED SO THAT YOU CAN TYPE CHECK
* AND PREVENT ONE GROUP FROM BEING APPLIED TO ANOTHER
*
*******************************************************************************/

//////////////////////////////////////////////////////////////////////
spriteCollection::spriteCollection()
{
  first = NULL;
  last = NULL;
  current = NULL;
  count = 0;
}

//////////////////////////////////////////////////////////////////////
spriteCollection::~spriteCollection()
{
  current = first;

  while(current != NULL)
  {
    deleteCurrent();
  }
}

//////////////////////////////////////////////////////////////////////
// Adds a new item to the list and makes it the current record.
//  It doesn't load in any default values, like location.
//  You must do that with:
//
//    spriteCollection.current->property = value;
//
// I might add a generic struct to pass unless the sub-classes
// are too customized.
//////////////////////////////////////////////////////////////////////

void
spriteCollection::addNew(sprite_type tmpSprite)
{
  if(count != 0)       //Do any exist yet? Go ahead and create normally
  {
    current = last;
    current->next = createNew(tmpSprite);
    current->next->previous = current;
    current->next->next = NULL;
	current->next->SoundEngine = SoundEngine;
    current = current->next;
    last = current;
    count++;    
  }
  else          //Creating the first entry in list is an exception
  {
    current = createNew(tmpSprite);
	current->SoundEngine = SoundEngine;
    current->previous = NULL;
    current->next = NULL;
    first = current;
    last = current;
    count = 1;
  }
}

//////////////////////////////////////////////////////////////////////
//  This removes the current record from the list and DELETEs
//  it from memory.
//////////////////////////////////////////////////////////////////////
void
spriteCollection::deleteCurrent(void)
{
  sprite* tmpPrevious;
  sprite* tmpNext;

  if(count != 0)                    // Is there a current record to delete?
  {
    tmpPrevious = current->previous;
    tmpNext = current->next;

    delete current;
    count--;

    if(count == 0)                // deleted the last record, empty set now.
    {
      first = NULL;
      last = NULL;
      current = NULL;
    }
    else
    {
      if(tmpPrevious == NULL)   // deleted the first record, must set new first record.
      {
        current = tmpNext;
        current->previous = NULL;
        first = current;
      }
      else
      {
        if(tmpNext == NULL)   // deleted the last record, must set new last record.
        {
          current = tmpPrevious;
          current->next = NULL;
          last = current;
        }
        else                 // deleted a record in the middle somewhere
        {
          current = tmpNext;
          current->previous = tmpPrevious;
          current->previous->next = tmpNext;
        }
      }
    }
  }
}

//////////////////////////////////////////////////////////////////////
// Following are overloaded operators for ++, --, +=, -=.  They allow
// you to navigate through the list of spriteCollection.  These just
// stop at the first and last record without any return values to 
// indicate an error.
//////////////////////////////////////////////////////////////////////
void
spriteCollection::operator++(int)
{
  if(current != last)           // We can't skip past the last record.
  {
    current = current->next;
  }
}

//////////////////////////////////////////////////////////////////////
void
spriteCollection::operator--(int)
{
  if(current != first)         // We can't go before the first record.
  {
    current = current->previous;
  }
}

//////////////////////////////////////////////////////////////////////
void
spriteCollection::operator+=(int increment)
{
  for(int i=0 ; i < increment; i++)    // We have to climb through the list I steps
  {
    if(current != last)
    {
      current = current->next;
    }
  }
}

//////////////////////////////////////////////////////////////////////
void
spriteCollection::operator-=(int decrement)
{
  for(int i=0 ; i < decrement; i++)   // We have to climb through the list I steps
  {
    if(current != first)
    {
      current = current->previous;
    }
  }
}

//////////////////////////////////////////////////////////////////////
//  This draws all the memebers of the collection after performing
// various tests such as collision detection and bounds.
//////////////////////////////////////////////////////////////////////
void
spriteCollection::draw(bool drawOrCycle)
{
  killDead();

  if(count != 0)                 //is there anything to draw?
  {
    current = first;
    updateSprite(current, drawOrCycle);

    while(current != last)
    {
      current = current->next;
      updateSprite(current, drawOrCycle);
    };
  }
}


inline void
spriteCollection::updateSprite(sprite* currentSprite, bool drawOrUpdate)
{
	if(World->Camera.center.getOtherDistance(currentSprite->Position.current)
			> World->Camera.visionRange)
	{ //Out of sight, don't waste our time.
		currentSprite->ActionOutOfRange();
	}
	else
	{
		currentSprite->cycleState();
	    currentSprite->cyclePosition();
		currentSprite->bound(World);
		currentSprite->cycleAnim();

	    collisionRoutine();

		currentSprite->draw(drawOrUpdate);
	}
}

//////////////////////////////////////////////////////////////////////
// This deletes any members with the deleteDead state set to true.
//////////////////////////////////////////////////////////////////////
void
spriteCollection::killDead(void)
{
  bool tmpSwitch = FALSE;
  if(count != 0)
  {
    current = first;
    while(!tmpSwitch)
    {
      if(current == last)
      {tmpSwitch = TRUE;}

      if(current->State.deleteDead)
      {
        deleteCurrent();
      }else{
        if(current != last){current = current->next;}
      }
    }
  }
}

