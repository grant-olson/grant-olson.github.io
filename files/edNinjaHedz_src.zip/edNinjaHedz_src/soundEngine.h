#ifndef SOUND_ENGINE

#include <windows.h>
#include <dsound.h>
#include <mmsystem.h>
#include "wave.h"

#include "gfxTypes.h"		// for error message

#define COPIES_OF_SOUND	5
#define	MAX_SOUNDS	32
enum	sounds {STAR_THROW, PLAYER_HURT, PLAYER_DEAD, NINJA_YELL, NINJA_HURT, NINJA_DEAD};

class sound
{
private:
	//these are for the wave.c functions
	WAVEFORMATEX	*pwfx;
	HMMIO			hmmio;
	MMCKINFO		mmckinfo;
	MMCKINFO		mmckinfoParent;

	LPDIRECTSOUNDBUFFER	lpdsbStatic;					// the static buffer
	LPDIRECTSOUNDBUFFER dsbCopies[COPIES_OF_SOUND];		// copies for repeat play

	int		nextCopyToPlay;								// counter
	
public:
	sound();
	~sound();

	bool loadSound(LPDIRECTSOUND lpds, LPTSTR szFileName);
	void playSound(void);
};

class soundEngine
{
private:
	LPDIRECTSOUND	lpDS;
	sound* Sound[MAX_SOUNDS];
	
	LPTSTR	returnFileName(sounds tmpSound);
	HWND	hwndMainWindow;			// Window controlling the sound engine

	bool	playlist;		// is there a playlist?
	int		currentTrack;	// the current track
	int*	playlistStart;	// beginning of playlist
	int*	playlistCurrent;// current song to play

	void playCDtrack(int track, bool sendNotify);

public:
	WAVEFORMATEX	wfxPrimaryBuffer;

	bool	enabled;		// is the sound engine on?
	bool	repeat;			// repeat current CD selection when done?

	soundEngine();
	~soundEngine();

	void setCurrentTrack(int track);
	int	 getCurrentTrack(void);
	void setCDplaylist(int* list);
	void playNextCDtrack(void);
	void stopCDplayer(void);
	void pauseCDplayer(void);
	void continueCDplayer(void);

	BOOL initSoundEngine(HWND hwnd);
	void playSound(sounds playThisSound);
};

#define SOUND_ENGINE
#endif;
