#include "preferences.h"
	
preferences::preferences()
{
	// DEFAULT PREFERENCES
	fullscreen = TRUE;

	log			= FALSE;

	flush		= FALSE;
	lowRes		= FALSE;
	textureMode	= LINEAR;
	thirtyTwoBit= TRUE;
	clip		= CLIP_MEDIUM;
	lightmap	= TRUE;
	gamma		= 1.0;
	fog			= TRUE;
	realFloor	= TRUE;
	skipframe	= FALSE;
	alpha		= TRUE;
};

/////////////////////////////////////////////////////////////////////
//
// Not part of the preferences struct but this is some stuff so that
// we can use command line switches to override default prefs
//
/////////////////////////////////////////////////////////////////////

// TABLE TO CONVERT STRING TO ENUMERATED OPTION

cmdLineTable cmdLineInstruction[] = 
{
	"fullscreen",	CMD_FULLSCREEN,
	"lowres",		CMD_LOWRES,
	"32bit",		CMD_32BIT,
	"alpha",		CMD_ALPHA,
	"gamma_low",	CMD_GAMMA_LOW,
	"gamma_medium",	CMD_GAMMA_MEDIUM,
	"gamma_high",	CMD_GAMMA_HIGH,
	"clip_near",	CMD_CLIP_NEAR,
	"clip_medium",	CMD_CLIP_MEDIUM,
	"clip_far",		CMD_CLIP_FAR,
	"tex_nearest",	CMD_TEXTURE_NEAREST,
	"tex_linear",	CMD_TEXTURE_LINEAR,
	"lightmap",		CMD_LIGHTMAP,
	"log",			CMD_LOG,
	"fog",			CMD_FOG,
	"floor",		CMD_FLOOR,
	"flush",		CMD_FLUSH,
	"skipframe",	CMD_SKIPFRAME

};

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This breaks the command line into individual words for
//   processing.
//
// [INPUT]
//   szCmdLine- pointer to NUL terminated Command Line
//
//////////////////////////////////////////////////////////////////////
void
parseWinCmdLine(LPSTR szCmdLine)
{
	CHAR	commandLine[256];

	while(*szCmdLine != '\0')  // UNTIL WE REACH THE END
	{
		//SKIP WHITESPACE
		while(*szCmdLine == ' ')
		{szCmdLine++;}

		int i = 0;	//RESET INDEX

		// GO UNTIL WE HIT WHITESPACE
		while(*szCmdLine != ' ' && *szCmdLine != '\0')
		{
			commandLine[i] = *szCmdLine;  // COPY

			//FORCE TO LOWERCASE IF NECESSARY
			if(commandLine[i] >= 'A' && commandLine[i] <= 'Z')
				CONVERT_TO_LOWERCASE(commandLine[i]);

			// GOTO NEXT LETTER
			szCmdLine++;
			i++;
		}

		// NULL TERMINATED STRING
		commandLine[i] = '\0';

		//PARSE THIS INSTRUCTION
		parseCmdInstruction(commandLine);
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This breaks instruction down for processing
//
// [INPUT]
//   szInstruction - the instruction word
//
//////////////////////////////////////////////////////////////////////
void
parseCmdInstruction(LPSTR szInstruction)
{
	//Get Command Type
	CHAR	type = szInstruction[0];

	// Verify
	if( (type != '-') && (type != '+') && (type != '=') )
	{
		// No good, abort
		GFX_ErrorMessage(szInstruction, "Invalid Paramter Format");
		return;
	}

	// Make this command
	szInstruction++;

	// TRY TO FIND MATCH
	cmdLineCommands currentCommand = CMD_NOMATCH;

	for(int i = 0; i < CMD_PARAMETERS; i++)
	{
		if(!strcmp(szInstruction, cmdLineInstruction[i].name))
		{
			currentCommand = cmdLineInstruction[i].command;
		}
	}

	// PROCESS IF MATCH
	if(currentCommand != CMD_NOMATCH)
	{
		processCmdInstruction(type, currentCommand);
	}
	else
	{
		MessageBox(NULL, szInstruction, "Invalid Parameter Ignored",NULL);
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This processes a valid instruction
//
// [INPUT]
//  type  switch: + parameter on, - off, = just set
//	instruction	parameter
//
//////////////////////////////////////////////////////////////////////
void
processCmdInstruction(CHAR type, cmdLineCommands instruction)
{
	switch(instruction)
	{
	case CMD_FULLSCREEN:
		Prefs.fullscreen = (type == '-') ? FALSE : TRUE;
		break;

	case CMD_32BIT:
		Prefs.thirtyTwoBit = (type == '-') ? FALSE : TRUE;
		break;

	case CMD_LOWRES:
		Prefs.lowRes = (type == '+') ? TRUE : FALSE;
		break;

	case CMD_ALPHA:
		Prefs.alpha = (type == '+') ? TRUE : FALSE;
		break;

	case CMD_FOG:
		Prefs.fog = (type == '-') ? FALSE : TRUE;
		break;

	case CMD_FLOOR:
		Prefs.realFloor = (type == '+') ? TRUE : FALSE;
		break;

	case CMD_GAMMA_LOW:
		Prefs.gamma = 0.5;
		break;

	case CMD_GAMMA_MEDIUM:
		Prefs.gamma = 1.0;
		break;

	case CMD_GAMMA_HIGH:
		Prefs.gamma = 2.0;
		break;

	case CMD_CLIP_NEAR:
		Prefs.clip = CLIP_NEAR;
		break;

	case CMD_CLIP_MEDIUM:
		Prefs.clip = CLIP_MEDIUM;
		break;

	case CMD_CLIP_FAR:
		Prefs.clip = CLIP_FAR;
		break;

	case CMD_TEXTURE_NEAREST:
		Prefs.textureMode = NEAREST;
		break;

	case CMD_TEXTURE_LINEAR:
		Prefs.textureMode = LINEAR;
		break;

	case CMD_SKIPFRAME:
		Prefs.skipframe = (type == '-') ? FALSE : TRUE;
		break;

	case CMD_LIGHTMAP:
		Prefs.lightmap = (type == '-') ? FALSE : TRUE;
		break;

	case CMD_LOG:
		Prefs.log = (type == '+') ? TRUE : FALSE;
		break;

	case CMD_FLUSH:
		Prefs.flush = (type == '+') ? TRUE : FALSE;
		break;

	case CMD_NOMATCH:
	default:
		// NO MATCH- DO NOTHING
		break;
	}
}

//////////////////////////////////////////////////////////////////////
// THIS WRITES THE CURRENT PREFS TO LOG FILE
//////////////////////////////////////////////////////////////////////
void
writePrefsToLogFile(void)
{
	WriteToLogFile( Prefs.alpha ? "ALPHA ON" : "ALPHA OFF");

	switch(Prefs.clip)
	{
	case CLIP_NEAR:
		WriteToLogFile("CLIP NEAR");
		break;

	case CLIP_MEDIUM:
		WriteToLogFile("CLIP MEDIUM");
		break;

	case CLIP_FAR:
		WriteToLogFile("CLIP FAR");		
		break;
	}
	WriteToLogFile( Prefs.flush ? "FLUSH ON" : "FLUSH OFF");
	WriteToLogFile( Prefs.fog ? "FOG ON" : "FOG OFF");
	WriteToLogFile( Prefs.fullscreen ? "FULLSCREEN ON" : "FULLSCREEN OFF");
	WriteToLogFile( Prefs.lightmap ? "LIGHTMAP ON" : "LIGHTMAP OFF");
	WriteToLogFile( Prefs.lowRes ? "LOWRES ON" : "LOWRES OFF");
	WriteToLogFile( Prefs.realFloor ? "FLOOR ON" : "FLOOR OFF");
	WriteToLogFile( Prefs.skipframe ? "SKIPFRAME ON" : "SKIPFRAME OFF");

	switch(Prefs.textureMode)
	{
	case NEAREST:
		WriteToLogFile("TEXTURE BLEND- NEAREST");
		break;

	case LINEAR:
		WriteToLogFile("TEXTURE BLEND- LINEAR");
		break;
	}

	WriteToLogFile( Prefs.thirtyTwoBit ? "THIRTY TWO BIT" : "SIXTEEN BIT");
	WriteToLogFile( ".");
}