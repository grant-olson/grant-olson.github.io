#ifndef	EDITOR_HEADER_SEEN
#define EDITOR_HEADER_SEEN

#include <windows.h>
#include "resource.h"
#include "gfxTypes.h"
#include "position.h"
#include "textureInfo.h"
#include "world.h"
#include "NinjaHedEntities.h"

#include "soundEngine.h"

#include "preferences.h"

//constants for WINDOWS
#define	GL_WINDOW_WIDTH			640
#define GL_WINDOW_WIDTH_LOW		320

#define	GL_WINDOW_HEIGHT		480
#define GL_WINDOW_HEIGHT_LOW	240

#define NO_FILE_LOADED		TEXT("Untitled")

// callback functions
LRESULT CALLBACK	WndProc (HWND, UINT, WPARAM, LPARAM);

BOOL	CALLBACK	dlgAddPrimitiveProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgNewFileProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgEditWorldProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgClearAreaProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgAddLightProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgAddEnemyProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgSetPlayerProc(HWND, UINT, WPARAM, LPARAM);
BOOL	CALLBACK	dlgCurrentTextureProc(HWND, UINT, WPARAM, LPARAM);

//main engine pointers
extern	world*				World;			// physical world struct
extern	sprite*				Player;			// PLAYER info
extern	spriteCollection*	Enemies;		// ENEMY stack
extern	spriteCollection*	Projectiles;	// PROJECTILE stack


extern	soundEngine*		SoundEngine;		// Sound Engine

// set/ unset pointers
void initLevel(void);
void cleanUpLevel(void);

void cleanUpEditor(void);
void initEditor(void);

// Open GL operations
void initGL(void);

void displayGL(void);
void displayGameGL(void);
void displayEditorGL(void);

// ENGINE GLOBALS
extern	bool	drawOrNot;
extern	bool	Skipframe;

// EDITOR GLOBAL INFO

// edit global vars
extern	bool	EditOn;			// EDIT MODE on
extern	bool	PrimitiveOn;			// PRIMITIVE is BEING DRAWN
extern	bool	addRect;			// PRIMITIVE is ADDITIVE
extern	bool	deleteRect;			// PRIMITIVE is SUBTRACTIVE

extern	int		frameCount;				// counts FRAMES PER SECOND

extern	vector		playerPos;			// holds the position PLAYER starts level at
extern	vector	editPos;						// holds edit cursor
extern	leaf	editLeaf;						// holds current leaf definition
extern	corners editPrimitive;					// holds Primitive area before it's created
extern	GLfloat editZoomDistance;		// holds the size of the edit screen

void editTitleText(HWND hwnd);			//generates the title bar text


// move playert
void movePlayer(void);


void setupFog(void);

//ENEMY storage for EDITOR, these would just call World->addEnemy in game
struct	enemyInfo
{
	sprite_type		Type;
	vector			Position;
};
//enemy functions
void		newEnemy(enemyInfo tmpEnemy);
void		deleteAllEnemies(void);
void		deleteEnemy(int index);

extern	enemyInfo*	editEnemies[];
extern	int			enemyCount;

// editor info
extern	int	currentLight;
extern	int currentEnemy;

//WINDOWS GLOBALS
extern	OPENFILENAME ofn;						// for common dialog FILES
extern	HINSTANCE	hInstance;					
extern	HWND		hDlgCurrentTexture;	// Modeless Dialog in edit mode

// WINDOWS STRINGS
extern	TCHAR		szAppName[];
extern	TCHAR		szFileName[];
extern	TCHAR		szTitleName[];
extern	TCHAR		szTextureFile[];

int	music[];

#endif
