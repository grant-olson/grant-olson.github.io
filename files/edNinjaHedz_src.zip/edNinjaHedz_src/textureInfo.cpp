#include "textureInfo.h"

/****************************************************************
*
* GFX_TextureInfo
* Holds all the information to create a texture
*
****************************************************************/
/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   DEFAULT CONSTRUCTOR
/////////////////////////////////////////////////////////////////
GFX_TextureInfo::GFX_TextureInfo()
{
	wrapS		= GL_REPEAT;
	wrapT		= GL_REPEAT;
	minFilter	= GL_LINEAR;
	magFilter	= GL_LINEAR;
	width		= 0;
	height		= 0;
	texelData	= NULL;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   DEFAULT DESTRUCTOR
/////////////////////////////////////////////////////////////////
GFX_TextureInfo::~GFX_TextureInfo()
{
	if(texelData != NULL)
	{
		delete[] texelData;
	}
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   COPY CONSTRUCTOR
//
// [NOTES]
//   Class has Pointers
//
/////////////////////////////////////////////////////////////////
GFX_TextureInfo::GFX_TextureInfo(const GFX_TextureInfo& texInfo)
{
	wrapS		= texInfo.wrapS;
	wrapT		= texInfo.wrapT;
	minFilter	= texInfo.minFilter;
	magFilter	= texInfo.magFilter;
	width		= texInfo.width;
	height		= texInfo.height;
	texelData	= NULL;

	if(texInfo.texelData != NULL)
	{
		int arraySize = sizeof(GLubyte) * width * height * 4;
		texelData = new GLubyte[arraySize];
		
		for(int i = 0; i < arraySize; i++)
		{
			texelData[i] = texInfo.texelData[i];
		}
	}
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   OPERATOR =
//
// [NOTES]
//   class has POINTERS
/////////////////////////////////////////////////////////////////
GFX_TextureInfo& 
GFX_TextureInfo::operator= (const GFX_TextureInfo& texInfo)
{
	if(this == &texInfo)
	{
		wrapS		= texInfo.wrapS;
		wrapT		= texInfo.wrapT;
		minFilter	= texInfo.minFilter;
		magFilter	= texInfo.magFilter;
		width		= texInfo.width;
		height		= texInfo.height;
		texelData	= NULL;

		if(texInfo.texelData != NULL)
		{
			int arraySize = sizeof(GLubyte) * width * height * 4;
			texelData = new GLubyte[arraySize];
		
			for(int i = 0; i < arraySize; i++)
			{
				texelData[i] = texInfo.texelData[i];
			}
		}
	}

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This loads a 24 bit BMP file in as the texture.
//
// [PARAMETERS]
//   TCHAR* filename - filename of bitmap
//
// [NOTES]
//   WINDOWS SPECIFIC CODE
//   Doesn't check to see if bitmap is 24 bit
//   Even though all 24bbmps will load, not all will bind to 
//   OpenGL.
/////////////////////////////////////////////////////////////////
void
GFX_TextureInfo::loadBMP(TCHAR* filename)
{
	HANDLE				fileToRead;
	BITMAPFILEHEADER	fileHeader;
	BITMAPINFOHEADER	infoHeader;
	DWORD				numRead;
	int					RowLength;

	GLubyte*			dummyData;
	GLubyte*			tmpPointer;

	fileToRead =  CreateFile(filename, GENERIC_READ,
				FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	ReadFile(fileToRead, &fileHeader, sizeof(BITMAPFILEHEADER), &numRead, NULL);
	ReadFile(fileToRead, &infoHeader, sizeof(BITMAPINFOHEADER), &numRead, NULL);

	height		= (GLint)infoHeader.biHeight;
	width		= (GLint)infoHeader.biWidth;

	RowLength	= ((infoHeader.biWidth * infoHeader.biBitCount + 31) & ~31) >> 3;  // from Peltzoid P729

	dummyData = new GLubyte[4];
	delete [] texelData;
	texelData	= new GLubyte[height * width * 4];
	
	tmpPointer = texelData;

	for(int i = 0; i < height; i++)
	{
		for(int j = 0; j < width; j++)
		{
			ReadFile(fileToRead, (tmpPointer + 2), sizeof(GLubyte), &numRead, NULL);
			ReadFile(fileToRead, (tmpPointer + 1), sizeof(GLubyte), &numRead, NULL);
			ReadFile(fileToRead, (tmpPointer), sizeof(GLubyte), &numRead, NULL);
						
			*(tmpPointer + 3) = 255;
			tmpPointer += 4;
		}
		ReadFile(fileToRead,(dummyData), sizeof(GLubyte) *(RowLength - (width * 3)), &numRead, NULL);
	}
	CloseHandle(fileToRead);		
}
/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This binds the texture to an openGL context
//
// [PARAMETERS]
//   GFX_TEXTURE_ID tmpTextureID- the OpenGL texture ID
//
// [NOTES]
//   The TextureID must be generated externally with OpenGL calls
//
/////////////////////////////////////////////////////////////////
void
GFX_TextureInfo::bindTexture(GFX_TEXTURE_ID tmpTextureID)
{
	glBindTexture(GL_TEXTURE_2D, tmpTextureID);
	  
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapS);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height,
				0, GL_RGBA, GL_UNSIGNED_BYTE, texelData);

#ifdef PREFS_ON
	if(Prefs.textureMode == NEAREST)
	{
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	}
#endif

}