#include "camera.h"

/*********************************************************************
*
* CAMERA CLASS
* used to determine what we should be looking at.
*
*********************************************************************/
//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   DEFAULT CAMERA CONSTRUCTOR
//
//////////////////////////////////////////////////////////////////////
camera::camera(void)
{
	angle = 80.0;
	aspect = 1.33;
	nearPlane = 1.0;
	farPlane = 50.0;

	eyeY = 0.0;

	centerY = 0.0;

	upX = 0.0;
	upY = 1.0;
	upZ = 0.0;
	visionRange = 50.0;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This places the camera so that it is looking at a vector, 
//   irregardless of the current location
//
// [PARAMETERS]
//   tmpVector- the vector to look at
//
//////////////////////////////////////////////////////////////////////
void
camera::place(vector tmpVector)
{
	eye = tmpVector;
	eye.velocity = -4.0;
	eye.move();

	eyeY = 2.0;

	center = tmpVector;
	centerY = 1.50;

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This chases a given vector.  It turns to look at the vector, and
//   moves closer to it if necessary.
//
// [PARAMETERS]
//   tmpVector- the vector to chase
//
// [NOTES]
//   You should use place() to set the camera initially.  If not the
//   camera could have to zoom halfway across the world to catchup, 
//   cutting through walls, etch.
//   After that you can just chase() chase() chase()
//
//   NEEDS SOME WORK
//   now that yards are the default unit measurement
//   this causes more of a clipping problem than it did before
//////////////////////////////////////////////////////////////////////
void
camera::chase(vector tmpVector)
{
	GFX_FLOAT tmpDistance;

	tmpDistance = eye.getOtherDistance(tmpVector);

	// try some fuzzy logic on the speed
	if(tmpDistance < 4.0)
	{
		eye.velocity = 0.0;
	}
	else
	{
		if(tmpDistance < 5.0)
		{
			eye.velocity = 0.4;
		}
		else
		{
			eye.velocity = 0.7;
		}
	}
  
	eye.setAngle(eye.getOtherAngle(tmpVector));
	eye.move();

	center.X = (center.X + tmpVector.X) / 2;
	centerY = 1.50;
	center.Y = (center.Y + tmpVector.Y) / 2;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This issues the OpenGL to acually use the cameras view for 
//    rendering the scene.
//
// [PARAMETERS]
//    --
//
// [NOTES]
//   uses GLU,  not pure OPENGL
//////////////////////////////////////////////////////////////////////
void camera::setUp(void)
{
	glLoadIdentity();
	gluPerspective(angle, aspect, nearPlane, farPlane);

	gluLookAt(eye.X,    eyeY,    eye.Y,
            center.X, centerY, center.Y,
            upX,     upY,     upZ);
			
}
