#include "soundEngine.h"

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
soundEngine::soundEngine()
{
	// init default Primary Buffer
	memset(&wfxPrimaryBuffer, 0, sizeof(WAVEFORMATEX));
	wfxPrimaryBuffer.wFormatTag = WAVE_FORMAT_PCM;
	wfxPrimaryBuffer.nChannels  = 1;
	wfxPrimaryBuffer.nSamplesPerSec = 44100;
	wfxPrimaryBuffer.wBitsPerSample = 16;
	wfxPrimaryBuffer.nBlockAlign = 
		wfxPrimaryBuffer.wBitsPerSample / 8 * wfxPrimaryBuffer.nChannels;
	wfxPrimaryBuffer.nAvgBytesPerSec =
		wfxPrimaryBuffer.nSamplesPerSec * wfxPrimaryBuffer.nBlockAlign;

	repeat = TRUE;
	enabled = TRUE;
	playlist = FALSE;
	currentTrack = 1;
	
	for(int i = STAR_THROW; i <= NINJA_DEAD; i++)
	{
		Sound[i] = NULL;
	}
}  // end of Constructor

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
soundEngine::~soundEngine()
{
	for(int i = STAR_THROW; i <= NINJA_DEAD; i++)
	{
		if (Sound[i] != NULL)
		{
			delete Sound[i];
		}
	}

	if(lpDS != NULL)
		{lpDS->Release();}

	stopCDplayer();
}	// end of Destructor

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::pauseCDplayer(void)
{
	mciSendString(TEXT("pause cdaudio"), NULL,
		NULL, NULL);
}	// end of pauseCDplayer()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::continueCDplayer(void)
{
	mciSendString(TEXT("play cdaudio"), NULL,
		NULL, NULL);
}	// end of contintueCDplayer()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::playCDtrack(int track, bool sendNotify)
{
	TCHAR	lpszCommandString[100];
	TCHAR	lpszReturnString[100];

	wsprintf(lpszCommandString,TEXT("open cdaudio") );
	mciSendString(lpszCommandString, lpszReturnString,
		lstrlen(lpszReturnString), NULL);

	wsprintf(lpszCommandString, TEXT("set cdaudio time format tmsf") );
	mciSendString(lpszCommandString, lpszReturnString,
		lstrlen(lpszReturnString), NULL);

	wsprintf(lpszCommandString, TEXT("play cdaudio from %i to %i %s"), track, track + 1, 
				sendNotify ? TEXT("notify") : TEXT(""));
	mciSendString(lpszCommandString, lpszReturnString,
		lstrlen(lpszReturnString), hwndMainWindow);

}	// end of playCDtrack

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
BOOL
soundEngine::initSoundEngine(HWND hwnd)
{
	if(enabled)
	{
		HRESULT					hr;
		LPDIRECTSOUNDBUFFER		lpDSB;
		DSBUFFERDESC			dsbdesc;

		hwndMainWindow = hwnd;

		// Create DirectSound Object
		DirectSoundCreate(NULL, &lpDS, NULL);
		lpDS->SetCooperativeLevel(hwnd, DSSCL_PRIORITY);

		memset(&dsbdesc, 0, sizeof(DSBUFFERDESC) );
		dsbdesc.dwSize = sizeof(DSBUFFERDESC);
		dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
		dsbdesc.dwBufferBytes = 0;
		dsbdesc.lpwfxFormat = NULL;

		hr = lpDS->CreateSoundBuffer(&dsbdesc, &lpDSB, NULL);

		if( SUCCEEDED (hr) )
		{
			// Set Primary Buffer to default format
			hr = lpDSB->SetFormat(&wfxPrimaryBuffer);
			if(FAILED(hr))
			{
				GFX_ErrorMessage("Couldn't Set Primary Buffer Format\n Sound Engine disabled.", "SoundEngine::initSoundEngine");
				enabled = FALSE;
				return FALSE;
			}
		}
		else
		{
			GFX_ErrorMessage("Couldn't Grab Primary Sound Buffer.\n Sound Engine disabled.","SoundEngine::initSoundEngine");
			lpDS = NULL;
			enabled = FALSE;
			return FALSE;
		}

		// load sounds

		for(int i = STAR_THROW; i <= NINJA_DEAD; i++)
		{
			Sound[i] = new sound;
		
			if(!Sound[i]->loadSound(lpDS, returnFileName( (sounds)i ) ) )
			{
				GFX_ErrorMessage("Couldn't Load Sound.\n Sound Engine disabled.","SoundEngine::initSoundEngine"); 
				enabled = FALSE;
				return FALSE;
			}
		}

		lpDSB->Play(0, 0, DSBPLAY_LOOPING);  // Keep primary buffer on

	return TRUE;
	}
	else    // engine not enabled
	{
		return FALSE;
	}

}  // end of initSoundEngine()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::setCurrentTrack(int track)
{
	currentTrack = track;
	playlist = FALSE;  // disable playlist
}	// end of setCurrentTrack()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
int
soundEngine::getCurrentTrack(void)
{
	return currentTrack;
}	// end of getCurrentTrack()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::playNextCDtrack(void)
{
	if(!playlist)
	{
		playCDtrack(currentTrack, repeat);
	}
	else
	{
		currentTrack = *playlistCurrent;
		playlistCurrent++;
		
		if(*playlistCurrent == 0)   // end of list
		{
			if(repeat)
			{
				playlistCurrent = playlistStart;
				playCDtrack(currentTrack, TRUE);
			}
			else
			{
				playCDtrack(currentTrack, FALSE);
			}
		}
		else  // normal play
		{
			playCDtrack(currentTrack, TRUE);
		}
	}
}	//end of playNextCDtrack()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::setCDplaylist(int* list)
{
	playlist = TRUE;

	playlistStart = list;
	playlistCurrent = list;

}	// end of setCDplaylist;

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::stopCDplayer(void)
{
	mciSendString(TEXT("stop cdaudio"), NULL,
		NULL, NULL);

}	//end of stopCDplayer()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
soundEngine::playSound(sounds playThisSound)
{
	if(enabled)
	{
		Sound[playThisSound]->playSound();
	}
}// end of playSound()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
LPTSTR
soundEngine::returnFileName(sounds tmpSound)
{
	switch(tmpSound)
	{
	case STAR_THROW:
		return TEXT("snd/whoosh.wav");

	case PLAYER_HURT:
		return TEXT("snd/playerhurt.wav");
		break;

	case PLAYER_DEAD:
		return TEXT("snd/playerdead.wav");
		break;

	case NINJA_YELL:
		return TEXT("snd/ninjayell.wav");

	case NINJA_HURT:
		return TEXT("snd/ninjaow.wav");

	case NINJA_DEAD:
		return TEXT("snd/ninjaargh.wav");

	default:
		return TEXT('\0');
	}

} // end of returnFileName()

//////////////////////////////////////////////////////////////////////////
//
// sound class
//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
sound::sound()
{
	lpdsbStatic = NULL;
	nextCopyToPlay = 0;
	for(int i = 0; i < COPIES_OF_SOUND; i++)
	{
		dsbCopies[i] = NULL;
	}
}  // end of sound Constructor

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
sound::~sound()
{

} // end of sound Destructor

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
sound::loadSound(LPDIRECTSOUND lpds, LPTSTR szFileName)
{
	DSBUFFERDESC	dsbdesc;
	LPVOID			lpvAudio1;
	DWORD			dwBytes1;
	UINT			cbBytesRead;


	//try to open file
	if(WaveOpenFile(szFileName, &hmmio, &pwfx, &mmckinfoParent ) != 0)
		return FALSE;

	//go to data chunk
	if(WaveStartDataRead( &hmmio, &mmckinfo, &mmckinfoParent) != 0)
		return FALSE;

	// if the buffer doesn't exist, create it

	if(lpdsbStatic == NULL)
	{
		memset( &dsbdesc, 0, sizeof(DSBUFFERDESC));
		dsbdesc.dwSize = sizeof(DSBUFFERDESC);
		dsbdesc.dwFlags = DSBCAPS_STATIC;
		dsbdesc.dwBufferBytes = mmckinfo.cksize;
		dsbdesc.lpwfxFormat = pwfx;

		if( FAILED(lpds->CreateSoundBuffer(&dsbdesc, &lpdsbStatic, NULL) ) )
		{
			WaveCloseReadFile( &hmmio, &pwfx);
			return FALSE;
		}
	}

	if( FAILED( lpdsbStatic->Lock(
				0,
				0,
				&lpvAudio1,
				&dwBytes1,
				NULL,
				NULL,
				DSBLOCK_ENTIREBUFFER) ) )
	{
		//error Handling
		return FALSE;
	}

	if(WaveReadFile(hmmio, dwBytes1, (BYTE*)lpvAudio1, &mmckinfo, &cbBytesRead) )
	{
		//failure on nonzero return
		return FALSE;
	}

	lpdsbStatic->Unlock(lpvAudio1, dwBytes1, NULL, 0);

	//now create copies

	for(int i = 0; i < COPIES_OF_SOUND; i++)
	{
		lpds->DuplicateSoundBuffer(lpdsbStatic, &dsbCopies[i]);
	}
	
	return TRUE;

}  // end of loadSound()

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
sound::playSound(void)
{
	HRESULT hr;

	if(lpdsbStatic == NULL) return; // nothing to play

	dsbCopies[nextCopyToPlay]->SetCurrentPosition(0);
	hr = dsbCopies[nextCopyToPlay]->Play(0, 0, 0);
	if (hr == DSERR_BUFFERLOST)
	{
		 GFX_ErrorMessage("Buffer Lost","sound::playSound");
	}

	nextCopyToPlay++;

	if(nextCopyToPlay >= COPIES_OF_SOUND)
		nextCopyToPlay = 0;


}  // end of playSound()
