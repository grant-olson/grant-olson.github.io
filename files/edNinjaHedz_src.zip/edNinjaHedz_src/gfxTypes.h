#ifndef GFX_ENGINE_TYPES
#define GFX_ENGINE_TYPES

#pragma warning(disable : 4305)     // double const cast for GLfloat warning
#pragma warning(disable : 4244)

// standard include files
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>
// Engine types, in sync with GL numbers

typedef	GLfloat	GFX_FLOAT;
typedef GLuint	GFX_TEXTURE_ID;

// constants for engine
#define MAX_TEXTURES	32
#define MAX_LIGHTS		64
#define MAX_ENEMIES		128

// some generic math functions

#define abs(a) ((a < 0) ? (0-(a)) : (a))
#define square(a)  ((a)*(a))
#define PI 3.141592654

// generic error message

#define GFX_ErrorMessage(a, b)	MessageBox(NULL, TEXT(a), TEXT(b), MB_ICONWARNING)

#define GFX_FatalError(a, b)  \
{MessageBox(NULL, TEXT(a), TEXT(b), MB_ICONWARNING); \
PostQuitMessage(0);}

/////////////////////////////////////////////////////////////////////
//
// CORNERS:
//
// Holds the corners of a rectangle:
//
//                 (x1, y1) ------------ (x2, y1)
//                          |          |
//                          |          |
//                          |          |
//                          |          |
//                 (x2, y1) ------------ (x2, y2)
//
/////////////////////////////////////////////////////////////////////

struct corners
{
  GFX_FLOAT x1;
  GFX_FLOAT x2;
  GFX_FLOAT y1;
  GFX_FLOAT y2;

};	// end of corners


/////////////////////////////////////////////////////////////////////////////////////////
// COLOR information
/////////////////////////////////////////////////////////////////////////////////////////

struct color{
	GFX_FLOAT red;
	GFX_FLOAT green;
	GFX_FLOAT blue;
	GFX_FLOAT alpha;

	color();
	color(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
        GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha);
	color(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue);

	void setColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha);
	void setColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue);
	void setColor(color tmpColor);

	void mixColor(color otherColor, GFX_FLOAT mixPercent);

	void sendGL(void);

	const color& operator=(const color& otherColor);
	const color& operator+=(const color& otherColor);
	const color& operator-=(const color& otherColor);
	const color operator+(const color& otherColor);
	const color operator-(const color& otherColor);

	const color operator+(GFX_FLOAT tmpNumber);
	const color operator-(GFX_FLOAT tmpNumber);
	const color operator*(GFX_FLOAT tmpNumber);
	const color operator/(GFX_FLOAT tmpNumber);

	const color& operator+=(GFX_FLOAT tmpNumber);
	const color& operator-=(GFX_FLOAT tmpNumber);
	const color& operator*=(GFX_FLOAT tmpNumber);
	const color& operator/=(GFX_FLOAT tmpNumber);

};

#endif