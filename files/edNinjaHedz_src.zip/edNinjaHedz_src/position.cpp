#include "position.h"

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
position::position()
{
	setXY(0.0, 0.0);
	velocity = 0.0;
	degrees = 0.0;
	radius = 1.0;
	move();
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
position::setAngle(GFX_FLOAT tmpDegrees)
{
	degrees = tmpDegrees;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
position::setXY(GFX_FLOAT X, GFX_FLOAT Y)
{
	current.X = X;
	current.Y = Y;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
position::setBoundBox(GFX_FLOAT x1, GFX_FLOAT x2, GFX_FLOAT y1, GFX_FLOAT y2)
{
	boundBox.x1 = x1;
	boundBox.x2 = x2;
	boundBox.y1 = y1;
	boundBox.y2 = y2;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
position::move(void)
{
	last = current;
	current.setAngle(degrees);
	current.velocity = velocity;
	current.move();
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
position::getOtherCollide(position otherPosition)
{
	return current.getOtherCollide(otherPosition.current);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
position::boundBoxCollide(position otherPosition)
{
	bool tmpReturn;
	vector tmpVector;

	tmpReturn = FALSE;

	Matrix.loadIdentity();
	Matrix.translate(otherPosition.current.X - current.X,
                   otherPosition.current.Y - current.Y);
	Matrix.rotate(otherPosition.current.radians - current.radians);

	tmpVector.X = otherPosition.boundBox.x1;
	tmpVector.Y = otherPosition.boundBox.y1;

	tmpVector = Matrix * tmpVector;

	if((tmpVector.X >= boundBox.x1) && (tmpVector.X <= boundBox.x2)
		&&(tmpVector.Y >= boundBox.y1) && (tmpVector.Y <= boundBox.y2))
	{
		tmpReturn = TRUE;
	}

	tmpVector.X = otherPosition.boundBox.x1;
	tmpVector.Y = otherPosition.boundBox.y2;

	tmpVector = Matrix * tmpVector;

	if((tmpVector.X >= boundBox.x1) && (tmpVector.X <= boundBox.x2)
		&&(tmpVector.Y >= boundBox.y1) && (tmpVector.Y <= boundBox.y2))
	{
		tmpReturn = TRUE;
	}

	tmpVector.X = otherPosition.boundBox.x2;
	tmpVector.Y = otherPosition.boundBox.y1;

	tmpVector = Matrix * tmpVector;

	if((tmpVector.X >= boundBox.x1) && (tmpVector.X <= boundBox.x2)
		&&(tmpVector.Y >= boundBox.y1) && (tmpVector.Y <= boundBox.y2))
	{
		tmpReturn = TRUE;
	}

	tmpVector.X = otherPosition.boundBox.x2;
	tmpVector.Y = otherPosition.boundBox.y2;

	tmpVector = Matrix * tmpVector;

	if((tmpVector.X >= boundBox.x1) && (tmpVector.X <= boundBox.x2)
		&&(tmpVector.Y >= boundBox.y1) && (tmpVector.Y <= boundBox.y2))
	{
		tmpReturn = TRUE;
	}

	return tmpReturn;
}