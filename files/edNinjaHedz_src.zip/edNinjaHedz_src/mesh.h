#ifndef MESH_FILE_SEEN
#define MESH_FILE_SEEN

#include "gfxTypes.h"
#include "textureInfo.h"

struct triangleInfo{
	short	one, two, three, texOne, texTwo, texThree;
};

struct texPointInfo{
	GFX_FLOAT s, t;
};

struct pointInfo{
	GFX_FLOAT x, y, z, w;
};

//////////////////////////////////////////////////////////////////////
// MESH
// Holds animation data
//////////////////////////////////////////////////////////////////////
class mesh{
private:

public:
	int frames;
//	int vertexCount;

	int				triangleCount;
	triangleInfo*	triangleData;

	int				texPointCount;
	texPointInfo*	texPointData;

	int				pointCount;
	pointInfo*		pointData;

	GFX_TextureInfo*	textureInfo;
	GFX_TEXTURE_ID		textureID;

	mesh(void);
	mesh(TCHAR* filename);		// loads .msh file
	mesh(const mesh& otherMesh); // copy constructor

	~mesh(void);

	mesh& operator=(const mesh& otherMesh);

	void draw(color tmpColor, int tmpFrame);
	bool loadFile(TCHAR *filename);
	bool saveFile(TCHAR *filename);

};

#endif