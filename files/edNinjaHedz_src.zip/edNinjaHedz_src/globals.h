#ifndef	GLOBAL_FILE_SEEN
#define	GLOBAL_FILE_SEEN

#include "preferences.h"
//
// This shows the global variables that are required for the engine
//

extern	preferences	Prefs;		// Various user settings

#endif
