#ifndef CAMERA_TYPE_SEEN
#define CAMERA_TYPE_SEEN

#include "gfxTypes.h"
#include "vector.h"

/////////////////////////////////////////////////////////////////////////////////////////
// camera struct
/////////////////////////////////////////////////////////////////////////////////////////
class camera
{

public:
// for GluPerspective
  GFX_FLOAT angle;
  GFX_FLOAT aspect;		//aspect ratio
  GFX_FLOAT nearPlane;
  GFX_FLOAT farPlane;

  GFX_FLOAT visionRange;

// for GluLookAt
  vector eye;
  GFX_FLOAT eyeY;

  vector center;
  GFX_FLOAT centerY;

  GFX_FLOAT upX;
  GFX_FLOAT upY;
  GFX_FLOAT upZ;

//function
  camera();
  void place(vector tmpVector);
  void chase(vector tmpVector);
  void setUp(void);
};

#endif