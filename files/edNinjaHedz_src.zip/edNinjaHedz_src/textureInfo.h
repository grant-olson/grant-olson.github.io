#ifndef TEXTURE_INFO_SEEN
#define TEXTURE_INFO_SEEN

#include "gfxTypes.h"

#ifdef PREFS_ON

#include "preferences.h"

#endif
/////////////////////////////////////////////////
// TEXTURE INFO
// Stores everything you need for textures
//
/////////////////////////////////////////////////
struct GFX_TextureInfo
{
	GLint		wrapS;
	GLint		wrapT;
	GLint		minFilter;
	GLint		magFilter;
	GLint		width;
	GLint		height;
	GLubyte*	texelData;

	GFX_TextureInfo();
	GFX_TextureInfo(const GFX_TextureInfo& texInfo);	// copy constructor
	~GFX_TextureInfo();

	GFX_TextureInfo& operator= (const GFX_TextureInfo& texInfo);

	void	loadBMP(TCHAR* filename);
	void	bindTexture(GFX_TEXTURE_ID tmpTextureID);
};

#endif