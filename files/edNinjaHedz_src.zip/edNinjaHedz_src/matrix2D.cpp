#include "matrix2D.h"

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
matrix2D::matrix2D()
{
  loadIdentity();
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
matrix2D::loadIdentity(void)
{
  for(int i=0; i < 3; i++)
  {
    for(int j=0; j < 3; j++)
    {
      if(i == j)
        {matrix[i][j] = 1.0;}
      else
        {matrix[i][j] = 0.0;}
    }
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
matrix2D
matrix2D::operator*(const matrix2D& otherMatrix)
{
  matrix2D temp;

  for(int i=0; i < 3; i++)
  {
    for(int j=0; j < 3; j++)
    {
      temp.matrix[i][j] = 
              matrix[i][0] * otherMatrix.matrix[0][j] +
              matrix[i][1] * otherMatrix.matrix[1][j] +
              matrix[i][2] * otherMatrix.matrix[2][j];
    }
  }

  return temp;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
vector
matrix2D::operator*(vector originalVector)
{
  vector tmpVector;

  tmpVector.X = originalVector.X * matrix[0][0] +
                originalVector.Y * matrix[0][1] +
                matrix[0][2];

  tmpVector.Y = originalVector.X * matrix[1][0] +
                originalVector.Y * matrix[1][1] +
                matrix[1][2];

  return tmpVector;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
matrix2D::translate(GFX_FLOAT X, GFX_FLOAT Y)
{
  matrix2D tmpMatrix;
 
  tmpMatrix.matrix[0][2] = X;
  tmpMatrix.matrix[1][2] = Y;
   
  (*this) = (*this) * tmpMatrix;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
matrix2D::rotate(double radians)
{
  matrix2D tmpMatrix;

  // need to account for the fact that 0 deg is 
  // down the negative Y axis, so the transformation
  // might not be kosher for general purpose.

  tmpMatrix.matrix[0][0] = (GFX_FLOAT)(cos(radians));
  tmpMatrix.matrix[1][0] = (GFX_FLOAT)(sin(radians));

  tmpMatrix.matrix[0][1] = -(GFX_FLOAT)(sin(radians));
  tmpMatrix.matrix[1][1] =  (GFX_FLOAT)(cos(radians));

  (*this) = (*this) * tmpMatrix;
}
