#ifndef GFX_SPRITES_SEEN
#define GFX_SPRITES_SEEN

#include "gfxTypes.h"
#include "mesh.h"
//#include "textureInfo.h"
#include "vector.h"
#include "position.h"
#include "state.h"
#include "light.h"
#include "world.h"
#include "soundEngine.h"



//////////////////////////////////////////////////////////////////////
//
// SPRITE-
//
// This is the base class for all SPRITES.  It contains generic 
// mechanisms for handling all SPRITE function calls.  There are 
// several virtual functions that can be overridden by specific 
// subclasses.
//
// Even though we are rendering 3D images, everything is really in a 
// 2D environment.  Height doesn't effect the sprites in any way.
//
// The virtual ACTION functions are triggered by several functions
// (including the STATE MACHINE) to perform sprite specific classes.
//  These start off with very generic routines that will be modified
//  by subclasses:
// 
//     ActionCollide(sprite* otherSprite)- What to do when the sprite
//                    hits another.  You also get access to the other
//                    sprite to set it's states.
//     ActionBound() - Collision with bounding coords (walls).
//
//     ActionDead()  - Dead State counter reaches zero.
//     ActionDamage()- Process Damage- usually set by another sprite
//     ActionHit()   - Hit counter runs out
//     ActionSight() - Sight counter runs out
//     ActionSaw()   - Saw counter runs out
//     ActionNoHP()  - Hit Points run out(its dead)
//
// Generally, there are four functions to be called to complete a round
// of animation:
//
//       cycleState() - runs the state machine, calls appropriate
//                      action functions.
//        cycleAnim() - cycles the animation sequence.
//          setAnim() - sets the next animation sequence if possible
//             draw() - issues OpenGL to draw the routine
//
// And Collision Routines.  These are generally called by the 
// SPRITECOLLECTION class.
//
//      collideVector(vector otherVector)
//      collideSprite(sprite* otherSprite)
//      collideCollection(void* SpriteCollection)
//      bound(world* World)
//
// There are three void pointers used to pass implementation specific
// pointers to subclasses.  I.E. an enemy will need to know where
// the player sprite is for it's AI routines.  Didn't want to hard-code
//
//     void* voidPointer1, voidPointer2, voidPointer3;
//     void initPointers()- dereferences above pointers to private
//          pointers for internal use.
//////////////////////////////////////////////////////////////////////

class sprite
{
private:

protected:

public:

// STATE MACHINE FUNCTIONS
	virtual void ActionCollide(sprite* otherSprite);
	virtual void ActionDead(void);
	virtual void ActionDamage(void);
	virtual void ActionHit(void);
	virtual void ActionSight(void);
	virtual void ActionSaw(void);
	virtual void ActionNoHP(void);
	virtual void ActionBound(void);
	virtual void ActionOutOfRange(void);

	// FOR SPRITE COLLECTIONS  
	sprite* previous;
	sprite* next;

	// ANIMATION ROUTINE VARS
	mesh* Mesh;

	int frame;
	int animCounter;	// 10 fps
	color Color;

	// STATE MACHINE
	state State;

	//MISC VARS
	int hitPoints;          // Hit Points
	position Position;        // physical loaction info
	void* voidPointer1;
	void* voidPointer2;
	void* voidPointer3;

	sprite(){};
	virtual ~sprite(){};

	//POINTER JUNK
	virtual void initPointers(void);

	//STUFF TO CALL TO ANIMATE
	void cycleState(void);
	virtual void cyclePosition(void)=0;
	virtual void cycleAnim(void)=0;

	void draw(void);
	void draw(bool drawOrNot);     //Only draws if true, for skipframes

	void draw(const color& addColor);
	void draw(bool drawOrNot, const color& addColor);     //Only draws if true, for skipframes

	//COLLISION ROUTINES
	bool collideVector(vector otherVector);
	bool collideSprite(sprite* otherSprite);
	void collideCollection(void* SpriteCollection);
	bool bound(world* World);

	// sound Engine pointer
	soundEngine*	SoundEngine;
};



extern enum sprite_type;


//////////////////////////////////////////////////////////////////////
//
// SPRITE COLLECTION:
//
// This is a collection of various SPRITES.  It has some virtual 
// functions so that we can set up different collections of SPRITES
// that operate in the same way(i.e. one collection of ENEMIES, another
// of PROJECTILES).
//
// Lets go throught the linked list junk first:
//
//    first   - a pointer to the first SPRITE.  NULL if there isn't one.
//    last    - a pointer to the last SPRITE.  NULL if there isnt one.
//    current - a pointer to the currentSPRITE.  NULL if there isn't
//              one, although it's preferable to test this with 
//              count != 0
//    count   - count of elements in the collection
//
// And the linked list functions:
//
//   addNew(sprite_type tmpSprite) - Adds a SPRITE to the end of the
//                                   list.
//
//   deleteCurrent(void)           - Deletes the Current SPRITE.
//
//  PRIVATE sprite* createNew(sprite_type tmpSprite);
//     This is a pure virtual function that NEWs a SPRITE and retuns
//     a pointer.  This is so we can perform basic Type Checks and
//     not add a PLAYER sprite to ENEMIES collection.
//
// I've also overloaded the ++, --, +=, -= operators so you can jump
// through the collection.  They make sure you don't go to far.
// This won't work if you're using a POINTER to the COLLECTION though
// To cycle through with a POINTER you must use something like:
//
//         if(collection->current->next)   //NOT NULL, NOT END OF LIST
//         {
//           collection->current = collection->current->next;
//         }
//
// That sums up the linked list.  Here are the SPRITE related stuff:
//
//      boundLeft, boundRight, boundFront, boundBack-  these are the
//               values for bounding tests.  It assumes -Z goes into
//               the screen so boundFront should be less than back
//
//      draw() - performs all necessary tests (collision, anim, etc.)
//                and draws all the SPRITES
//      killDead() - DELETEs tagged SPRITES for clean-up.
//      collisionRoutine() - this is a PURE virtual function.
//                     It performs required collision tests.
//
// There are three void pointers used to pass implementation specific
// pointers to subclasses. These are used for collision tests and 
// anything else needed.  IE-  a collection of ENEMIES might need to 
// access a PROJECTILE collection to shoot at the PLAYER.
//
//     void* voidPointer1, voidPointer2, voidPointer3;
//     void initPointers()- dereferences above pointers to private
//          pointers for internal use.
//////////////////////////////////////////////////////////////////////

class spriteCollection{

private:
	virtual sprite* createNew(sprite_type tmpSprite)=0;

public:

	//LINKED LIST VARS
	sprite* first;
	sprite* last;
	sprite* current;
	unsigned int count;

	//ITEMS FOR COLLISION TESTS
	void*   voidPointer1;
	void*   voidPointer2;
	void*   voidPointer3;
	void*   voidPointer4;

	//Reference to the outside world
	world* World;
	soundEngine*	SoundEngine;

	spriteCollection();
	~spriteCollection();

	//LINKED LIST FUNCTIONS
	void addNew(sprite_type tmpSprite);
	void deleteCurrent(void);

	// These operators are overloaded to allow you to iterate your way
	// through the collection.  See above note.
	void operator++(int);
	void operator--(int);
	void operator+=(int increment);
	void operator-=(int decrement);

	//DRAW FUNCTIONS
	virtual void draw(bool drawOrCycle);
	inline void updateSprite(sprite* currentSprite, bool drawOrUpdate);
	void killDead(void);
	virtual void initPointers(void)=0;
	virtual void collisionRoutine(void)=0;
};



#endif /* FILE_SPRITES_SEEN */