#ifndef GFX_QUADTREE_SEEN
#define GFX_QUADTREE_SEEN

#include "gfxTypes.h"
#include "vector.h"
#include "light.h"

#ifdef PREFS_ON

#include "preferences.h"

#endif

//////////////////////////////////////////////////////////////////////
//
// LEAF-
//
// This holds the physical contents of leaves on the quadtree.
//////////////////////////////////////////////////////////////////////

class leaf
{
protected:
	inline void sendLeafGL(color tmpColor);

public:
	short int flags;
	corners Corner;
	color Color;
	color tempMixColor;
	GFX_FLOAT height;
	static GLuint* texturePointer;
	int		textureIndex;

	leaf();
	leaf(leaf* tmpLeaf);
	void drawLeaf(void);
	void drawLeafWithFade(GFX_FLOAT tmpPercent, color* tmpBgcolor, GFX_FLOAT tmpThreshold);
};


// DEFINES FOR LEAVES
#define   LF_NORTH_WALL    1
#define   LF_SOUTH_WALL    2
#define   LF_EAST_WALL     4
#define   LF_WEST_WALL     8
#define   LF_TOP_WALL     16
#define   LF_BOTTOM_WALL  32

#define   WALL_HEIGHT     3.0      // How tall do we make leaves?
//END LEAF DEFINES

//////////////////////////////////////////////////////////////////////
// Enumerate the different quadrants for easy reference.  The quadrants
// start in the upper right corner and rotate clockwise.
//
//                                -y (into the screen)
//
//                                 |
//                            4    |    1
//                                 |
//                     -x  --------|--------  +x                                 |
//                            3    |    2
//                                 |
//                                 |
//
//                                 +y
//
//////////////////////////////////////////////////////////////////////
enum quadrant{QUAD_ONE, QUAD_TWO, QUAD_THREE, QUAD_FOUR};

// The smallest size a Quadtree can become, also the size of a leaf?
#define MIN_QUAD_SIZE 1.0


//////////////////////////////////////////////////////////////////////
//
// QUADTREE-
//
// This class implements a quadtree for to store scenery.  It acts 
// recursively and holds either up to four NODES, a LEAF or NOTHING.
//
// It Works under the assumption that if there is a LEAF there are
// no NODES so this is never explicitly checked.
//
// It also assumes that the base QUADTREE is SQUARE and the size is
// a power of two when it's created.  If not it won't work properly.
//
// Instead of using an array of quadrants with the assumption that
// quad[0] is quadrant zero, ect. the subquads are referred to by
// an enumerated type QUADRANT (above) that is resolved into a 
// quadtree pointer via a private function.
//////////////////////////////////////////////////////////////////////

class quadtree
{

private:

	// CORE OF THE QUADTREE
	leaf* Leaf;

	quadtree* parent;
	quadtree* quad1;
	quadtree* quad2;
	quadtree* quad3;
	quadtree* quad4;
	// EVERYTHING ELSE IS THE GRAPHICS


	color quad1_color,
		quad2_color, quad3_color,  // color for the floor tiles
		quad4_color;

	color tempMixColor;				// this color gets reset after the frame is drawn

	static color* bgcolor;

// used to dereference quadrant type
	inline quadtree* returnPointerToQuad(quadrant tmpQuad);

// used to make things readable when quad is drawn, 
    inline void drawQuad(quadrant tmpQuadrant, vector eyePosition, GFX_FLOAT tmpDistance);
	inline void drawQuadWithFade(quadrant tmpQuadrant, vector eyePosition, GFX_FLOAT percentFade,
                           GFX_FLOAT tmpDistance, GFX_FLOAT tmpThreshold);

// sends the actaul GL
	inline void sendFloorGL(corners tmpCorner);

	void addNode(quadrant Quad);
	bool cleanArea(quadrant Quad);

	bool noQuad(quadrant tmpQuadrant);     //Checks to see if a quad exists yet
	bool smallestQuad(void);               //Checks to see if the quad is the smallest possible

	void drawFloor(corners tmpCorner);

	void drawFloorWithFade(quadrant tmpQuadrant, GFX_FLOAT tmpPercent,
                         GFX_FLOAT tmpThreshold);
	bool onScreen(quadtree* tmpQuad, vector eyePosition
                   , GFX_FLOAT tmpDistance);


protected:
	quadrant whichQuad(GFX_FLOAT x, GFX_FLOAT y);  // what sub-quad does this point belong to
	corners returnQuadCorners(quadrant tmpQuad);   // coordinates in physical space of sub-quad

	// for light falloff
	GFX_FLOAT quadraticAttenuation(GFX_FLOAT tmpNumber1, GFX_FLOAT tmpNumber2);

public:
	corners Corner;  // physical coordinates of quad

	static bool	floor, ceiling;    // do we draw floor or ceiling?
	color floorColor; 

	static GLuint* floorTexture;    // texture for floor
	static GFX_FLOAT resolution;    // Max Quad Size

// CONSTRUCTION/DESTRUCTION
	quadtree();
	quadtree(GFX_FLOAT tmpX1, GFX_FLOAT tmpX2,
           GFX_FLOAT tmpY1, GFX_FLOAT tmpY2);
	~quadtree();

// THESE ADD AND DELETE NODES AND LEAFS AS APPROPRIATE
	void insertLeaf(leaf* tmpLeaf);
	void clearArea(corners tmpCorner);

// VARIOUS HOUSEKEEPING FUNCTIONS
	void minQuadResolution(GFX_FLOAT size);    //Globally creates nodes of size
	bool boundCheck(GFX_FLOAT x, GFX_FLOAT y); //does a point intersect with this?


// DISTANCE FUNCTIONS
	GFX_FLOAT distanceFromPoint(vector otherVector);
	vector closestPointToPoint(vector otherVector);

	GFX_FLOAT distanceFromPoint(corners tmpCorner, vector otherVector);
	vector closestPointToPoint(corners tmpCorner, vector otherVector);

// RENDERING FUNCTIONS
	void draw(vector eyePosition, GFX_FLOAT tmpDistance);
	void drawWithFade(vector eyePosition, GFX_FLOAT tmpDistance, GFX_FLOAT tmpThreshold);
	void drawAll(void);


// COLOR FUNCTIONS
	// set floor color OVERLOADED
	void setFloorColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                     GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha);
	void setFloorColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue);
	void setFloorColor(color tmpColor);

	//sets the BGCOLOR OVERLOADED
	void setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                     GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha);
	void setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue);
	void setBgcolor(color tmpColor);

	// lightmap itself
	void mixTempColor(light tmpLight);
	void mixColor(light tmpLight);

// FILE FUNCTIONS
	int	leafCount(void);
	void	writeLeaf(HANDLE saveFile);
};


#endif /* FILE_QUADTREE_SEEN */