#include "quadtree.h"

/*********************************************************************
* QUADTREE MEMBERS
*********************************************************************/

// static members, must be initialized.

color*
quadtree::bgcolor = new color(0.0, 0.0, 0.0);

GLuint*
quadtree::floorTexture = NULL;

bool
quadtree::floor = TRUE;

bool
quadtree::ceiling = FALSE;

GFX_FLOAT 
quadtree::resolution = 32.0;

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Default Constructor
//////////////////////////////////////////////////////////////////////
quadtree::quadtree()
{
  parent = NULL;
  quad1  = NULL;
  quad2  = NULL;
  quad3  = NULL;
  quad4  = NULL;

  Leaf = NULL;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    Parameterized Constructor.
// [PARAMETERS]
//    tmpX1, tmpX2, tmpY1, tmpY2 - The corners of this portion of the
//          quadtree.
//////////////////////////////////////////////////////////////////////
quadtree::quadtree(GFX_FLOAT tmpX1, GFX_FLOAT tmpX2,
                   GFX_FLOAT tmpY1, GFX_FLOAT tmpY2)
{
  parent = NULL;
  quad1  = NULL;
  quad2  = NULL;
  quad3  = NULL;
  quad4  = NULL;

  Leaf = NULL;

  Corner.x1 = tmpX1;
  Corner.x2 = tmpX2;
  Corner.y1 = tmpY1;
  Corner.y2 = tmpY2;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Destructor- cleans everything up.
//////////////////////////////////////////////////////////////////////
quadtree::~quadtree()
{
  if(Leaf != NULL){delete Leaf;}

  if(quad1 != NULL){delete quad1;}
  if(quad2 != NULL){delete quad2;}
  if(quad3 != NULL){delete quad3;}
  if(quad4 != NULL){delete quad4;}

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This initializes a node on the current quadtree.
//
// [PARAMETERS]
//    quadrant Quad- either QUAD_ONE, QUAD_TWO, QUAD_THREE, or QUAD_FOUR
// 
//////////////////////////////////////////////////////////////////////
void
quadtree::addNode(quadrant Quad)
{
  switch(Quad)
  {
    case QUAD_ONE:
      quad1 = new quadtree;
      quad1->Corner = returnQuadCorners(QUAD_ONE);
      quad1->parent = this;
      quad1->setFloorColor(quad1_color);
    break;

    case QUAD_TWO:
      quad2 = new quadtree;
      quad2->Corner = returnQuadCorners(QUAD_TWO);
      quad2->parent = this;
      quad2->setFloorColor(quad2_color);
    break;

    case QUAD_THREE:
      quad3 = new quadtree;
      quad3->Corner = returnQuadCorners(QUAD_THREE);
      quad3->parent = this;
      quad3->setFloorColor(quad3_color);
    break;

    case QUAD_FOUR:
      quad4 = new quadtree;
      quad4->Corner = returnQuadCorners(QUAD_FOUR);
      quad4->parent = this;
      quad4->setFloorColor(quad4_color);
    break;
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This determines what quadrant of the current node a point falls
//    into
//
// [PARAMETERS]
//    x, y - the points of the quadrant
//
// [RETURN TYPE]
//    quadrant- either QUAD_ONE, QUAD_TWO, QUAD_THREE, or QUAD_FOUR
//
//////////////////////////////////////////////////////////////////////
quadrant
quadtree::whichQuad(GFX_FLOAT x, GFX_FLOAT y)
{
  quadrant tmpQuad;

  if( x >= ((Corner.x1 + Corner.x2) / 2) )              //right side
  {
    if (y >= ((Corner.y1 + Corner.y2) /2) )
      {tmpQuad = QUAD_TWO;}
    else
      {tmpQuad = QUAD_ONE;}
  }else{
    if (y >= ((Corner.y1 + Corner.y2) /2) )
      {tmpQuad = QUAD_THREE;}
    else
      {tmpQuad = QUAD_FOUR;}
  }

  return tmpQuad;    
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    A recursive function that traverses the quadtree until it is
//    able to add a leaf
//
// [PARAMETERS]
//    leaf* tmpLeaf- the leaf to add.
//
//////////////////////////////////////////////////////////////////////
void
quadtree::insertLeaf(leaf* tmpLeaf)
{

  quadrant tmpQuadrant;
  tmpQuadrant = whichQuad(tmpLeaf->Corner.x1, tmpLeaf->Corner.y1);

  // Is the leaf the same size as node?
  if((tmpLeaf->Corner.x1 == Corner.x1) && (tmpLeaf->Corner.x2 == Corner.x2) &&
     (tmpLeaf->Corner.y1 == Corner.y1) && (tmpLeaf->Corner.y2 == Corner.y2) )

  //YES add leaf           
  {  
    Leaf = new leaf(tmpLeaf);
  }
  else  
  // NO, add node
  {
    if(!smallestQuad()){
    if(noQuad(tmpQuadrant))
      {addNode( tmpQuadrant );}

    quadtree* tmpQuadtree;

    tmpQuadtree = returnPointerToQuad(tmpQuadrant);
    tmpQuadtree->insertLeaf(tmpLeaf);
    }
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This determines if the given quadrant exists yet.
//
// [PARAMETERS]
//    quadrant tmpQuadrant- either QUAD_ONE, QUAD_TWO, QUAD_THREE, or QUAD_FOUR
//
// [RETURN TYPE]
//    TRUE- doesn't exist yet
//    FALSE- already exists
//////////////////////////////////////////////////////////////////////
bool
quadtree::noQuad(quadrant tmpQuadrant)
{
  bool tmpReturn;
  quadtree* tmpQuadtree;

  tmpQuadtree = returnPointerToQuad(tmpQuadrant);

  if(tmpQuadtree == NULL)
    {tmpReturn = TRUE;}
  else
    {tmpReturn = FALSE;}

  return tmpReturn;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This traverses the quadtree and draws everything
//
// [NOTES]
//    THIS IS OUT OF DATE
//////////////////////////////////////////////////////////////////////
void
quadtree::drawAll(void)
{
  if(Leaf != NULL)
  {
    Leaf->drawLeaf();
  }
  else
  {
    if(quad1 != NULL){quad1->drawAll();};
    if(quad2 != NULL){quad2->drawAll();};
    if(quad3 != NULL){quad3->drawAll();};
    if(quad4 != NULL){quad4->drawAll();};
  }

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This draws everything that is close enough to a given point
//
// [PARAMETERS]
//    vector eyePosition- point to start at
//    GFX_FLOAT tmpDistance-  range to draw
//
//////////////////////////////////////////////////////////////////////
void
quadtree::draw(vector eyePosition, GFX_FLOAT tmpDistance)
{

  if(Leaf != NULL)            // Leaf exists, draw it.
  {
    Leaf->drawLeaf();
  }
  else
  {
    drawQuad(QUAD_ONE, eyePosition, tmpDistance);
    drawQuad(QUAD_TWO, eyePosition, tmpDistance);
    drawQuad(QUAD_THREE, eyePosition, tmpDistance);
    drawQuad(QUAD_FOUR, eyePosition, tmpDistance);
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    draws a given quadrant without performing any lighting/ coloring
//    effects
//
// [PARAMETERS]
//    quadrant tmpQuadrant-  quad to draw (QUAD_ONE, etc)
//    vector eyePosition - starting point
//    GFX_FLOAT tmpDistance- range to draw
//
// [NOTES]
//    Inlined for speed
//
//////////////////////////////////////////////////////////////////////
inline void
quadtree::drawQuad(quadrant tmpQuadrant, vector eyePosition, GFX_FLOAT tmpDistance)
{
  corners tmpCorner;
  quadtree* tmpQuadtree;

  tmpQuadtree = returnPointerToQuad(tmpQuadrant);

  if(tmpQuadtree == NULL)        // QUAD DOESN'T EXIST, DRAW FLOOR
  {
    tmpCorner = returnQuadCorners(tmpQuadrant);
    drawFloor(tmpCorner);   
  }
  else                    // QUAD DOES EXIST
  {                       // IF ITS CLOSE ENOUGH, GO DOWN A LEVEL
    if(onScreen(tmpQuadtree, eyePosition, tmpDistance))
      {tmpQuadtree->draw(eyePosition, tmpDistance);}
  };
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This draws everything that is within a given DISTANCE of X,Y.
//   and throws out any node that's not.   It fades the color based
//   on distance so the light falls off
//
// [PARAMETERS]
//   vector eyePosition- position of camera
//   GFX_FLOAT tmpDistance- distance range cutoff
//   GFX_FLOAT tmpthreshold- percent range to start falloff fade
//            i.e. threshold =0.75, distance =100.0 , anything before
//            distance 75 doesn't have color falloff
//////////////////////////////////////////////////////////////////////
void
quadtree::drawWithFade(vector eyePosition, GFX_FLOAT tmpDistance, GFX_FLOAT tmpThreshold)
{
  GFX_FLOAT percentFade;
  
	percentFade =  quadraticAttenuation(distanceFromPoint(eyePosition),tmpDistance) ;
  //percentFade = distanceFromPoint(eyePosition)/ tmpDistance;

  if(Leaf != NULL)            // Leaf exists, draw it.
  {
    Leaf->drawLeafWithFade(percentFade, bgcolor, tmpThreshold);
  }
  else
  {
    drawQuadWithFade(QUAD_ONE, eyePosition, percentFade, tmpDistance, tmpThreshold);
    drawQuadWithFade(QUAD_TWO, eyePosition, percentFade, tmpDistance, tmpThreshold);
    drawQuadWithFade(QUAD_THREE, eyePosition, percentFade, tmpDistance, tmpThreshold);
    drawQuadWithFade(QUAD_FOUR, eyePosition, percentFade, tmpDistance, tmpThreshold);
    tempMixColor.setColor(0.0, 0.0, 0.0);
  }
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This checks to see if a quad exists, if NOT it draws it, if SO
//   it calls drawWithFade() to continue down the quadtree.
//
// [PARAMETERS]
//   see above
// [RETURN TYPE]
//   --
// [NOTES]
//     INLINE- I just pulled it out to keep the drawWithFade() function
//             clean.
//////////////////////////////////////////////////////////////////////
inline void
quadtree::drawQuadWithFade(quadrant tmpQuadrant, vector eyePosition, GFX_FLOAT percentFade,
                           GFX_FLOAT tmpDistance, GFX_FLOAT tmpThreshold)
{
  corners tmpCorner;
  quadtree* tmpQuadtree;

  tmpQuadtree = returnPointerToQuad(tmpQuadrant);

  if(tmpQuadtree == NULL)        // QUAD DOESN'T EXIST, DRAW FLOOR
  {
    tmpCorner = returnQuadCorners(tmpQuadrant);
    if(floor || ceiling)
	{
		drawFloorWithFade(tmpQuadrant, percentFade, tmpThreshold);
	}
  }
  else                    // QUAD DOES EXIST
  {                       // IF ITS CLOSE ENOUGH, GO DOWN A LEVEL
    if(onScreen(tmpQuadtree, eyePosition, tmpDistance))
      {tmpQuadtree->drawWithFade(eyePosition, tmpDistance, tmpThreshold);}
  };
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This determines if a given Quadrant is on the screen so we know
//   if we should throw it out.
//   It currently just tests to see if its at least a certain DISTANCE
//   from position X,Y.
//
// [PARAMETERS]
//   quadtree* tmpQuad- the quadtree NODE to test
//   vector eyePosition- camera position
//   GFX_FLOAT tmpDistance- inclusive distance range
//
// [RETURN TYPE]
//   TRUE- it is onScreen
//   FALSE- it's too far away
//
// [NOTES]
//   I tried adding something that threw out anything behind the camera
//   but it didn't speed things up more than 1 fps and caused goofy
//   clipping.
//////////////////////////////////////////////////////////////////////
bool
quadtree::onScreen(quadtree* tmpQuad, vector eyePosition
                   , GFX_FLOAT tmpDistance)
{
  bool tmpReturn;

  tmpReturn = FALSE;

  if(tmpQuad->distanceFromPoint(eyePosition) < tmpDistance)
  {
    tmpReturn = TRUE;
  }

  return tmpReturn;
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This determines if this quad is the smallest possible size.  If
//   so, you can't break it up into smaller parts.
//
// [RETURN TYPE]
//   TRUE- smallest
//   FALSE- bigger
//
// [NOTES]
//   MIN_QUAD_SIZE is a constant in the header file.  It must be equal
//   to 2^n.
//   Corner.x1 should always be smaller than Corner.x2 but I'm checking
//   anyway.  This is never done while the engines running so I'm not
//   too worried about performance
//////////////////////////////////////////////////////////////////////
bool
quadtree::smallestQuad(void)
{
  bool tmpReturn;

  if(Corner.x1 < Corner.x2)
  {
    if( (Corner.x2 - Corner.x1) > MIN_QUAD_SIZE)
      {tmpReturn = FALSE;}
    else
      {tmpReturn = TRUE;}
  }
  else
  {
    if( (Corner.x2 - Corner.x1) > MIN_QUAD_SIZE)
      {tmpReturn = FALSE;}
    else
      {tmpReturn = TRUE;}
  }
  
  return tmpReturn;
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// This routine determines if the given point touches occupied space
// by seeing if point X, Y intersects with a leaf.
// Recurses through the nodes until it runs out or hits one.
//
// [PARAMETERS]
//    GFX_FLOAT x, y- the points X and Y
//
// [RETURN TYPE]
//    TRUE- point intersects with leaf
//    FALSE- point is in open space
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
quadtree::boundCheck(GFX_FLOAT x, GFX_FLOAT y)
{
  quadrant tmpQuad;
  quadtree* tmpQuadtree;
  bool tmpReturn;

  tmpQuad = whichQuad(x,y);
  tmpQuadtree = returnPointerToQuad(tmpQuad);

  if(Leaf != NULL)      //This is a leaf, intersects
  {
    tmpReturn = TRUE;
  }
  else                 // Doesn't intersect, can we jump down a level?
  {
    if(tmpQuadtree != NULL)
    {
      tmpReturn = tmpQuadtree->boundCheck(x,y);
    }
    else
    {
      tmpReturn = FALSE;   // No node, point doesnt intersect
    }
  }
  return tmpReturn;
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This calculates the appropriate global cordinates for the 
//    corners for a node based on parent's coordinates
//
// [PARAMETERS]
//    quadrant tmpQuad- QUAD_ONE, TWO etc
//
// [RETURN TYPE]
//    corners- the corners of the subQuad
//
// [NOTES]
//    This doesn't check to see if the resultant set of corners is 
//    smaller than the smallest possible quad.  use smallestQuad()
//    to double check.
//////////////////////////////////////////////////////////////////////
corners
quadtree::returnQuadCorners(quadrant tmpQuad)
{
  corners tmpCorners;

  switch(tmpQuad)
  {
    case QUAD_ONE:
      tmpCorners.x1 = (Corner.x1 + Corner.x2) / 2;
      tmpCorners.x2 = Corner.x2;
      tmpCorners.y1 = Corner.y1;
      tmpCorners.y2 = (Corner.y1 + Corner.y2) / 2;
    break;

    case QUAD_TWO:
      tmpCorners.x1 = (Corner.x1 + Corner.x2) / 2;
      tmpCorners.x2 = Corner.x2;
      tmpCorners.y1 = (Corner.y1 + Corner.y2) / 2;
      tmpCorners.y2 = Corner.y2;
    break;

    case QUAD_THREE:
      tmpCorners.x1 = Corner.x1;
      tmpCorners.x2 = (Corner.x1 + Corner.x2) / 2;
      tmpCorners.y1 = (Corner.y1 + Corner.y2) / 2;
      tmpCorners.y2 = Corner.y2;
    break;

    case QUAD_FOUR:
      tmpCorners.x1 = Corner.x1;
      tmpCorners.x2 = (Corner.x1 + Corner.x2) / 2;
      tmpCorners.y1 = Corner.y1;
      tmpCorners.y2 = (Corner.y1 + Corner.y2) / 2;
    break;
  }

  return tmpCorners;
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This draws a floor on the current Quadrant
//
// [PARAMETERS]
//   corners tmpCorner- area drawn
//
// [NOTES]
//  OBSOLITE?- Each subQuad has it's own floorcolor
//////////////////////////////////////////////////////////////////////
void
quadtree::drawFloor(corners tmpCorner)
{
	floorColor.sendGL();
	sendFloorGL(tmpCorner);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This draws a floor, diludes the color by a given PERCENT to achieve
//   light falloff, and mixes in any temporary lights that have been
//   added this iteration
//
// [PARAMETERS]
//   quadrant tmpQuadrant- QUAD_ONE, TWO, etc
//   GFX_FLOAT tmpPercent- percent to falloff
//   GFX_FLOAT tmpThreshold- limit on mixing in falloff color
//
//////////////////////////////////////////////////////////////////////
void
quadtree::drawFloorWithFade(quadrant tmpQuadrant, GFX_FLOAT tmpPercent, GFX_FLOAT tmpThreshold)
{
  corners tmpCorner;
  color tmpColor;

  switch(tmpQuadrant)
  {
    case QUAD_ONE:
      tmpColor = quad1_color;
    break;

    case QUAD_TWO:
      tmpColor = quad2_color;
    break;

    case QUAD_THREE:
      tmpColor = quad3_color;
    break;

    case QUAD_FOUR:
      tmpColor = quad4_color;
    break;
  }

  tmpCorner = returnQuadCorners(tmpQuadrant);

  tmpColor += tempMixColor;



  if(tmpThreshold < tmpPercent)
  {
    tmpColor.mixColor((*bgcolor), tmpPercent);
  }

  tmpColor.sendGL();
  sendFloorGL(tmpCorner);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sends the  actual OpenGL to draw a part of the floor
//
// [PARAMETERS]
//   corners tmpCorner- area to draw.
//
// [NOTES]
//   only draws FLOOR or CEILING if the FLOOR or CEILING bools are 
//   set to true.
//   ALSO CHECKS PREFS TO SEE IF REAL FLOOR/CEILING SHOULD EVEN
//   BE DRAWN
//////////////////////////////////////////////////////////////////////
inline void
quadtree::sendFloorGL(corners tmpCorner)
{

#ifdef PREFS_ON
	if(!Prefs.realFloor){return;}	// SKIP THIS JUNK IN REALFLOOR SET TO FALSE
#endif

  if(floor)
  {
	glBindTexture(GL_TEXTURE_2D, (*floorTexture));

	glBegin(GL_QUADS);

	glTexCoord2f(tmpCorner.x2 - tmpCorner.x1, 0.0);
	glVertex3f(tmpCorner.x2, 0.0, tmpCorner.y1);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(tmpCorner.x1, 0.0, tmpCorner.y1);
	glTexCoord2f(0.0, tmpCorner.y2 - tmpCorner.y1);
	glVertex3f(tmpCorner.x1, 0.0, tmpCorner.y2);
	glTexCoord2f(tmpCorner.x2 - tmpCorner.x1, tmpCorner.y2 - tmpCorner.y1);
	glVertex3f(tmpCorner.x2, 0.0, tmpCorner.y2);

	glEnd();
  }

  if(ceiling)
  {
	glBindTexture(GL_TEXTURE_2D, (*floorTexture + 1));

	glBegin(GL_QUADS);

	glTexCoord2f(tmpCorner.x2 - tmpCorner.x1, tmpCorner.y2 - tmpCorner.y1);
	glVertex3f(tmpCorner.x2, 3.0, tmpCorner.y2);
	glTexCoord2f(0.0, tmpCorner.y2 - tmpCorner.y1);
	glVertex3f(tmpCorner.x1, 3.0, tmpCorner.y2);
	glTexCoord2f(0.0, 0.0);
	glVertex3f(tmpCorner.x1, 3.0, tmpCorner.y1);
	glTexCoord2f(tmpCorner.x2 - tmpCorner.x1, 0.0);
	glVertex3f(tmpCorner.x2, 3.0, tmpCorner.y1);

	glEnd();
  }

}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This is used to automatically break up the quadtree into nodes
//   of at least a certain size even if there's nothing located there.
//   Usually used at initialization to balance the quadsize and make
//   lighting look better
//
// [PARAMETERS]
//   GFX_FLOAT size- MAXIMUM SIZE a bottom level quadtree NODE can be
//
//////////////////////////////////////////////////////////////////////
void
quadtree::minQuadResolution(GFX_FLOAT size)
{
  if((Corner.x2 - Corner.x1) > size)
  {
    if(quad1 == NULL){addNode(QUAD_ONE);}
    quad1->minQuadResolution(size);

    if(quad2 == NULL){addNode(QUAD_TWO);}
    quad2->minQuadResolution(size);

    if(quad3 == NULL){addNode(QUAD_THREE);}
    quad3->minQuadResolution(size);

    if(quad4 == NULL){addNode(QUAD_FOUR);}
    quad4->minQuadResolution(size);
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This returns the distance of the closest point of the
//   current quad to a given vector.
//
// [PARAMETERS]
//   vector otherVector- point to measure distance from 
//
// [RETURN TYPE]
//   GFX_FLOAT- distance
//////////////////////////////////////////////////////////////////////
GFX_FLOAT
quadtree::distanceFromPoint(vector otherVector)
{

  vector tmpVector;
  tmpVector = closestPointToPoint(otherVector);

  return tmpVector.getOtherDistance(otherVector);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This returns the distance of the closest point of an arbitrary
//   axis aligned square defined by tmpCorner to a given point 'otherVector'
//
// [PARAMETERS]
//   corners tmpCorner- square
//   vector otherVector- point
// [RETURN TYPE]
//   GFX_FLOAT- distance
//
//////////////////////////////////////////////////////////////////////
GFX_FLOAT
quadtree::distanceFromPoint(corners tmpCorner, vector otherVector)
{

  vector tmpVector;
  tmpVector = closestPointToPoint(tmpCorner, otherVector);

  return tmpVector.getOtherDistance(otherVector);
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This returns the closest point of the current quad to a given 
//   point.
// [PARAMETERS]
//   vector otherVector- point
// [RETURN TYPE]
//   vector- point on quad
//
//////////////////////////////////////////////////////////////////////
vector
quadtree::closestPointToPoint(vector otherVector)
{
  return closestPointToPoint(Corner, otherVector);
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   this returns the closest point to an arbitrary rect defined by
//   tmpCorner.  This is te workhorse routine for all the distance
//   functions
//
// [PARAMETERS]
//   corner tmpCorner- quad to check
//   vector otherVector- point
//
// [RETURN TYPE]
//   vector- distance
//
//////////////////////////////////////////////////////////////////////
vector
quadtree::closestPointToPoint(corners tmpCorner, vector otherVector)
{
  vector tmpReturn;
  GFX_FLOAT tmpX1, tmpX2,
          tmpY1, tmpY2,
          closeX, closeY;

// IF X,Y IS INSIDE QUADRANT, DISTANCE == 0
if( (otherVector.X >= tmpCorner.x1) && (otherVector.X <= tmpCorner.x2) &&
    (otherVector.Y >= tmpCorner.y1) && (otherVector.Y <= tmpCorner.y2))
  {
    closeX = otherVector.X;
    closeY = otherVector.Y;
  }
  else
  {
  // IF POINT X FALLS BETWEEN THE X COORDS, DISTANCE == THE
  // DISTANCE TO THE CLOSEST Y POINT 
  if ( (otherVector.X >= tmpCorner.x1) && (otherVector.X <= tmpCorner.x2) )
  {
    tmpY1 = abs(otherVector.Y - tmpCorner.y1);
    tmpY2 = abs(otherVector.Y - tmpCorner.y2);

    closeY = ( tmpY1 < tmpY2 ) ? tmpCorner.y1 : tmpCorner.y2;
    closeX = otherVector.X;
  }
  else
  {
  // IF POINT Y FALLS BETWEEN THE Y COORDS, DISTANCE == THE
  // DISTANCE TO THE CLOSEST X POINT 
    if ((otherVector.Y >= tmpCorner.y1) && (otherVector.Y <= tmpCorner.y2))
    {
    tmpX1 = abs( otherVector.X  - tmpCorner.x1 );
    tmpX2 = abs( otherVector.X  - tmpCorner.x2 );

    closeX = ( tmpX1 < tmpX2 ) ? tmpCorner.x1 : tmpCorner.x2;
    closeY = otherVector.Y;

    }
    else
    {
      // IF ALL ELSE FAILS, CHECK DISTANCE TO CLOSEST CORNER
      tmpX1 = abs(otherVector.X - tmpCorner.x1);
      tmpX2 = abs(otherVector.X - tmpCorner.x2);

      tmpY1 = abs(otherVector.Y - tmpCorner.y1);
      tmpY2 = abs(otherVector.Y - tmpCorner.y2);

      closeX = ( tmpX1 < tmpX2 ) ? tmpCorner.x1 : tmpCorner.x2;
      closeY = ( tmpY1 < tmpY2 ) ? tmpCorner.y1 : tmpCorner.y2;
    }
  }
}
  tmpReturn.X = closeX;
  tmpReturn.Y = closeY;

  return tmpReturn;

}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sets the floor color to the given color
//
// [PARAMETERS]
//   GFX_FLOAT tmpRed, tmpGreen, tmpBlue, tmpAlpha=  Colors
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
quadtree::setFloorColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                   GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha)
{
	floorColor.setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
  quad1_color.setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
  quad2_color.setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
  quad3_color.setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
  quad4_color.setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);

  if(quad1 != NULL)
    {quad1->setFloorColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);}

  if(quad2 != NULL)
    {quad2->setFloorColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);}

  if(quad3 != NULL)
    {quad3->setFloorColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);}

  if(quad4 != NULL)
    {quad4->setFloorColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sets the current floor color of the current quad
//
// [PARAMETERS]
//
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
quadtree::setFloorColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue)
{
  setFloorColor(tmpRed, tmpGreen, tmpBlue, 1.0);


}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// This sets the current floor color of the current quad
//
// [PARAMETERS]
//    color tmpColor- the color
//
//////////////////////////////////////////////////////////////////////
void
quadtree::setFloorColor(color tmpColor)
{
  setFloorColor(tmpColor.red, tmpColor.green, tmpColor.blue, tmpColor.alpha);
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sets the current background color, which is a STATIC MEMBER
// [PARAMETERS]
//   the color to set
//
//////////////////////////////////////////////////////////////////////
void
quadtree::setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                   GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha)
{
  bgcolor->setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sets the current background color, which is a STATIC MEMBER
// [PARAMETERS]
//   the color to set
//////////////////////////////////////////////////////////////////////
void
quadtree::setBgcolor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue)
{
  bgcolor->setColor(tmpRed, tmpGreen, tmpBlue);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This sets the current background color, which is a STATIC MEMBER
// [PARAMETERS]
//   the color to set
//////////////////////////////////////////////////////////////////////
void
quadtree::setBgcolor(color tmpColor)
{
  bgcolor->setColor(tmpColor);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This returns the pointer to an enumerated QUADRANT of the current
//   quadtree node or NULL if it doesn't exist.
// [PARAMETERS]
//   quadrant tmpQuad- QUAD_ONE, QUAD_TWO, QUAD_THREE, QUAD_FOUR
//
// [NOTES]
//   INLINE FUNCTION
//   we use this (and the enumerated quadrant type) so that each quad
//   is explicitly defined for the END-USER, instead of relying on 
//   assumptions of a quadtree array
//////////////////////////////////////////////////////////////////////
inline quadtree*
quadtree::returnPointerToQuad(quadrant tmpQuad)
{
  switch(tmpQuad)
  {
    case QUAD_ONE:
      return quad1;
    break;

    case QUAD_TWO:
      return quad2;
    break;

    case QUAD_THREE:
      return quad3;
    break;

    case QUAD_FOUR:
      return quad4;
      break;

    default:
      return NULL;
      break;
  }

}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This mixes in a temporary light to the quadtree.
// [PARAMETERS]
//   light tmpLight- light to add
//
// [NOTES]
//   This light is used for one frame and thrown away
//////////////////////////////////////////////////////////////////////
void
quadtree::mixTempColor(light tmpLight)
{
  GFX_FLOAT dist, proximity;
  vector closestPoint;

  dist = distanceFromPoint(tmpLight.Position);

  if(dist <= tmpLight.distance)
  {
    //is there a leaf to color?
    if(Leaf != NULL)
    {
      closestPoint = closestPointToPoint(tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{   
				proximity = tmpLight.distance - dist;  // light is at 100 % near vector
				Leaf->tempMixColor += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}
    }
    else  // COLOR QUAD
    {
      // light is at 100 % near vector
      proximity = (tmpLight.distance - dist) * 0.25;

      tempMixColor += tmpLight.Color * quadraticAttenuation(proximity,tmpLight.distance);    

      // we traverse the tree here
      if(quad1 != NULL){quad1->mixTempColor(tmpLight);}
      if(quad2 != NULL){quad2->mixTempColor(tmpLight);}
      if(quad3 != NULL){quad3->mixTempColor(tmpLight);}
      if(quad4 != NULL){quad4->mixTempColor(tmpLight);}
    }
  }  // ELSE do nothing, no need to traverse the tree.
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// This uses a light struct to mix in color and create a lightmap
//
// [PARAMETERS]
//   light tmpLight- light to add
//
// [NOTES]
//   this adds a permanant light.  It is impossible to undo or erase
//   if you don't want to do that use mixTempColor()
//////////////////////////////////////////////////////////////////////
void
quadtree::mixColor(light tmpLight)
{
  GFX_FLOAT dist, proximity;
  vector closestPoint;

  dist = distanceFromPoint(tmpLight.Position);

  if(dist <= tmpLight.distance)
  {

    if(Leaf != NULL)
    {
      closestPoint = closestPointToPoint(tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{
        proximity = tmpLight.distance - dist;  // light is at 100 % near vector
        Leaf->Color += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}
    }
    else
    {
      closestPoint = closestPointToPoint(returnQuadCorners(QUAD_ONE), tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{
				dist = distanceFromPoint(returnQuadCorners(QUAD_ONE), tmpLight.Position);
				proximity = (tmpLight.distance - dist) * 0.75;  
				quad1_color += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}

      closestPoint = closestPointToPoint(returnQuadCorners(QUAD_TWO), tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{
				dist = distanceFromPoint(returnQuadCorners(QUAD_TWO), tmpLight.Position);
				proximity = (tmpLight.distance - dist) * 0.75;  
				quad2_color += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}

      closestPoint = closestPointToPoint(returnQuadCorners(QUAD_THREE), tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{
				dist = distanceFromPoint(returnQuadCorners(QUAD_THREE), tmpLight.Position);
				proximity = (tmpLight.distance - dist) * 0.75; 
				quad3_color += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}

      closestPoint = closestPointToPoint(returnQuadCorners(QUAD_FOUR), tmpLight.Position);
			if(tmpLight.Position.getOtherFOV(closestPoint, tmpLight.angle, tmpLight.distance))
			{
				dist = distanceFromPoint(returnQuadCorners(QUAD_FOUR), tmpLight.Position);
				proximity = (tmpLight.distance - dist) * 0.75;  
				quad4_color += tmpLight.Color * quadraticAttenuation(proximity, tmpLight.distance);
			}

      if(quad1 != NULL){quad1->mixColor(tmpLight);}
      if(quad2 != NULL){quad2->mixColor(tmpLight);}
      if(quad3 != NULL){quad3->mixColor(tmpLight);}
      if(quad4 != NULL){quad4->mixColor(tmpLight);}
    }
  }
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This calculates a weighed percent of the two numbers.  Used
//   for light falloff calculations
//
// [PARAMETERS]
//
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
GFX_FLOAT
quadtree::quadraticAttenuation(GFX_FLOAT tmpNumber1, GFX_FLOAT tmpNumber2)
{
	return (square(tmpNumber1) / square(tmpNumber2));
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This deletes any Leafs contained in the given rectangle
//
// [PARAMETERS]
//   corners tmpCorner- the rectangle 
//
// [NOTES]
//   uses the cleanArea() function to get rid of any unnecessary
//   nodes
//////////////////////////////////////////////////////////////////////
void
quadtree::clearArea(corners tmpCorner)
{
	if( Corner.x1 >= tmpCorner.x1 && Corner.x2 <= tmpCorner.x2 &&
		Corner.y1 >= tmpCorner.y1 && Corner.y2 <= tmpCorner.y2)
	{  // entire area is in range to clear.
		if(Leaf != NULL){delete Leaf; Leaf = NULL;}
		if(quad1 != NULL){delete quad1; quad1 = NULL;}
		if(quad2 != NULL){delete quad2; quad2 = NULL;}
		if(quad3 != NULL){delete quad3; quad3 = NULL;}
		if(quad4 != NULL){delete quad4; quad4 = NULL;}
	}
	else
	{
		if(quad1 != NULL){quad1->clearArea(tmpCorner);}
		if(quad2 != NULL){quad2->clearArea(tmpCorner);}
		if(quad3 != NULL){quad3->clearArea(tmpCorner);}
		if(quad4 != NULL){quad4->clearArea(tmpCorner);}
	}

	if(cleanArea(QUAD_ONE))
	{
		delete quad1;
		quad1 = NULL;
	}

	if(cleanArea(QUAD_TWO))
	{
		delete quad2;
		quad2 = NULL;
	}

	if(cleanArea(QUAD_THREE))
	{
		delete quad3;
		quad3 = NULL;
	}

	if(cleanArea(QUAD_FOUR))
	{
		delete quad4;
		quad4 = NULL;
	}
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This determines if a quadrant contains nothing.  If it doesn't 
//   contain anything there's no reason to keep it around
//
// [PARAMETERS]
//   quadrant Quad- quad to check
//
// [RETURN TYPE]
//   TRUE- Contains nothing
//   FALSE- still has something in it
//
//////////////////////////////////////////////////////////////////////
bool
quadtree::cleanArea(quadrant Quad)
{
	quadtree* tmpQuad;

	tmpQuad = returnPointerToQuad(Quad);

	if(tmpQuad != NULL)
	{
		if(tmpQuad->Leaf == NULL && tmpQuad->quad1 == NULL && tmpQuad->quad2 == NULL &&
			tmpQuad->quad3 == NULL && tmpQuad->quad4 == NULL &&
			(tmpQuad->Corner.x2 - tmpQuad->Corner.x1 < resolution) )
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}

	return FALSE;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This traverses the Quadtree so we can count the number of leaves
//
// [PARAMETERS]
//    --
// [RETURN TYPE]
//   int- number of leaves
// [NOTES]
//   You can use this to judge the speed the level will work at.
//   It's also needed to write the LEVEL FILE
//////////////////////////////////////////////////////////////////////
int
quadtree::leafCount(void)
{
	int	tmpReturn = 0;

	if(Leaf != NULL)
	{
		tmpReturn = 1;
	}
	else
	{
		if(quad1 != NULL)
			{tmpReturn += quad1->leafCount();}

		if(quad2 != NULL)
			{tmpReturn += quad2->leafCount();}

		if(quad3 != NULL)
			{tmpReturn += quad3->leafCount();}

		if(quad4 != NULL)
			{tmpReturn += quad4->leafCount();}
	}

	return tmpReturn;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    This recursively writes all leafs to a file.
//
// [PARAMETERS]
//    HANDLE saveFile- the file to write to.
//
// [NOTES]
//    USES WINDOWS FILE I/O
//////////////////////////////////////////////////////////////////////
void
quadtree::writeLeaf(HANDLE saveFile)
{
	DWORD	dwNumWritten;

	if(Leaf != NULL)
	{
		WriteFile(saveFile, Leaf, sizeof(leaf), &dwNumWritten, NULL);
	}
	else
	{
		if(quad1 != NULL)
			{quad1->writeLeaf(saveFile);}

		if(quad2 != NULL)
			{quad2->writeLeaf(saveFile);}

		if(quad3 != NULL)
			{quad3->writeLeaf(saveFile);}

		if(quad4 != NULL)
			{quad4->writeLeaf(saveFile);}
	}
}