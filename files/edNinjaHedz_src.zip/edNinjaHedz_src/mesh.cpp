#include "mesh.h"

/*******************************************************************************
* MESH:
* This holds the mesh and skin and provides functions to send GL load and save
*******************************************************************************/

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// Default constructor.
//////////////////////////////////////////////////////////////////////
mesh::mesh(void)
{
	frames = 0;

	triangleCount = 0;
	triangleData = NULL;

	texPointCount = 0;
	texPointData = NULL;

	pointCount = 0;
	pointData = NULL;

	textureInfo = NULL;
	textureID = 0;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// parameterized constructor
//
// [PURPOSE]
// Loads in a file and binds the texture to openGL
//
// [DEPENDENCIES]
// Takes a WINDOWS TCHAR type
//////////////////////////////////////////////////////////////////////
mesh::mesh(TCHAR* filename)
{
	frames = 0;

	triangleCount = 0;
	triangleData = NULL;

	texPointCount = 0;
	texPointData = NULL;

	pointCount = 0;
	pointData = NULL;

	textureInfo = NULL;
	textureID = 0;

	loadFile(filename);
	glGenTextures(1, &textureID);
	textureInfo->bindTexture(textureID);
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// Destructor
//////////////////////////////////////////////////////////////////////
mesh::~mesh(void)
{
	glDeleteTextures(1, &textureID);
		
	// should delete textureInfo and texelData
	delete[] triangleData;
	delete[] texPointData;
	delete[] pointData;

	delete textureInfo;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// Copy Constructor
//
// [PURPOSE]
// The class has pointer members.  Have to watch new & delete
//////////////////////////////////////////////////////////////////////
mesh::mesh(const mesh& otherMesh)
{
	int i;	// for allocations

	frames = otherMesh.frames;

	textureID = otherMesh.textureID;

	triangleCount = otherMesh.triangleCount;
	texPointCount = otherMesh.texPointCount;
	pointCount = otherMesh.pointCount;

	delete[] triangleData;
	triangleData = new triangleInfo[triangleCount];

	for(i = 0; i < triangleCount; i++)
	{
		triangleData[i] = otherMesh.triangleData[i];
	}

	delete[] texPointData;
	texPointData = new texPointInfo[texPointCount];

	for(i = 0; i < texPointCount; i++)
	{
		texPointData[i] = otherMesh.texPointData[i];
	}

	delete[] pointData;
	pointData = new pointInfo[pointCount * frames];

	for(i = 0; i < pointCount * frames; i++)
	{
		pointData[i] = otherMesh.pointData[i];
	}

	textureInfo = otherMesh.textureInfo;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// Operator = 
//
// [PURPOSE]
// The class has pointer members.  Have to watch new & delete
//////////////////////////////////////////////////////////////////////
mesh& 
mesh::operator=(const mesh& otherMesh)
{
	int i;	// for allocations

	if(this != &otherMesh)
	{
		frames = otherMesh.frames;

		textureID = otherMesh.textureID;

		triangleCount = otherMesh.triangleCount;
		texPointCount = otherMesh.texPointCount;
		pointCount = otherMesh.pointCount;

		delete[] triangleData;
		triangleData = new triangleInfo[triangleCount];

		for(i = 0; i < triangleCount; i++)
		{
			triangleData[i] = otherMesh.triangleData[i];
		}

		delete[] texPointData;
		texPointData = new texPointInfo[texPointCount];

		for(i = 0; i < texPointCount; i++)
		{
			texPointData[i] = otherMesh.texPointData[i];
		}

		delete[] pointData;
		pointData = new pointInfo[pointCount * frames];

		for(i = 0; i < pointCount * frames; i++)	
		{
			pointData[i] = otherMesh.pointData[i];
		}

		textureInfo = otherMesh.textureInfo;
	}

	return *this;
}

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
// DRAW
//
// [PURPOSE]
// Issues the OpenGL to draw the mesh
//
// [DEPENDENCIES]
// Requires a material color from the lightmap
//////////////////////////////////////////////////////////////////////
void
mesh::draw(color tmpColor, int tmpFrame)
{
	int i, currentFrame;

	currentFrame = tmpFrame - 1;

	glBindTexture(GL_TEXTURE_2D, textureID);

	tmpColor.sendGL();

	glBegin(GL_TRIANGLES);

	for(i = 0; i < triangleCount; i++)
	{
		glTexCoord2fv((float *) &texPointData[triangleData[i].texOne ]);
		glVertex4fv((float *) &pointData[ (currentFrame * pointCount) + triangleData[i].one]);
		
		glTexCoord2fv((float *) &texPointData[triangleData[i].texTwo ]);
		glVertex4fv((float *) &pointData[ (currentFrame * pointCount) + triangleData[i].two]);

		glTexCoord2fv((float *) &texPointData[triangleData[i].texThree ]);
		glVertex4fv((float *) &pointData[ (currentFrame * pointCount) + triangleData[i].three]);
		
	}
  
	glEnd();

}

//////////////////////////////////////////////////////////////////////
// loadFile
// reads in a mesh file
// uses windows file functions and windows TCHAR type
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
mesh::loadFile(TCHAR *filename)
{
	HANDLE		lFile;
	DWORD		numWritten;

	lFile = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ, NULL,
			 OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(lFile == INVALID_HANDLE_VALUE)
	{
		//couldn't create
		GFX_FatalError("Unable to load file.", "mesh::loadFile");
		return FALSE;
	}

	// clean-up before we do anything
	delete[] triangleData;
	delete[] texPointData;
	delete[] pointData;

	delete textureInfo;
	// read header
	ReadFile(lFile, this, sizeof(mesh), &numWritten, NULL);

	//ALLOCATE
	//texture array
	triangleData = new triangleInfo[triangleCount];
	ReadFile(lFile, triangleData, sizeof(triangleInfo) * triangleCount, &numWritten, NULL);

	texPointData = new texPointInfo[texPointCount];
	ReadFile(lFile, texPointData, sizeof(texPointInfo) * texPointCount, &numWritten, NULL);

	pointData = new pointInfo[pointCount * frames];
	ReadFile(lFile, pointData, sizeof(pointInfo) * pointCount * frames, &numWritten, NULL);

	//texture info
	textureInfo = new GFX_TextureInfo;

	ReadFile(lFile, textureInfo, sizeof(GFX_TextureInfo), &numWritten, NULL);

	textureInfo->texelData = new GLubyte[textureInfo->width * textureInfo->height * 4];
	ReadFile(lFile, textureInfo->texelData, sizeof(GLubyte) * textureInfo->width *
		textureInfo->height * 4, &numWritten, NULL);

	CloseHandle(lFile);

	return TRUE;
}

//////////////////////////////////////////////////////////////////////
// saveFile
// saves the mesh in a file
// uses windows file functions and windows TCHAR type
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//
// [PARAMETERS]
// 
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
bool
mesh::saveFile(TCHAR *filename)
{
	HANDLE		sFile;
	DWORD		numWritten;

	sFile = CreateFile(filename, GENERIC_WRITE,
				FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if(sFile == INVALID_HANDLE_VALUE)
	{
		//couldn't create
		GFX_ErrorMessage( "Unable to save file.", "mesh::saveFile");
		return FALSE;
	}

	WriteFile(sFile, this, sizeof(mesh),  &numWritten, NULL);

	// triangle info
	WriteFile(sFile, triangleData, sizeof(triangleInfo) * triangleCount, &numWritten, NULL);

	WriteFile(sFile, texPointData, sizeof(texPointInfo) * texPointCount, &numWritten, NULL);

	WriteFile(sFile, pointData, sizeof(pointInfo) * pointCount * frames, &numWritten, NULL);

	//textureInfo
	WriteFile(sFile, textureInfo , sizeof(GFX_TextureInfo), &numWritten, NULL);
	WriteFile(sFile, textureInfo->texelData, sizeof(GLubyte) * textureInfo->width * textureInfo->height * 4,
		&numWritten, NULL);
	

	CloseHandle(sFile);

	return TRUE;
}
