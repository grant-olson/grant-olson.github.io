#include "editor.h"
#include "gfxTypes.h"


////////////////////////////////////////////////////////////
//
// Procedure for NEW FILE dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgNewFileProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hdlg, IDC_WORLD_SIZE, 512, TRUE);
		SetDlgItemInt(hdlg, IDC_QUAD_SIZE, 32, TRUE);

		SetDlgItemInt(hdlg, IDC_BG_RED, 10, TRUE);
		SetDlgItemInt(hdlg, IDC_BG_GREEN, 10, TRUE);
		SetDlgItemInt(hdlg, IDC_BG_BLUE, 10, TRUE);

		CheckDlgButton(hdlg, IDC_FLOOR, BST_CHECKED);
		SetDlgItemInt(hdlg, IDC_FLOOR_RED, 50, TRUE);
		SetDlgItemInt(hdlg, IDC_FLOOR_GREEN, 50, TRUE);
		SetDlgItemInt(hdlg, IDC_FLOOR_BLUE, 50, TRUE);

		CheckDlgButton(hdlg, IDC_FADE_ON, BST_CHECKED);
		SetDlgItemInt(hdlg, IDC_FADE_THRESHOLD, 0, TRUE);

		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:

			cleanUpEditor();
			
			delete World;

			World = new world((GLfloat) GetDlgItemInt(hdlg, IDC_WORLD_SIZE, NULL, TRUE),
				               (GLfloat) GetDlgItemInt(hdlg, IDC_QUAD_SIZE, NULL, TRUE));

			World->setBgcolor(
				            ((GLfloat) GetDlgItemInt(hdlg, IDC_BG_RED, NULL, TRUE)) / 100.0 ,
							((GLfloat) GetDlgItemInt(hdlg, IDC_BG_GREEN, NULL, TRUE)) / 100.0,
							((GLfloat) GetDlgItemInt(hdlg, IDC_BG_BLUE, NULL, TRUE)) / 100.0);

			World->Quadtree->setFloorColor(
				            (GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_RED, NULL, TRUE) / 100.0 ,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_GREEN, NULL, TRUE) / 100.0,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_BLUE, NULL, TRUE) / 100.0);

			editLeaf.Color.setColor(
				            (GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_RED, NULL, TRUE) / 100.0 ,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_GREEN, NULL, TRUE) / 100.0,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_BLUE, NULL, TRUE) / 100.0);

			World->Quadtree->floor = IsDlgButtonChecked(hdlg, IDC_FLOOR) ? TRUE : FALSE;
			World->Quadtree->ceiling = IsDlgButtonChecked(hdlg, IDC_CEILING) ? TRUE : FALSE;

			World->Quadtree->floorTexture = World->textureID;

			World->fadeOn = IsDlgButtonChecked(hdlg, IDC_FADE_ON) ? TRUE : FALSE;
			World->fadeThreshold = (GLfloat) GetDlgItemInt(hdlg, IDC_FADE_THRESHOLD, NULL, TRUE) / 100.0;
			EndDialog(hdlg, TRUE);
			return TRUE;

		case IDCANCEL:
			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

////////////////////////////////////////////////////////////
//
// Procedure for EDIT WORLD dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgEditWorldProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hdlg, IDC_BG_RED, (int)(World->bgcolor.red * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_BG_GREEN, (int)(World->bgcolor.green * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_BG_BLUE, (int)(World->bgcolor.blue * 100), TRUE);

		CheckDlgButton(hdlg, IDC_FLOOR, World->Quadtree->floor ? BST_CHECKED : BST_UNCHECKED);
		CheckDlgButton(hdlg, IDC_CEILING, World->Quadtree->ceiling ? BST_CHECKED : BST_UNCHECKED);
		SetDlgItemInt(hdlg, IDC_FLOOR_RED, (int)(World->Quadtree->floorColor.red * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_FLOOR_GREEN, (int)(World->Quadtree->floorColor.green * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_FLOOR_BLUE, (int)(World->Quadtree->floorColor.blue * 100), TRUE);

		CheckDlgButton(hdlg, IDC_FADE_ON, World->fadeOn ? BST_CHECKED : BST_UNCHECKED);
		SetDlgItemInt(hdlg, IDC_FADE_THRESHOLD, (int)(World->fadeThreshold * 100), TRUE);

		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			World->setBgcolor(
				            ((GLfloat) GetDlgItemInt(hdlg, IDC_BG_RED, NULL, TRUE)) / 100.0 ,
							((GLfloat) GetDlgItemInt(hdlg, IDC_BG_GREEN, NULL, TRUE)) / 100.0,
							((GLfloat) GetDlgItemInt(hdlg, IDC_BG_BLUE, NULL, TRUE)) / 100.0);

			World->Quadtree->setFloorColor(
				            (GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_RED, NULL, TRUE) / 100.0 ,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_GREEN, NULL, TRUE) / 100.0,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_BLUE, NULL, TRUE) / 100.0);

			editLeaf.Color.setColor(
				            (GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_RED, NULL, TRUE) / 100.0 ,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_GREEN, NULL, TRUE) / 100.0,
							(GLfloat) GetDlgItemInt(hdlg, IDC_FLOOR_BLUE, NULL, TRUE) / 100.0);


			World->Quadtree->floor = IsDlgButtonChecked(hdlg, IDC_FLOOR) ? TRUE : FALSE;
			World->Quadtree->ceiling = IsDlgButtonChecked(hdlg, IDC_CEILING) ? TRUE : FALSE;

			World->fadeOn = IsDlgButtonChecked(hdlg, IDC_FADE_ON) ? TRUE : FALSE;
			World->fadeThreshold = (GLfloat) GetDlgItemInt(hdlg, IDC_FADE_THRESHOLD, NULL, TRUE) / 100.0;

		case IDCANCEL:
			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}


////////////////////////////////////////////////////////////
//
// Procedure for ADD LIGHT dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgAddLightProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static light* lightPtr;
	static light tmpLight;

	int tmpX, tmpY;   // for negative #s

	switch(message)
	{
	case WM_INITDIALOG:
		//create light info
		lightPtr = (light*) lParam;
		tmpLight = (*lightPtr);

		if(tmpLight.distance < 10.0){tmpLight.distance = 10.0;}

		SetDlgItemInt(hdlg, IDC_X, (int) tmpLight.Position.X, TRUE);
		SetDlgItemInt(hdlg, IDC_Y, (int) tmpLight.Position.Y, TRUE);
		SetDlgItemInt(hdlg, IDC_DIRECTION, (int) tmpLight.Position.degrees, TRUE);
		SetDlgItemInt(hdlg, IDC_RED, (int) (tmpLight.Color.red * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_GREEN, (int) (tmpLight.Color.green * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_BLUE, (int) (tmpLight.Color.blue * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_DISTANCE , (int) tmpLight.distance, TRUE);
		SetDlgItemInt(hdlg, IDC_ANGLE, (int) tmpLight.angle, TRUE);
		
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			//for negative #s
			tmpX = GetDlgItemInt(hdlg, IDC_X, NULL, TRUE);
			tmpY = GetDlgItemInt(hdlg, IDC_Y, NULL, TRUE);
			
			tmpLight.Position.X = (GLfloat) tmpX;
			tmpLight.Position.Y = (GLfloat) tmpY;
			tmpLight.Position.setAngle( (GLfloat) GetDlgItemInt(hdlg, IDC_DIRECTION, NULL, TRUE));
			tmpLight.Color.setColor( ((GLfloat) GetDlgItemInt(hdlg, IDC_RED, NULL, TRUE)) / 100,
				                     ((GLfloat) GetDlgItemInt(hdlg, IDC_GREEN , NULL, TRUE)) / 100,
									 ((GLfloat) GetDlgItemInt(hdlg, IDC_BLUE, NULL, TRUE)) / 100);
			tmpLight.distance = (GLfloat) (GetDlgItemInt(hdlg, IDC_DISTANCE, NULL, TRUE));
			tmpLight.angle = (GLfloat) (GetDlgItemInt(hdlg, IDC_ANGLE, NULL, TRUE));

			(*lightPtr) = tmpLight;

			EndDialog(hdlg, TRUE);
			return TRUE;

		case IDCANCEL:
			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

////////////////////////////////////////////////////////////
//
// Procedure for ADD ENEMY dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgAddEnemyProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static enemyInfo* enemyPtr;
	static enemyInfo tmpEnemy;

	int tmpX, tmpY;   // for negative #s
	int tmpEnemyType;
	HWND	hwndEnemyType = GetDlgItem(hdlg, IDC_ENEMY_TYPE);

	switch(message)
	{
	case WM_INITDIALOG:
		//create enemy info
		enemyPtr = (enemyInfo*) lParam;
		tmpEnemy = (*enemyPtr);

		SetDlgItemInt(hdlg, IDC_X, (int) tmpEnemy.Position.X, TRUE);
		SetDlgItemInt(hdlg, IDC_Y, (int) tmpEnemy.Position.Y, TRUE);
		SetDlgItemInt(hdlg, IDC_DIRECTION, (int) tmpEnemy.Position.degrees, TRUE);

		// Init Combo Box
		DWORD	dwIndex;
		char	szTemp[256];

		tmpEnemyType = 0;

		wsprintf(szTemp, "Head");

		dwIndex = SendMessage(hwndEnemyType, CB_ADDSTRING, 0, (LPARAM) (LPCSTR) szTemp);
		SendMessage(hwndEnemyType, CB_SETITEMDATA, dwIndex, (LPARAM) HEAD);
		if(tmpEnemy.Type == HEAD)
			{tmpEnemyType = dwIndex;}

		wsprintf(szTemp, "Head II");

		dwIndex = SendMessage(hwndEnemyType, CB_ADDSTRING, 0, (LPARAM) (LPCSTR) szTemp);
		SendMessage(hwndEnemyType, CB_SETITEMDATA, dwIndex, (LPARAM) HEADII);
		if(tmpEnemy.Type == HEADII)
			{tmpEnemyType = dwIndex;}
		
        SendMessage(hwndEnemyType , CB_SETCURSEL, (WPARAM) tmpEnemyType, 0); 
 		
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			//for negative #s
			tmpX = GetDlgItemInt(hdlg, IDC_X, NULL, TRUE);
			tmpY = GetDlgItemInt(hdlg, IDC_Y, NULL, TRUE);
			
			tmpEnemy.Position.X = (GLfloat) tmpX;
			tmpEnemy.Position.Y = (GLfloat) tmpY;
			tmpEnemy.Position.setAngle( (GLfloat) GetDlgItemInt(hdlg, IDC_DIRECTION, NULL, TRUE));

			tmpEnemyType = SendMessage(hwndEnemyType, CB_GETCURSEL, 0, 0);
			tmpEnemy.Type = (sprite_type)SendMessage(hwndEnemyType, CB_GETITEMDATA, (WPARAM) tmpEnemyType, 0);

			(*enemyPtr) = tmpEnemy;

			EndDialog(hdlg, TRUE);
			return TRUE;

		case IDCANCEL:
			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

////////////////////////////////////////////////////////////
//
// Procedure for SET PLAYER dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgSetPlayerProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static vector* positionPtr;
	static vector tmpVector;

	int tmpX, tmpY;   // for negative #s

	switch(message)
	{
	case WM_INITDIALOG:
		//create light info
		positionPtr = (vector*) lParam;
		tmpVector = (*positionPtr);

		SetDlgItemInt(hdlg, IDC_X, (int) tmpVector.X, TRUE);
		SetDlgItemInt(hdlg, IDC_Y, (int) tmpVector.Y, TRUE);
		SetDlgItemInt(hdlg, IDC_DIRECTION, (int) tmpVector.degrees, TRUE);
		
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			//for negative #s
			tmpX = GetDlgItemInt(hdlg, IDC_X, NULL, TRUE);
			tmpY = GetDlgItemInt(hdlg, IDC_Y, NULL, TRUE);
			
			tmpVector.X = (GLfloat) tmpX;
			tmpVector.Y = (GLfloat) tmpY;
			tmpVector.setAngle( (GLfloat) GetDlgItemInt(hdlg, IDC_DIRECTION, NULL, TRUE));

			(*positionPtr) = tmpVector;

			EndDialog(hdlg, TRUE);
			return TRUE;

		case IDCANCEL:
			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}


////////////////////////////////////////////////////////////
//
// Procedure for ADD PRIMITIVE dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgAddPrimitiveProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	corners tmpCorners;
	static int	x1 = 0, x2 = 0, y1 = 0, y2 = 0;

	switch(message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hdlg, IDC_X1, x1, TRUE);
		SetDlgItemInt(hdlg, IDC_X2, x2, TRUE);
		SetDlgItemInt(hdlg, IDC_Y1, y1, TRUE);
		SetDlgItemInt(hdlg, IDC_Y2, y2, TRUE);
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			x1 = GetDlgItemInt(hdlg, IDC_X1, NULL, TRUE);
			x2 = GetDlgItemInt(hdlg, IDC_X2, NULL, TRUE);
			y1 = GetDlgItemInt(hdlg, IDC_Y1, NULL, TRUE);
			y2 = GetDlgItemInt(hdlg, IDC_Y2, NULL, TRUE);

			tmpCorners.x1 = (GLfloat) x1;
			tmpCorners.x2 = (GLfloat) x2;
			tmpCorners.y1 = (GLfloat) y1;
			tmpCorners.y2 = (GLfloat) y2;

			World->addPrimitive(tmpCorners, editLeaf);

		case IDCANCEL:

			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

////////////////////////////////////////////////////////////
//
// Procedure for Current Texture dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgCurrentTextureProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC				dlgHdc;
	PAINTSTRUCT		ps;
	int				i, j;
	int				tmpX, tmpY;
	COLORREF		pixelColor;
	static int		texturePaddingX = 100;
	static int		texturePaddingY = 15;
	GFX_TextureInfo		loadTexture;
	GFX_TextureInfo*	tmpTexture;
	static	TCHAR	szLoadFile[40] = TEXT("\0");

	switch(message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hdlg, IDC_TEX_NO,(int)editLeaf.textureIndex, TRUE);
		SetDlgItemInt(hdlg, IDC_RED, (int)(editLeaf.Color.red * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_GREEN, (int)(editLeaf.Color.green * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_BLUE, (int)(editLeaf.Color.blue * 100), TRUE);
		SetDlgItemInt(hdlg, IDC_HEIGHT, (int)editLeaf.height, TRUE);

		tmpTexture = World->getPtrToTexture(editLeaf.textureIndex);

		if(tmpTexture != NULL)
		{
			if(tmpTexture->wrapS == GL_REPEAT )
				SendDlgItemMessage(hdlg, IDC_WRAP_S,  BM_SETCHECK, TRUE, 0);

			if(tmpTexture->wrapT == GL_REPEAT )
				SendDlgItemMessage(hdlg, IDC_WRAP_T,  BM_SETCHECK, TRUE, 0);

			if(tmpTexture->magFilter == GL_LINEAR )
				SendDlgItemMessage(hdlg, IDC_MAG_LIN,  BM_SETCHECK, TRUE, 0);

			if(tmpTexture->minFilter == GL_LINEAR )
				SendDlgItemMessage(hdlg, IDC_MIN_LIN,  BM_SETCHECK, TRUE, 0);
		}

		return TRUE;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{

		case IDC_RED:
			if(HIWORD(wParam) == EN_UPDATE)
				editLeaf.Color.red =(GLfloat)(GetDlgItemInt(hdlg, IDC_RED, NULL, TRUE)) / 100;
			break;

		case IDC_GREEN:
			if(HIWORD(wParam) == EN_UPDATE)
				editLeaf.Color.green =(GLfloat)(GetDlgItemInt(hdlg, IDC_GREEN, NULL, TRUE)) / 100;
			break;

		case IDC_BLUE:
			if(HIWORD(wParam) == EN_UPDATE)
				editLeaf.Color.blue = (GLfloat)(GetDlgItemInt(hdlg, IDC_BLUE, NULL, TRUE)) / 100;
			break;

		case IDC_HEIGHT:
			if(HIWORD(wParam) == EN_UPDATE)
				editLeaf.height = (GLfloat)(GetDlgItemInt(hdlg, IDC_HEIGHT, NULL, TRUE));
			break;

		case IDC_ADD_NEW:

			ofn.hwndOwner		= hdlg;
			ofn.lpstrFile		= szLoadFile;
			ofn.lpstrFileTitle	= NULL;
			ofn.Flags			= OFN_HIDEREADONLY;
			//file info for bmp files
			ofn.lpstrFilter			= TEXT("Windows Bitmap Files (*.bmp)\0*.bmp\0");
			ofn.lpstrDefExt			= TEXT("bmp");

			GetOpenFileName(&ofn);
			
			if(szLoadFile[0] != '\0')
			{
				loadTexture.loadBMP(szLoadFile);
				World->addNewTexture(loadTexture);
				editLeaf.textureIndex = World->textureCount - 1;
				SetDlgItemInt(hdlg, IDC_TEX_NO, (int) editLeaf.textureIndex, TRUE);
			}
			break;

		case IDC_CHANGE_CURRENT:

			ofn.hwndOwner		= hdlg;
			ofn.lpstrFile		= szLoadFile;
			ofn.lpstrFileTitle	= NULL;
			ofn.Flags			= OFN_HIDEREADONLY;
			//file info for bmp files
			ofn.lpstrFilter			= TEXT("Windows Bitmap Files (*.bmp)\0*.bmp\0");
			ofn.lpstrDefExt			= TEXT("bmp");
			
			GetOpenFileName(&ofn);
			
			if(szLoadFile[0] != '\0')
			{
				tmpTexture = World->getPtrToTexture(editLeaf.textureIndex);
				tmpTexture->loadBMP(szLoadFile);
				tmpTexture->bindTexture(World->textureID[editLeaf.textureIndex]);
			}
			break;
		}
		break;

	case WM_VSCROLL:
		switch(LOWORD(wParam))
		{
		case SB_LINEUP:
			if(editLeaf.textureIndex < World->textureCount - 1)
			{
				editLeaf.textureIndex += 1;
			}
			break;

		case SB_LINEDOWN:
			if(editLeaf.textureIndex > 0)
			{
				editLeaf.textureIndex -= 1;
			}
			break;

		default:
			return FALSE;
		}
		SetDlgItemInt(hdlg, IDC_TEX_NO, editLeaf.textureIndex, TRUE);

		tmpTexture = World->getPtrToTexture(editLeaf.textureIndex);
		
		if(tmpTexture != NULL)
		{
			SendDlgItemMessage(hdlg, IDC_WRAP_S,  BM_SETCHECK, 
				tmpTexture->wrapS == GL_REPEAT ? TRUE : FALSE, 0);

			SendDlgItemMessage(hdlg, IDC_WRAP_T,  
				BM_SETCHECK, tmpTexture->wrapT == GL_REPEAT ? TRUE : FALSE, 0);

			SendDlgItemMessage(hdlg, IDC_MAG_LIN,  
				BM_SETCHECK, tmpTexture->magFilter == GL_LINEAR ? TRUE : FALSE, 0);

			SendDlgItemMessage(hdlg, IDC_MIN_LIN, 
				BM_SETCHECK, tmpTexture->magFilter == GL_LINEAR ? TRUE : FALSE, 0);
		}

		InvalidateRect(hdlg, NULL, TRUE);
		return TRUE;


	case WM_PAINT:
		dlgHdc = BeginPaint(hdlg, &ps);

		tmpTexture = World->getPtrToTexture(editLeaf.textureIndex);
		
		if(tmpTexture != NULL)
		{
			tmpX = texturePaddingX + (j * 2);
			tmpY = texturePaddingY + ((tmpTexture->height - i) * 2);

			if(tmpTexture->texelData != NULL)
			{
			for(i = 0; i < tmpTexture->height; i++)
				for(j = 0; j < tmpTexture->width; j++)
				{
					tmpX = texturePaddingX + (j * 2);
					tmpY = texturePaddingY + (tmpTexture->height - i) * 2;
			
					// grabs from texture struct
					if(tmpTexture->texelData != NULL)
					{
					pixelColor = RGB(
						*(tmpTexture->texelData + ((i * tmpTexture->width + j) * 4)),
						*(tmpTexture->texelData + ((i * tmpTexture->width + j) * 4) + 1),
						*(tmpTexture->texelData + ((i * tmpTexture->width + j) * 4) + 2));
					}
					else
					{
						pixelColor = RGB(255,255,255);
					}

					SetPixel(dlgHdc, tmpX,     tmpY,     pixelColor);
					SetPixel(dlgHdc, tmpX + 1, tmpY + 1, pixelColor);
					SetPixel(dlgHdc, tmpX + 1, tmpY,     pixelColor);
				SetPixel(dlgHdc, tmpX ,    tmpY + 1, pixelColor);
				}
			}
		}

		EndPaint(hdlg, &ps);
		
		return TRUE;


	case WM_CLOSE:
		DestroyWindow (hdlg);
		hDlgCurrentTexture = NULL;
		return TRUE;
	}

	return FALSE;
}
////////////////////////////////////////////////////////////
//
// Procedure for CLEAR AREA dialog
//
////////////////////////////////////////////////////////////
BOOL CALLBACK dlgClearAreaProc(HWND hdlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	corners tmpCorners;
	static int	x1 = 0, x2 = 0, y1 = 0, y2 = 0;

	switch(message)
	{
	case WM_INITDIALOG:
		SetDlgItemInt(hdlg, IDC_X1, x1, TRUE);
		SetDlgItemInt(hdlg, IDC_X2, x2, TRUE);
		SetDlgItemInt(hdlg, IDC_Y1, y1, TRUE);
		SetDlgItemInt(hdlg, IDC_Y2, y2, TRUE);
		return TRUE;

	case WM_COMMAND:
		switch(LOWORD (wParam))
		{
		case IDOK:
			x1 = GetDlgItemInt(hdlg, IDC_X1, NULL, TRUE);
			x2 = GetDlgItemInt(hdlg, IDC_X2, NULL, TRUE);
			y1 = GetDlgItemInt(hdlg, IDC_Y1, NULL, TRUE);
			y2 = GetDlgItemInt(hdlg, IDC_Y2, NULL, TRUE);

			tmpCorners.x1 = (GLfloat) x1;
			tmpCorners.x2 = (GLfloat) x2;
			tmpCorners.y1 = (GLfloat) y1;
			tmpCorners.y2 = (GLfloat) y2;

			World->deleteArea(tmpCorners);

		case IDCANCEL:

			EndDialog(hdlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}