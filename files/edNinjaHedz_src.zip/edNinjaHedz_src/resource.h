//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_ADD_PRIMITIVE               105
#define IDD_NEW_FILE                    107
#define IDD_EDIT_WORLD                  108
#define IDD_CLEAR_AREA                  109
#define IDD_ADD_LIGHT                   111
#define IDD_ADD_ENEMY                   112
#define IDD_SET_PLAYER                  113
#define IDD_CURRENT_TEXTURE             114
#define IDD_STATUS                      117
#define IDC_X1                          1000
#define IDC_Y1                          1001
#define IDC_TEXT_X1                     1002
#define IDC_TEXT_Y1                     1003
#define IDC_X2                          1004
#define IDC_Y2                          1005
#define IDC_TEXT_X2                     1006
#define IDC_TEXT_Y2                     1007
#define IDC_WORLD_SIZE                  1018
#define IDC_QUAD_SIZE                   1019
#define IDC_BG_RED                      1020
#define IDC_BG_GREEN                    1021
#define IDC_BG_BLUE                     1022
#define IDC_FADE_ON                     1023
#define IDC_FADE_THRESHOLD              1024
#define IDC_FLOOR_RED                   1025
#define IDC_FLOOR_GREEN                 1026
#define IDC_FLOOR_BLUE                  1027
#define IDC_FLOOR                       1028
#define IDC_CEILING                     1029
#define IDC_RED                         1030
#define IDC_GREEN                       1031
#define IDC_BLUE                        1032
#define IDC_X                           1035
#define IDC_Y                           1036
#define IDC_DIRECTION                   1037
#define IDC_DISTANCE                    1041
#define IDC_ANGLE                       1042
#define IDC_ENEMY_TYPE                  1043
#define IDC_TEX_NO                      1048
#define IDC_SCROLL_CURRENT              1049
#define IDC_ADD_NEW                     1050
#define IDC_CHANGE_CURRENT              1051
#define IDC_HEIGHT                      1055
#define IDC_WRAP_S                      1056
#define IDC_WRAP_T                      1057
#define IDC_MIN_LIN                     1058
#define IDC_MAG_LIN                     1059
#define IDC_STATUS                      1061
#define IDC_TITLE                       1062
#define IDM_FILE_LOAD                   40001
#define IDM_FILE_SAVE                   40002
#define IDM_FILE_EXIT                   40003
#define IDM_VIDEO_SPEED_SLOW            40004
#define IDM_VIDEO_CLIP_NEAR             40004
#define IDM_VIDEO_SPEED_MEDIUM          40005
#define IDM_VIDEO_CLIP_MEDIUM           40005
#define IDM_VIDEO_SPEED_FAST            40006
#define IDM_VIDEO_CLIP_FAR              40006
#define IDM_VIDEO_FLOOR                 40007
#define IDM_VIDEO_CEILING               40008
#define IDM_HELP_ABOUT                  40009
#define IDM_VIDEO_SKIPFRAME             40010
#define IDM_EDIT_EDITMODE               40011
#define IDM_EDIT_ADD_PRIMITIVE          40012
#define IDM_EDIT_WORLD                  40013
#define IDM_FILE_NEW                    40015
#define IDM_EDIT_ZOOM_IN                40016
#define IDM_EDIT_ZOOM_OUT               40017
#define IDM_EDIT_CLEAR_AREA             40018
#define IDM_EDIT_ADD_LIGHT              40020
#define IDM_EDIT_ADD_ENEMY              40021
#define IDM_EDIT_PLAYER                 40022
#define IDM_FILE_SAVE_AS                40023
#define IDM_EDIT_ADD_TEXTURE            40024
#define IDM_VIDEO_RES                   40026
#define IDM_VIDEO_FOG                   40027
#define IDM_VIDEO_32BIT                 40028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40029
#define _APS_NEXT_CONTROL_VALUE         1063
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
