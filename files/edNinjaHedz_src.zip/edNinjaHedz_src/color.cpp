#include "gfxTypes.h"

#ifdef PREFS_ON

#include "preferences.h"
extern	preferences Prefs;

#endif

/****************************************************************
*
* GFX_Color
* Holds color information
*
****************************************************************/
/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   DEFAULT CONSTRUCTOR
/////////////////////////////////////////////////////////////////
color::color()
{
	setColor(0.0, 0.0, 0.0, 1.0);
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   PARAMETERIZED CONSTRUCTOR
//
// [PARAMETERS]
//   GFX_FLOAT tmpRed, tmpGreen, tmpBlue, tmpAlpha- RGBA values
//
/////////////////////////////////////////////////////////////////
color::color(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
             GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha)
{
	setColor(tmpRed, tmpGreen, tmpBlue, tmpAlpha);
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   PARAMETERIZED CONSTRUCTOR
//
// [PARAMETERS]
//   GFX_FLOAT tmpRed, tmpGreen, tmpBlue- RGB Components
//
// [NOTES]
//   ALPHA is assumed to be 1.0
//
/////////////////////////////////////////////////////////////////
color::color(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue)
{
	setColor(tmpRed, tmpGreen, tmpBlue, 1.0);
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   sets the color values.
//
// [PARAMETERS]
//   GFX_FLOAT tmpRed, tmpGreen, tmpBlue, tmpAlpha- RGBA values
//
// [NOTES]
// OVERLOADED
//
/////////////////////////////////////////////////////////////////
void
color::setColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen,
                GFX_FLOAT tmpBlue, GFX_FLOAT tmpAlpha)
{
	red = tmpRed;
	green = tmpGreen;
	blue = tmpBlue;
	alpha = tmpAlpha;
}

/////////////////////////////////////////////////////////////////
// Assumes Alpha is one
/////////////////////////////////////////////////////////////////
void
color::setColor(GFX_FLOAT tmpRed, GFX_FLOAT tmpGreen, GFX_FLOAT tmpBlue)
{
	setColor(tmpRed, tmpGreen, tmpBlue, 1.0);
}

/////////////////////////////////////////////////////////////////
//  takes a color parameter
/////////////////////////////////////////////////////////////////
void
color::setColor(color tmpColor)
{
	red = tmpColor.red;
	green = tmpColor.green;
	blue = tmpColor.blue;
	alpha = tmpColor.alpha;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This mixes another color in by a given percent
//
// [PARAMETERS]
//   color otherColor- The color to mix in
//   GFX_FLOAT mixPercent-  The % of the other color to mix in
//
/////////////////////////////////////////////////////////////////
void
color::mixColor(color otherColor, GFX_FLOAT mixPercent)
{
	GFX_FLOAT keepPercent;   //The amount to retain.
	keepPercent = 1.0 - mixPercent;

	red = (red * keepPercent) + (otherColor.red * mixPercent);
	green = (green * keepPercent) + (otherColor.green * mixPercent);
	blue = (blue * keepPercent) + (otherColor.blue * mixPercent);
	alpha = (alpha * keepPercent) + (otherColor.alpha * mixPercent);
}

//////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Issues OpenGL to use the color
//
// [EXTERNAL REFS]
//   Assumes PREFS exists and defines a GAMMA setting
//////////////////////////////////////////////////////////////////
void
color::sendGL(void)
{
#ifdef PREFS_ON
	glColor4f(red * Prefs.gamma, green * Prefs.gamma, blue * Prefs.gamma, alpha);
#else
	glColor4f(red, green, blue, alpha);
#endif
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//    Overloaded operator: EQUALS
// [PARAMETERS]
//    otherColor- the color to return
//
/////////////////////////////////////////////////////////////////
const color&
color::operator=(const color& otherColor)
{
	red = otherColor.red;
	green = otherColor.green;
	blue = otherColor.blue;
	alpha = otherColor.alpha;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Overloaded operator +=
//
// [PARAMETERS]
//    otherColor- the color to add
//
/////////////////////////////////////////////////////////////////
const color&
color::operator+=(const color& otherColor)
{
	red += otherColor.red;
	green += otherColor.green;
	blue += otherColor.blue;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Overloaded operator -=
//
// [PARAMETERS]
//    otherColor- the color to subtract
//
/////////////////////////////////////////////////////////////////
const color&
color::operator-=(const color& otherColor)
{
	red -= otherColor.red;
	green += otherColor.green;
	blue -= otherColor.blue;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Overloaded operator +
//
// [PARAMETERS]
//    otherColor- the color to add
//
/////////////////////////////////////////////////////////////////
const color
color::operator+(const color& otherColor)
{
	color tmpColor;

	tmpColor.red = red + otherColor.red;
	tmpColor.green = green + otherColor.green;
	tmpColor.blue = blue + otherColor.blue;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator -
//
// [PARAMETERS]
//   color& otherColor- the color to subract
//
/////////////////////////////////////////////////////////////////
const color
color::operator-(const color& otherColor)
{
	color tmpColor;

	tmpColor.red = red - otherColor.red;
	tmpColor.green = green - otherColor.green;
	tmpColor.blue = blue - otherColor.blue;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator +
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- constant value to add
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color
color::operator+(GFX_FLOAT tmpNumber)
{
	color tmpColor;

	tmpColor.red = red + tmpNumber;
	tmpColor.green = green + tmpNumber;
	tmpColor.blue = blue + tmpNumber;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator -
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- constant number to subtract
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color
color::operator-(GFX_FLOAT tmpNumber)
{
	color tmpColor;

	tmpColor.red = red - tmpNumber;
	tmpColor.green = green - tmpNumber;
	tmpColor.blue = blue - tmpNumber;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator *
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- Constant number to multiply by
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color
color::operator*(GFX_FLOAT tmpNumber)
{
	color tmpColor;

	tmpColor.red = red * tmpNumber;
	tmpColor.green = green * tmpNumber;
	tmpColor.blue = blue * tmpNumber;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator /
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- number to divide by
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color
color::operator/(GFX_FLOAT tmpNumber)
{
	color tmpColor;

	tmpColor.red = red / tmpNumber;
	tmpColor.green = green / tmpNumber;
	tmpColor.blue = blue / tmpNumber;
	tmpColor.alpha = alpha;

	return tmpColor;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator +=
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- constant value to add
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color&
color::operator+=(GFX_FLOAT tmpNumber)
{
	red = red + tmpNumber;
	green = green + tmpNumber;
	blue = blue + tmpNumber;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator -=
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- constant number to subtract
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color&
color::operator-=(GFX_FLOAT tmpNumber)
{
	red = red - tmpNumber;
	green = green - tmpNumber;
	blue = blue - tmpNumber;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator *=
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- Constant number to multiply by
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color&
color::operator*=(GFX_FLOAT tmpNumber)
{
	red = red * tmpNumber;
	green = green * tmpNumber;
	blue = blue * tmpNumber;

	return *this;
}

/////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   overloaded operator /=
//
// [PARAMETERS]
//   GFX_FLOAT tmpNumber- number to divide by
//
// [NOTES]
//   ALPHA is unaffected
/////////////////////////////////////////////////////////////////
const color&
color::operator/=(GFX_FLOAT tmpNumber)
{
	red = red / tmpNumber;
	green = green / tmpNumber;
	blue = blue / tmpNumber;

	return *this;
}
