#ifndef POSITION_FILE_SEEN
#define POSITION_FILE_SEEN

#include "gfxTypes.h"
#include "vector.h"
#include "matrix2D.h"

class position
{
protected:

public:

	matrix2D Matrix;
	GFX_FLOAT degrees;
	GFX_FLOAT velocity;

	vector current;
	vector last;
	GFX_FLOAT radius;
	corners boundBox;

	position();

	void setAngle(GFX_FLOAT tmpDegrees);
	void setXY(GFX_FLOAT X, GFX_FLOAT Y);
	void setBoundBox(GFX_FLOAT x1, GFX_FLOAT x2, GFX_FLOAT y1, GFX_FLOAT y2);

	void move(void);
	bool getOtherCollide(position otherPosition);
	bool boundBoxCollide(position otherPosition);
  
};

#endif