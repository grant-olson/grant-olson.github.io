#include "quadtree.h"

/*********************************************************************
* LEAF MEMBERS
*********************************************************************/
//////////////////////////////////////////////////////////////////////
// default constructor
//////////////////////////////////////////////////////////////////////
leaf::leaf(){}

//////////////////////////////////////////////////////////////////////
// copy constructor
//////////////////////////////////////////////////////////////////////
leaf::leaf(leaf* tmpLeaf)
{
  Corner = tmpLeaf->Corner;
  Color = tmpLeaf->Color;
  tempMixColor = tmpLeaf->tempMixColor;
  height = tmpLeaf->height;
  flags = tmpLeaf->flags;
  texturePointer = tmpLeaf->texturePointer;
  textureIndex = tmpLeaf->textureIndex;
}

// all leafs share texturePointer.  It points to an array.
// textureIndex refers to the specific index
GLuint*
leaf::texturePointer = NULL;

//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This routine draws the leaf.
//
// [PARAMETERS]
//    --
// [RETURN TYPE]
//    --
// [NOTES]
//    THIS IS OUT OF DATE
//
//////////////////////////////////////////////////////////////////////
void
leaf::drawLeaf(void)
{
	sendLeafGL(Color);
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   This routine sets up the leaf for OpenGL rendering and incorporates
//   a background fade and mixes in a predefined temporary color.  It 
//   also clears out the tempColor when done.
// 
// [PARAMETERS]
//
// [RETURN TYPE]
//
// [NOTES]
//
//////////////////////////////////////////////////////////////////////
void
leaf::drawLeafWithFade(GFX_FLOAT tmpPercent, color* tmpBgcolor, GFX_FLOAT tmpThreshold)
{
  color tmpColor;
  tmpColor = Color;

  tmpColor += tempMixColor;

  if(tmpThreshold < tmpPercent)
  {
    tmpColor.mixColor((*tmpBgcolor), tmpPercent);
  }

  sendLeafGL(tmpColor);

  tempMixColor.setColor(0.0, 0.0, 0.0);
 
}


//////////////////////////////////////////////////////////////////////
// [DESCRIPTION]
//   Actually sends the OpenGL information to draw the leaf.
//
// [PARAMETERS]
//   tmpColor - the leaf color.  This acts as a lightmap when textures
//              are used.
//
// [RETURN TYPE]
//   --
// [NOTES]
//   Inlined for speed.
//
//////////////////////////////////////////////////////////////////////
inline void
leaf::sendLeafGL(color tmpColor)
{
  glBindTexture(GL_TEXTURE_2D, (*(texturePointer + textureIndex)));

  glBegin(GL_QUADS);
	
	tmpColor.sendGL();

  if(flags & LF_NORTH_WALL)
  {
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x1, height, Corner.y1);
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x2, height, Corner.y1);
    glTexCoord2f(0.0, 0.0);
    glVertex3f(Corner.x2, 0.0, Corner.y1);
    glTexCoord2f(1.0, 0.0);
    glVertex3f(Corner.x1, 0.0, Corner.y1);
  } 

  if(flags & LF_SOUTH_WALL)
  {
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x1, height, Corner.y2);
    glTexCoord2f(0.0, 0.0);
    glVertex3f(Corner.x1, 0.0, Corner.y2);
    glTexCoord2f(1.0, 0.0);
    glVertex3f(Corner.x2, 0.0, Corner.y2);
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x2, height, Corner.y2);
  } 

	tmpColor *= 0.85;  // to make corners a little more visible
	tmpColor.sendGL();

  if(flags & LF_EAST_WALL)
  {
    glTexCoord2f(1.0, 0.0);
    glVertex3f(Corner.x2, 0.0, Corner.y1);
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x2, height, Corner.y1);
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x2, height, Corner.y2);
    glTexCoord2f(0.0, 0.0);
    glVertex3f(Corner.x2, 0.0, Corner.y2);
  } 

  if(flags & LF_WEST_WALL)
  {
    glTexCoord2f(1.0, 0.0);
    glVertex3f(Corner.x1, 0.0, Corner.y2);
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x1, height, Corner.y2);
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x1, height, Corner.y1);
    glTexCoord2f(0.0, 0.0);
    glVertex3f(Corner.x1, 0.0, Corner.y1);
  } 


  if(flags & LF_TOP_WALL)
  {
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x2, height, Corner.y1);
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x1, height, Corner.y1);
    glTexCoord2f(0.0, 1.0);
    glVertex3f(Corner.x1, height, Corner.y2);
    glTexCoord2f(1.0,1.0);
    glVertex3f(Corner.x2, height, Corner.y2);
  } 

  if(flags & LF_BOTTOM_WALL)
  {
    glTexCoord2f(1.0, 0.75);
    glVertex3f(Corner.x2, 0.0, Corner.y1);
    glTexCoord2f(0.0, 0.75);
    glVertex3f(Corner.x1, 0.0, Corner.y1);
    glTexCoord2f(0.0, 1.0);
    glVertex3f(Corner.x1, 0.0, Corner.y2);
    glTexCoord2f(1.0, 1.0);
    glVertex3f(Corner.x2, 0.0, Corner.y2);
  } 

  glEnd();

}