#ifndef NINJA_SPRITES_SEEN
#define NINJA_SPRITES_SEEN

#include "sprites.h"
#include "MD2fromQuake.h"

//////////////////////////////////////////////////////////////////////
//
// SPRITE_TYPE:
//
// This just enumerates the different hard coded SPRITE COLLECTIONS to
// make things a little easier when we instantiate specific sub-classes
// of the virtual sprite class through the SPRITE COLLECTION.
// Its easier to remember AddNew(NinjaHead) than AddNew(37).
//
//////////////////////////////////////////////////////////////////////

enum sprite_type{HEAD, HEADII, STAR};

//////////////////////////////////////////////////////////////////////
// A specific sprite: PLAYER
// Handles the players sprite
//////////////////////////////////////////////////////////////////////

class player : public sprite{

private:
	static mesh* PLAYER_MESH;

protected:

public:
	virtual void ActionDamage(void);
	virtual void ActionNoHP(void);

	player();
	virtual void cycleAnim(void);
	virtual void cyclePosition(void);
};

//////////////////////////////////////////////////////////////////////
// A specific sprite: head
// Just a stupid square that kind-of chases you for development.
//////////////////////////////////////////////////////////////////////

class head : public sprite{

private:
	static mesh* HEAD_MESH;

protected:
	virtual void initPointers(void);

	spriteCollection* Projs;
	sprite* Player;

public:

	virtual void ActionCollide(sprite* otherSprite);
	virtual void ActionBound(void);
	virtual void ActionDamage(void);
	virtual void ActionSight(void);
	virtual void ActionNoHP(void);

	head();
	virtual void cycleAnim(void);
	virtual void cyclePosition(void);
};


//////////////////////////////////////////////////////////////////////
// A specific sprite: STAR
// Throwing Star.
//////////////////////////////////////////////////////////////////////

class star : public sprite{

private:
	static mesh* STAR_MESH;

protected:

public:

	star();
		
	virtual void ActionCollide(sprite* otherSprite);
	virtual void ActionBound(void);
	virtual void ActionOutOfRange(void);

	virtual void cycleAnim(void);
	virtual void cyclePosition(void);
};


//////////////////////////////////////////////////////////////////////
//  This is a collection of projectile sprites.  It holds the throwing
//  stars.
//////////////////////////////////////////////////////////////////////
class projectiles: public spriteCollection{

private:
	sprite* playerSprite;    // For Collision 
	spriteCollection* enemySprites;

	virtual sprite* createNew(sprite_type tmpSprite);

public:
	virtual void initPointers(void);
	virtual void collisionRoutine(void);

};

//////////////////////////////////////////////////////////////////////
//  This is a collection of enemy sprites.  It holds all the bad guys
//  that can actually damage the player.
//////////////////////////////////////////////////////////////////////
class enemies : public spriteCollection{

private:
	sprite* playerSprite;    // For Collision 
	spriteCollection* projectileSprites;
	virtual sprite* createNew(sprite_type tmpSprite);

public:
	virtual void initPointers(void);
	virtual void collisionRoutine(void);
};

class headII : public head{

private:
	static mesh* HEADII_MESH;

public:
	headII();
	projectiles* projs;
	virtual void ActionBound(void);
	virtual void cyclePosition(void);

};

#endif