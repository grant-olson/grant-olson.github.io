#ifndef	FILE_IO_SEEN
#define FILE_IO_SEEN

// LEVEL FILE FORMAT INFO
// this is the FILE HEADER
#include <windows.h>
#include "gfxTypes.h"
#include "editor.h"

struct fileInfo
{
	int			worldSize;
	int			worldResolution;
	color		backgroundColor;
	bool		fadeOn;
	GLfloat		fadeThreshold;
	color		floorColor;
	bool		floorOn;
	bool		ceilingOn;

	vector		PlayerPos;

	int			textureCount;
	int			lightCount;
	int			leafCount;

	int			enemyCount;
	int			objectCount;		// NOT YET ADDED- objects: power-ups, doors, etc
	int			eventCount;			// NOT YET ADDED- events: notably end of level
};

// Level File Functions
bool	createFile(TCHAR* filename);
bool	loadFile(TCHAR* filename);

// Log File
void WriteToLogFile(LPSTR logInfo);

#endif