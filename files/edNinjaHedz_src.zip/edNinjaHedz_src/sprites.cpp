#include "sprites.h"


/*******************************************************************************
* SPRITE:
* THIS PROVIDES SEVERAL GENERIC ROUTINES FOR HANDLING SPRITES.  THEY WILL 
* TRIGGER APPROPRIATE VIRTUAL ACTION FUNCTIONS THAT ARE OVERRIDDEN BY SUBCLASSES.
*******************************************************************************/
void
sprite::draw(void)
{
	glPushMatrix();

	glTranslatef(Position.current.X, 0.0, Position.current.Y);
	glRotatef(Position.current.degrees, 0.0, -1.0, 0.0);

	Mesh->draw(Color, frame);  

	glPopMatrix();
}

void
sprite::draw(const color& addColor)
{
	color tmpColor;

	tmpColor = Color;
	tmpColor += addColor;

	glPushMatrix();

	glTranslatef(Position.current.X, 0.0, Position.current.Y);
	glRotatef(Position.current.degrees, 0.0, -1.0, 0.0);

	Mesh->draw(tmpColor, frame);  

	glPopMatrix();
}

//////////////////////////////////////////////////////////////////////
// This only draws if the argument drawOrNot is TRUE.  It's here so
// that you can incorporate skip frames more easily.  For collections
// and other stuff, it will still cycle all the necessary info so
// skipframe mode won't slow down.
//////////////////////////////////////////////////////////////////////
void
sprite::draw(bool drawOrNot)
{
	if(drawOrNot){draw();}
}

void
sprite::draw(bool drawOrNot, const color& addColor)
{
	if(drawOrNot){draw(addColor);}
}
//////////////////////////////////////////////////////////////////////
// Collision detection routine.  Starts off with basic VECTOR bounding circle
// test.
//////////////////////////////////////////////////////////////////////

bool
sprite::collideVector(vector otherVector)
{
  if( Position.current.getOtherCollide(otherVector) )
  {
    // add more sophisticated tests
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}   

//////////////////////////////////////////////////////////////////////
// This tests collision against an individual sprite and performs
// appropriate Action call
//////////////////////////////////////////////////////////////////////
bool
sprite::collideSprite(sprite* otherSprite)
{
 vector tmpVector;
 bool tmpReturn;

  tmpReturn = FALSE;
  tmpVector = otherSprite->Position.current;

  if(collideVector(tmpVector) && !otherSprite->State.hit)
  {
    if(Position.boundBoxCollide(otherSprite->Position) ||
		otherSprite->Position.boundBoxCollide(Position))
    {
      tmpReturn = TRUE;
      ActionCollide(otherSprite);
    }
  }

  return tmpReturn;

}

//////////////////////////////////////////////////////////////////////
// This tests collision against an  sprite collection and performs
// appropriate Action call
//////////////////////////////////////////////////////////////////////
void 
sprite::collideCollection(void* SpriteCollection)
{
  // we use void pointer because spriteCollection
  // is a forward reference in the definition

  spriteCollection* Collection;
  Collection = (spriteCollection*)SpriteCollection;
  bool tmpSwitch = FALSE;

  // does collection have at least one member?

  if(Collection->count != 0 )
  {
    Collection->current = Collection->first;

    while(!tmpSwitch)
    {
      collideSprite(Collection->current);
      if(Collection->current == Collection->last)
      {tmpSwitch = TRUE;}
      else
      {Collection->current = Collection->current->next;}
    }
  }  
}

//////////////////////////////////////////////////////////////////////
// Tests bounding range
//////////////////////////////////////////////////////////////////////
bool
sprite::bound(world* World)
{
  bool tmpReturn = FALSE;

  vector tmpVector;

  Position.Matrix.loadIdentity();
  Position.Matrix.translate(Position.current.X, Position.current.Y);
  Position.Matrix.rotate(Position.current.radians);

  if(World->bound(Position.current.X, Position.current.Y))
  {
    tmpReturn = TRUE;
  }

  tmpVector.X = Position.boundBox.x1;
  tmpVector.Y = Position.boundBox.y1;

  tmpVector = Position.Matrix * tmpVector;

  glBegin(GL_QUADS);
  glColor3f(0.0, 1.0, 0.0);
  glVertex3f(tmpVector.X, 0.0, tmpVector.Y);

  if(World->bound(tmpVector.X, tmpVector.Y))
  {
    tmpReturn = TRUE;
  }

  tmpVector.X = Position.boundBox.x1;
  tmpVector.Y = Position.boundBox.y2;
  tmpVector = Position.Matrix * tmpVector;


  glVertex3f(tmpVector.X, 0.0, tmpVector.Y);


  if(World->bound(tmpVector.X, tmpVector.Y))
  {
    tmpReturn = TRUE;
  }

  tmpVector.X = Position.boundBox.x2;
  tmpVector.Y = Position.boundBox.y2;

  tmpVector = Position.Matrix  * tmpVector;


  glVertex3f(tmpVector.X, 0.0, tmpVector.Y);

  if(World->bound(tmpVector.X, tmpVector.Y))
  {
    tmpReturn = TRUE;
  }

  tmpVector.X = Position.boundBox.x2;
  tmpVector.Y = Position.boundBox.y1;

  tmpVector = Position.Matrix * tmpVector;


  glVertex3f(tmpVector.X, 0.0, tmpVector.Y);


  if(World->bound(tmpVector.X, tmpVector.Y))
  {
    tmpReturn = TRUE;
  }


glEnd();


  if(tmpReturn)
    {ActionBound();}

  return tmpReturn;
}

//////////////////////////////////////////////////////////////////////
// This cycles through the state variables and triggers the
// appropriate ACTIONS. The state variables act as counters. 
// Once set, they count their ways down and trigger an ACTION
// when they reach ZERO.
//////////////////////////////////////////////////////////////////////
void
sprite::cycleState(void)
{
	if(State.dead)
	{
		State.dead--;
		if(!State.dead){ActionDead();}

		return;
	}

	if(State.damage){ActionDamage();}
  
	if(State.hit)
	{
		State.hit--;
		if(!State.hit){ActionHit();}
	}

	if(State.sight)
	{
		State.sight--;
		if(!State.sight){ActionSight();}
	}

	if(State.saw)
	{
		State.saw--;
		if(!State.saw){ActionSaw();}
	}

	if(hitPoints <= 0){ActionNoHP();}
}

//////////////////////////////////////////////////////////////////////
// The virtual Action function that is called if a collision takes place
//////////////////////////////////////////////////////////////////////
void
sprite::ActionCollide(sprite* otherSprite)
{
  otherSprite->State.damage = 1;
}

//////////////////////////////////////////////////////////////////////
// The virtual Action function that is called if bounding
// limits are exceeded
//////////////////////////////////////////////////////////////////////
void
sprite::ActionBound(void)
{
  Position.current = Position.last;
}

//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens when Dead State Expires
//////////////////////////////////////////////////////////////////////
void
sprite::ActionDead(void)
{
  State.deleteDead = TRUE;
}
//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens for damage.
//////////////////////////////////////////////////////////////////////
void
sprite::ActionDamage(void)
{
  hitPoints -= State.damage;
  State.damage = 0;
  State.hit = 10;
}

//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens when Hit State Expires
//////////////////////////////////////////////////////////////////////
void
sprite::ActionHit(void)
{

}

//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens when see time runs out
//////////////////////////////////////////////////////////////////////
void
sprite::ActionSight(void)
{
    State.saw = 10;
    Position.velocity = 0.6;
}
//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens when SAW timer runs down
//////////////////////////////////////////////////////////////////////
void
sprite:: ActionSaw(void)
{

}
//////////////////////////////////////////////////////////////////////
// The virtual Action function that happens sprite runs out of hitpoints
//////////////////////////////////////////////////////////////////////
void
sprite::ActionNoHP(void)
{
	State.dead = 1;    
}

void
sprite::ActionOutOfRange(void)
{
	
}

//////////////////////////////////////////////////////////////////////
// A generic mechanism to pass pointers to subclasses.  Used in
// conjuntion with voidPointer1, 2, 3
//////////////////////////////////////////////////////////////////////
void
sprite::initPointers(void)
{

}

