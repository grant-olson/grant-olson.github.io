#ifndef STATE_FILE_SEEN
#define STATE_FILE_SEEN

//////////////////////////////////////////////////////////////////////
//
// STATE-
//
// This provides the generic STATE MACHINE setup.  The STATES are set
// to a integer that counts its way down to zero and triggers an ACTION
// FUNCTION with a name like ActionDead() for the dead state.
// These are used by the various SPRITES via virtual functions so we
// can trigger SPRITE specific actions though a generic mechanism.
// The cycling of the STATE MACHINE is also handled by the SPRITE class
//
// STATES:
//    dead   -    dead, but not deleted
//    hit    -    you've been hit
//    damage -    determines damage to go against hitPoints.
//    sight  -    sees target object
//    saw    -    has recently seen target object
//
//    deleteDead- flag that causes you to be deleted from collection
//
//////////////////////////////////////////////////////////////////////

struct state{
	short int dead;
	short int hit;
	short int damage;
	short int sight;
	short int saw;
	bool deleteDead;

	state(){
		dead = 0;
		hit = 0;
		damage = 0;
		sight = 0;
		saw = 0;
		deleteDead=FALSE;
	}
};

#endif
